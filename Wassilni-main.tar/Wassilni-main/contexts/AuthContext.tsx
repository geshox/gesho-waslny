// Powered by OnSpace.AI
import React, { createContext, useState, useEffect, ReactNode } from 'react';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import {
  sendPhoneOTP,
  verifyPhoneOTP,
  getOrCreateProfile,
  fetchProfile,
  updateWalletBalance,
  signOut,
  UserProfile,
} from '@/services/authService';
import { MOCK_USER } from '@/constants/mockData';
import {
  registerForPushNotifications,
  savePushToken,
} from '@/services/notificationService';

export interface User {
  id: string;
  name: string;
  phone: string;
  avatar: string;
  rating: number;
  totalRides: number;
  walletBalance: number;
  joinDate: string;
  isVerified: boolean;
  role: 'passenger' | 'driver' | 'admin';
}

function mapProfile(p: UserProfile): User {
  return {
    id: p.id,
    name: p.full_name ?? 'مستخدم جديد',
    phone: p.phone,
    avatar:
      p.avatar_url ??
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
    rating: p.rating,
    totalRides: p.total_rides,
    walletBalance: p.wallet_balance,
    joinDate: new Date(p.created_at).toLocaleDateString('ar-EG', {
      month: 'long',
      year: 'numeric',
    }),
    isVerified: p.is_verified,
    role: p.role,
  };
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  pendingPhone: string;
  authError: string | null;
  login: (phone: string) => Promise<void>;
  verifyOTP: (otp: string) => Promise<boolean>;
  logout: () => void;
  updateBalance: (amount: number) => void;
  clearAuthError: () => void;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [pendingPhone, setPendingPhone] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);

  // ── Restore session on mount ──────────────────────────────────────────────
  useEffect(() => {
    if (!isSupabaseConfigured) {
      // Mock mode — no backend connected yet
      setIsLoading(false);
      return;
    }

    supabase.auth.getSession().then(async ({ data: { session } }) => {
      if (session?.user) {
        const profile = await fetchProfile(session.user.id);
        if (profile) setUser(mapProfile(profile));
        const token = await registerForPushNotifications();
        if (token && session.user.id) await savePushToken(session.user.id, token);
      }
      setIsLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (event === 'SIGNED_IN' && session?.user) {
          const profile = await fetchProfile(session.user.id);
          if (profile) setUser(mapProfile(profile));
        }
        if (event === 'SIGNED_OUT') {
          setUser(null);
        }
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  const login = async (phone: string) => {
    setIsLoading(true);
    setAuthError(null);
    const formattedPhone = phone.startsWith('+') ? phone : `+2${phone.replace(/^0/, '')}`;
    setPendingPhone(formattedPhone);

    if (!isSupabaseConfigured) {
      // Mock mode
      await new Promise(r => setTimeout(r, 800));
      setIsLoading(false);
      return;
    }

    const { error } = await sendPhoneOTP(formattedPhone);
    setIsLoading(false);
    if (error) setAuthError(error);
  };

  const verifyOTP = async (otp: string): Promise<boolean> => {
    setIsLoading(true);
    setAuthError(null);

    if (!isSupabaseConfigured) {
      // Mock mode — accept any 4-6 digit code
      await new Promise(r => setTimeout(r, 1000));
      if (otp.length >= 4) {
        setUser({
          id: 'mock_user',
          name: MOCK_USER.name,
          phone: pendingPhone || MOCK_USER.phone,
          avatar: MOCK_USER.avatar,
          rating: MOCK_USER.rating,
          totalRides: MOCK_USER.totalRides,
          walletBalance: MOCK_USER.walletBalance,
          joinDate: MOCK_USER.joinDate,
          isVerified: MOCK_USER.isVerified,
          role: 'passenger',
        });
        setIsLoading(false);
        return true;
      }
      setAuthError('رمز التحقق يجب أن يكون 4 أرقام على الأقل');
      setIsLoading(false);
      return false;
    }

    const { userId, error } = await verifyPhoneOTP(pendingPhone, otp);
    if (error || !userId) {
      setIsLoading(false);
      setAuthError(error ?? 'رمز التحقق غير صحيح');
      return false;
    }

    const { profile, error: profileErr } = await getOrCreateProfile(userId, pendingPhone);
    if (profileErr || !profile) {
      setIsLoading(false);
      setAuthError(profileErr ?? 'خطأ في تحميل الملف الشخصي');
      return false;
    }

    setUser(mapProfile(profile));

    const token = await registerForPushNotifications();
    if (token) await savePushToken(userId, token);

    setIsLoading(false);
    return true;
  };

  const logout = async () => {
    if (isSupabaseConfigured) await signOut();
    setUser(null);
  };

  const updateBalance = async (amount: number) => {
    if (!user) return;
    const newBalance = user.walletBalance + amount;
    setUser({ ...user, walletBalance: newBalance });
    await updateWalletBalance(user.id, newBalance);
  };

  const clearAuthError = () => setAuthError(null);

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        pendingPhone,
        authError,
        login,
        verifyOTP,
        logout,
        updateBalance,
        clearAuthError,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}
