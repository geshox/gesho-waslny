// Powered by OnSpace.AI
import { supabase } from '@/lib/supabase';
import { Database } from '@/lib/supabase';

type DriverRow = Database['public']['Tables']['drivers']['Row'];
type DriverInsert = Database['public']['Tables']['drivers']['Insert'];

export interface DriverStats {
  todayEarnings: number;
  todayRides: number;
  weekEarnings: number;
  weekRides: number;
  avgRating: number;
  totalRides: number;
  totalEarnings: number;
  hoursOnline: number;
}

/**
 * Register driver profile
 */
export async function registerDriver(
  data: DriverInsert
): Promise<{ driver: DriverRow | null; error: string | null }> {
  const { data: driver, error } = await supabase
    .from('drivers')
    .insert({ ...data, approval_status: 'pending', is_approved: false, is_online: false })
    .select()
    .single();

  if (error) return { driver: null, error: error.message };

  // Update user role to driver
  await supabase.from('users').update({ role: 'driver' }).eq('id', data.user_id);

  return { driver: driver as DriverRow, error: null };
}

/**
 * Get driver profile by user_id
 */
export async function getDriverByUserId(userId: string): Promise<DriverRow | null> {
  const { data } = await supabase
    .from('drivers')
    .select('*')
    .eq('user_id', userId)
    .single();
  return (data as DriverRow) ?? null;
}

/**
 * Toggle driver online/offline status
 */
export async function setDriverOnlineStatus(
  driverId: string,
  isOnline: boolean,
  lat?: number,
  lng?: number
): Promise<{ error: string | null }> {
  const update: any = { is_online: isOnline };
  if (lat !== undefined) update.current_lat = lat;
  if (lng !== undefined) update.current_lng = lng;

  const { error } = await supabase.from('drivers').update(update).eq('id', driverId);
  return { error: error?.message ?? null };
}

/**
 * Update driver location
 */
export async function updateDriverLocation(
  driverId: string,
  lat: number,
  lng: number
): Promise<void> {
  await supabase.from('drivers').update({ current_lat: lat, current_lng: lng }).eq('id', driverId);
}

/**
 * Get driver stats (today + week)
 */
export async function getDriverStats(driverId: string): Promise<DriverStats> {
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString();
  const weekStart = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString();

  const [todayData, weekData, totalData, ratingData] = await Promise.all([
    supabase
      .from('rides')
      .select('price')
      .eq('driver_id', driverId)
      .eq('status', 'completed')
      .gte('completed_at', todayStart),
    supabase
      .from('rides')
      .select('price')
      .eq('driver_id', driverId)
      .eq('status', 'completed')
      .gte('completed_at', weekStart),
    supabase
      .from('rides')
      .select('price')
      .eq('driver_id', driverId)
      .eq('status', 'completed'),
    supabase
      .from('rides')
      .select('driver_rating')
      .eq('driver_id', driverId)
      .not('driver_rating', 'is', null),
  ]);

  const todayRides = todayData.data ?? [];
  const weekRides = weekData.data ?? [];
  const allRides = totalData.data ?? [];
  const ratings = ratingData.data ?? [];

  const todayEarnings = todayRides.reduce((s, r) => s + (r.price || 0), 0);
  const weekEarnings = weekRides.reduce((s, r) => s + (r.price || 0), 0);
  const totalEarnings = allRides.reduce((s, r) => s + (r.price || 0), 0);
  const avgRating =
    ratings.length > 0
      ? ratings.reduce((s, r) => s + (r.driver_rating || 0), 0) / ratings.length
      : 5.0;

  return {
    todayEarnings,
    todayRides: todayRides.length,
    weekEarnings,
    weekRides: weekRides.length,
    totalRides: allRides.length,
    totalEarnings,
    avgRating: parseFloat(avgRating.toFixed(1)),
    hoursOnline: 0,
  };
}

/**
 * Get nearby ride requests for driver
 */
export async function getNearbyRideRequests(
  vehicleType: string,
  lat: number,
  lng: number,
  radiusKm: number = 5
) {
  const { data } = await supabase
    .from('rides')
    .select('*')
    .eq('status', 'searching')
    .eq('vehicle_type', vehicleType)
    .limit(10);
  return data ?? [];
}

/**
 * Driver accepts a ride
 */
export async function acceptRide(
  rideId: string,
  driverId: string
): Promise<{ error: string | null }> {
  const { error } = await supabase
    .from('rides')
    .update({ driver_id: driverId, status: 'accepted' })
    .eq('id', rideId)
    .eq('status', 'searching');
  return { error: error?.message ?? null };
}

/**
 * Subscribe to incoming ride requests for a driver
 */
export function subscribeToRideRequests(
  vehicleType: string,
  callback: (ride: any) => void
) {
  return supabase
    .channel('ride_requests')
    .on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'rides',
        filter: `vehicle_type=eq.${vehicleType}`,
      },
      (payload) => callback(payload.new)
    )
    .subscribe();
}
