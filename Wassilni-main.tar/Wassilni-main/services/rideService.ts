// Powered by OnSpace.AI
import { supabase } from '@/lib/supabase';
import { Database } from '@/lib/supabase';

type RideRow = Database['public']['Tables']['rides']['Row'];
type RideInsert = Database['public']['Tables']['rides']['Insert'];
type RideUpdate = Database['public']['Tables']['rides']['Update'];

export type RideStatus = RideRow['status'];

/**
 * Create a new ride request
 */
export async function createRide(
  data: RideInsert
): Promise<{ ride: RideRow | null; error: string | null }> {
  const { data: ride, error } = await supabase
    .from('rides')
    .insert(data)
    .select()
    .single();

  if (error) return { ride: null, error: error.message };
  return { ride: ride as RideRow, error: null };
}

/**
 * Update ride status and optional fields
 */
export async function updateRide(
  rideId: string,
  updates: RideUpdate
): Promise<{ error: string | null }> {
  const { error } = await supabase.from('rides').update(updates).eq('id', rideId);
  return { error: error?.message ?? null };
}

/**
 * Get ride by ID
 */
export async function getRide(rideId: string): Promise<RideRow | null> {
  const { data } = await supabase.from('rides').select('*').eq('id', rideId).single();
  return (data as RideRow) ?? null;
}

/**
 * Get passenger ride history
 */
export async function getPassengerRides(passengerId: string): Promise<RideRow[]> {
  const { data } = await supabase
    .from('rides')
    .select('*')
    .eq('passenger_id', passengerId)
    .order('created_at', { ascending: false });
  return (data as RideRow[]) ?? [];
}

/**
 * Get driver ride history
 */
export async function getDriverRides(driverId: string): Promise<RideRow[]> {
  const { data } = await supabase
    .from('rides')
    .select('*')
    .eq('driver_id', driverId)
    .order('created_at', { ascending: false });
  return (data as RideRow[]) ?? [];
}

/**
 * Submit passenger rating
 */
export async function rateRide(
  rideId: string,
  rating: number,
  review: string,
  raterRole: 'passenger' | 'driver'
): Promise<{ error: string | null }> {
  const update =
    raterRole === 'passenger'
      ? { passenger_rating: rating, passenger_review: review }
      : { driver_rating: rating, driver_review: review };

  const { error } = await supabase.from('rides').update(update).eq('id', rideId);
  return { error: error?.message ?? null };
}

/**
 * Subscribe to real-time ride updates
 */
export function subscribeToRide(
  rideId: string,
  callback: (ride: RideRow) => void
) {
  return supabase
    .channel(`ride:${rideId}`)
    .on(
      'postgres_changes',
      { event: 'UPDATE', schema: 'public', table: 'rides', filter: `id=eq.${rideId}` },
      (payload) => callback(payload.new as RideRow)
    )
    .subscribe();
}

/**
 * Subscribe to new ride requests (for drivers)
 */
export function subscribeToNewRides(
  vehicleType: string,
  callback: (ride: RideRow) => void
) {
  return supabase
    .channel('new_rides')
    .on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'rides',
        filter: `vehicle_type=eq.${vehicleType}`,
      },
      (payload) => callback(payload.new as RideRow)
    )
    .subscribe();
}
