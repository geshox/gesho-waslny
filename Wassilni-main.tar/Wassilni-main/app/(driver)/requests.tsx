// Powered by OnSpace.AI
import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, Alert, Platform,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Spacing, Radius, Fonts, Shadow } from '@/constants/theme';
import { useDriver } from '@/hooks/useDriver';
import { acceptRide } from '@/services/driverService';
import { notifyNewRideRequest } from '@/services/notificationService';

export default function DriverRequests() {
  const insets = useSafeAreaInsets();
  const { incomingRequests, dismissRequest, driverProfile, isOnline } = useDriver();
  const [acceptingId, setAcceptingId] = useState<string | null>(null);

  const ZONE_LABELS: Record<string, string> = {
    city: 'داخل المدينة', village: 'القرى والريف', intercity: 'بين المدن',
  };

  const handleAccept = async (rideId: string) => {
    if (!driverProfile) return;
    setAcceptingId(rideId);
    const { error } = await acceptRide(rideId, driverProfile.id);
    setAcceptingId(null);
    if (error) {
      if (Platform.OS !== 'web') Alert.alert('خطأ', 'لم يتم قبول الرحلة، ربما قبلها سائق آخر');
      dismissRequest(rideId);
      return;
    }
    dismissRequest(rideId);
    if (Platform.OS !== 'web') Alert.alert('تم القبول ✅', 'تم قبول الرحلة بنجاح، توجّه للراكب');
  };

  const handleReject = (rideId: string) => {
    dismissRequest(rideId);
  };

  const renderItem = ({ item }: { item: any }) => {
    const isAccepting = acceptingId === item.id;
    return (
      <View style={styles.requestCard}>
        <View style={styles.cardHeader}>
          <Text style={styles.cardTime}>
            {new Date(item.created_at).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}
          </Text>
          <View style={styles.zoneBadge}>
            <Text style={styles.zoneText}>{ZONE_LABELS[item.zone] ?? item.zone}</Text>
          </View>
        </View>

        <View style={styles.routeSection}>
          <View style={styles.routeRow}>
            <View style={[styles.routeDot, { backgroundColor: Colors.primary }]} />
            <Text style={styles.routeAddr} numberOfLines={1}>{item.from_address}</Text>
          </View>
          <View style={styles.routeConnector} />
          <View style={styles.routeRow}>
            <View style={[styles.routeDot, { backgroundColor: Colors.error }]} />
            <Text style={styles.routeAddr} numberOfLines={1}>{item.to_address}</Text>
          </View>
        </View>

        <View style={styles.detailsRow}>
          <View style={styles.detailItem}>
            <MaterialIcons name="directions" size={14} color={Colors.textSecondary} />
            <Text style={styles.detailText}>{item.distance_km?.toFixed(1)} كم</Text>
          </View>
          <View style={styles.detailItem}>
            <MaterialIcons name="schedule" size={14} color={Colors.textSecondary} />
            <Text style={styles.detailText}>{item.duration_minutes} د</Text>
          </View>
          <Text style={styles.priceText}>{item.price} ج.م</Text>
        </View>

        <View style={styles.cardActions}>
          <TouchableOpacity style={styles.rejectBtn} onPress={() => handleReject(item.id)}>
            <MaterialIcons name="close" size={18} color={Colors.error} />
            <Text style={styles.rejectText}>رفض</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.acceptBtnWrapper}
            onPress={() => handleAccept(item.id)}
            disabled={isAccepting}
          >
            <LinearGradient colors={[Colors.primary, Colors.primaryDark]} style={styles.acceptBtn}>
              <MaterialIcons name="check" size={18} color={Colors.textInverse} />
              <Text style={styles.acceptText}>{isAccepting ? 'جاري القبول...' : 'قبول الرحلة'}</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>طلبات الرحلات الواردة</Text>
        {incomingRequests.length > 0 ? (
          <View style={styles.countBadge}>
            <Text style={styles.countText}>{incomingRequests.length}</Text>
          </View>
        ) : null}
      </View>

      {!isOnline ? (
        <View style={styles.offlineState}>
          <LinearGradient colors={[Colors.errorFaded, Colors.background]} style={styles.offlineGradient}>
            <MaterialIcons name="wifi-off" size={56} color={Colors.error} />
            <Text style={styles.offlineTitle}>الخدمة متوقفة</Text>
            <Text style={styles.offlineDesc}>
              فعّل زر الخدمة من لوحة التحكم لاستقبال طلبات الرحلات الجديدة
            </Text>
          </LinearGradient>
        </View>
      ) : incomingRequests.length === 0 ? (
        <View style={styles.emptyState}>
          <MaterialIcons name="notifications-none" size={56} color={Colors.textTertiary} />
          <Text style={styles.emptyTitle}>لا توجد طلبات حالياً</Text>
          <Text style={styles.emptyDesc}>ستظهر طلبات الرحلات الجديدة هنا فور ورودها</Text>
        </View>
      ) : (
        <FlatList
          data={incomingRequests}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.base, paddingVertical: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  headerTitle: { fontSize: 18, fontWeight: Fonts.bold as any, color: Colors.text },
  countBadge: {
    backgroundColor: Colors.primary, borderRadius: Radius.full,
    minWidth: 24, height: 24, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 6,
  },
  countText: { color: Colors.textInverse, fontSize: 12, fontWeight: Fonts.bold as any },
  offlineState: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: Spacing.xl },
  offlineGradient: {
    width: '100%', padding: Spacing.xxl, borderRadius: Radius.xl,
    alignItems: 'center', gap: Spacing.md, borderWidth: 1, borderColor: Colors.error + '30',
  },
  offlineTitle: { fontSize: 20, fontWeight: Fonts.bold as any, color: Colors.error },
  offlineDesc: { fontSize: 14, color: Colors.textSecondary, textAlign: 'center', lineHeight: 22 },
  emptyState: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: Spacing.md },
  emptyTitle: { fontSize: 18, fontWeight: Fonts.semibold as any, color: Colors.textSecondary },
  emptyDesc: { fontSize: 14, color: Colors.textTertiary, textAlign: 'center', lineHeight: 22 },
  list: { padding: Spacing.base, gap: Spacing.md },
  requestCard: {
    backgroundColor: Colors.card, borderRadius: Radius.xl, padding: Spacing.base,
    borderWidth: 1, borderColor: Colors.border, gap: Spacing.md, ...Shadow.sm,
  },
  cardHeader: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between' },
  cardTime: { fontSize: 12, color: Colors.textTertiary },
  zoneBadge: {
    backgroundColor: Colors.accentFaded, borderRadius: Radius.full,
    paddingHorizontal: 10, paddingVertical: 4, borderWidth: 1, borderColor: Colors.accent + '30',
  },
  zoneText: { fontSize: 11, color: Colors.accent, fontWeight: Fonts.medium as any },
  routeSection: { gap: 4 },
  routeRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.sm },
  routeDot: { width: 8, height: 8, borderRadius: 4 },
  routeConnector: { width: 1, height: 12, backgroundColor: Colors.border, marginRight: 3.5 },
  routeAddr: { flex: 1, fontSize: 14, color: Colors.text, textAlign: 'right', fontWeight: Fonts.medium as any },
  detailsRow: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.md,
    backgroundColor: Colors.surface, borderRadius: Radius.md, padding: Spacing.md,
  },
  detailItem: { flexDirection: 'row-reverse', alignItems: 'center', gap: 4 },
  detailText: { fontSize: 13, color: Colors.textSecondary },
  priceText: { marginRight: 'auto', fontSize: 18, fontWeight: Fonts.extrabold as any, color: Colors.primary },
  cardActions: { flexDirection: 'row-reverse', gap: Spacing.sm },
  rejectBtn: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: 6,
    paddingHorizontal: Spacing.base, paddingVertical: 12,
    borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.error + '40', backgroundColor: Colors.errorFaded,
  },
  rejectText: { color: Colors.error, fontSize: 14, fontWeight: Fonts.medium as any },
  acceptBtnWrapper: { flex: 1, borderRadius: Radius.md, overflow: 'hidden', ...Shadow.glow },
  acceptBtn: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center',
    gap: 8, paddingVertical: 13,
  },
  acceptText: { color: Colors.textInverse, fontSize: 14, fontWeight: Fonts.bold as any },
});
