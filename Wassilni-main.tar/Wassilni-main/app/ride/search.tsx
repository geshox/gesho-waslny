// Powered by OnSpace.AI
import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  FlatList,
  Animated,
  ActivityIndicator,
  Platform,
  Dimensions,
  KeyboardAvoidingView,
} from 'react-native';
import { Image } from 'expo-image';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Spacing, Radius, Fonts, Shadow } from '@/constants/theme';
import { useAuth } from '@/hooks/useAuth';
import { useRide } from '@/hooks/useRide';
import { useNotifications } from '@/hooks/useNotifications';
import { MOCK_DRIVERS, VEHICLE_ICONS, VEHICLE_LABELS, VehicleType } from '@/constants/mockData';
import {
  calculateFare,
  estimateFare,
  DEFAULT_PRICING_CONFIG,
  VehicleType as PricingVehicleType,
} from '@/services/pricingEngine';

const { width } = Dimensions.get('window');

interface Suggestion {
  id: string;
  title: string;
  subtitle: string;
  icon: string;
  type: 'recent' | 'popular' | 'search';
}

const RECENT_PLACES: Suggestion[] = [
  { id: 'r1', title: 'المنزل',           subtitle: 'شارع 9، حي الرحاب',      icon: 'home',          type: 'recent' },
  { id: 'r2', title: 'العمل',            subtitle: 'برج النيل، مصر الجديدة', icon: 'work',          type: 'recent' },
  { id: 'r3', title: 'مطار القاهرة',     subtitle: 'الطريق الدائري',         icon: 'flight',        type: 'recent' },
];

const POPULAR_PLACES: Suggestion[] = [
  { id: 'p1', title: 'ميدان التحرير',    subtitle: 'وسط القاهرة',           icon: 'location-on',   type: 'popular' },
  { id: 'p2', title: 'مول مصر',          subtitle: '6 أكتوبر',              icon: 'shopping-bag',  type: 'popular' },
  { id: 'p3', title: 'الهرم',            subtitle: 'الجيزة',                icon: 'landscape',     type: 'popular' },
  { id: 'p4', title: 'ستاد القاهرة',     subtitle: 'مدينة نصر',             icon: 'sports-soccer', type: 'popular' },
];

const VEHICLE_ORDER: VehicleType[] = ['car', 'tuk', 'moto', 'microbus'];

const VEHICLE_COLOR: Record<VehicleType, string> = {
  car:      Colors.primary,
  tuk:      Colors.gold,
  moto:     Colors.accent,
  microbus: '#8B5CF6',
};

const VEHICLE_DESC: Record<VehicleType, string> = {
  car:      '1–4 أشخاص',
  tuk:      '1–2 شخص · اقتصادي',
  moto:     'شخص واحد · سريع',
  microbus: 'حتى 12 شخصاً',
};

export default function RideSearchScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { requestRide } = useRide();
  const { addNotification } = useNotifications();

  const [fromText, setFromText] = useState('موقعك الحالي');
  const [toText, setToText] = useState('');
  const [activeInput, setActiveInput] = useState<'from' | 'to' | null>(null);
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState<VehicleType>('car');
  const [selectedPayment, setSelectedPayment] = useState<string>('wallet');
  const [step, setStep] = useState<'search' | 'choose' | 'confirm'>('search');
  const [isBooking, setIsBooking] = useState(false);

  // Estimated distance — mock based on text length
  const estimatedDistanceKm = Math.max(2, (toText.length % 20) + 5);
  const estimatedDurationMin = Math.round(estimatedDistanceKm * 2.2);

  // Slide animation for panels
  const panelSlide = useRef(new Animated.Value(200)).current;
  const panelOpacity = useRef(new Animated.Value(0)).current;
  const confirmSlide = useRef(new Animated.Value(300)).current;
  const confirmOpacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (step === 'choose') {
      Animated.parallel([
        Animated.timing(panelSlide, { toValue: 0, duration: 350, useNativeDriver: true }),
        Animated.timing(panelOpacity, { toValue: 1, duration: 350, useNativeDriver: true }),
      ]).start();
    } else {
      panelSlide.setValue(200);
      panelOpacity.setValue(0);
    }
  }, [step]);

  useEffect(() => {
    if (step === 'confirm') {
      Animated.parallel([
        Animated.timing(confirmSlide, { toValue: 0, duration: 350, useNativeDriver: true }),
        Animated.timing(confirmOpacity, { toValue: 1, duration: 300, useNativeDriver: true }),
      ]).start();
    } else {
      confirmSlide.setValue(300);
      confirmOpacity.setValue(0);
    }
  }, [step]);

  const handleSearch = useCallback((text: string, field: 'from' | 'to') => {
    if (field === 'from') setFromText(text);
    else setToText(text);

    if (text.length < 2) {
      setSuggestions([]);
      return;
    }

    setIsSearching(true);
    // Simulate autocomplete delay
    setTimeout(() => {
      const mockResults: Suggestion[] = [
        { id: 's1', title: `${text} الجديدة`,      subtitle: 'القاهرة الكبرى',   icon: 'location-on', type: 'search' },
        { id: 's2', title: `شارع ${text}`,         subtitle: 'مصر الجديدة',      icon: 'map',         type: 'search' },
        { id: 's3', title: `ميدان ${text}`,         subtitle: 'وسط البلد',        icon: 'place',       type: 'search' },
        { id: 's4', title: `حي ${text}`,            subtitle: 'القاهرة',          icon: 'apartment',   type: 'search' },
      ].filter(s => s.title.includes(text) || Math.random() > 0.3);
      setSuggestions(mockResults);
      setIsSearching(false);
    }, 400);
  }, []);

  const handleSuggestionSelect = (s: Suggestion) => {
    if (activeInput === 'from') {
      setFromText(s.title);
    } else {
      setToText(s.title);
    }
    setSuggestions([]);
    setActiveInput(null);
    if (activeInput === 'to' && toText.length > 0) {
      setStep('choose');
    }
  };

  const handleSearchConfirm = () => {
    if (!toText.trim()) return;
    setSuggestions([]);
    setActiveInput(null);
    setStep('choose');
  };

  const handleVehicleSelect = (type: VehicleType) => {
    setSelectedVehicle(type);
  };

  const handleConfirmRide = () => {
    setStep('confirm');
  };

  const handleBookRide = async () => {
    setIsBooking(true);
    const driver = MOCK_DRIVERS.find(d => d.vehicleType === selectedVehicle) ?? MOCK_DRIVERS[0];

    await new Promise(r => setTimeout(r, 1200));
    await requestRide(driver, fromText, toText, selectedPayment);

    addNotification({
      type: 'ride_accepted',
      title: 'تم تأكيد رحلتك ✅',
      body: `السائق ${driver.name} في طريقه إليك`,
      icon: VEHICLE_ICONS[selectedVehicle],
    });

    setIsBooking(false);
    router.replace('/ride/active');
  };

  const getFare = (vehicleType: VehicleType) => {
    return calculateFare({
      vehicleType: vehicleType as PricingVehicleType,
      distanceKm: estimatedDistanceKm,
      durationMinutes: estimatedDurationMin,
      zone: 'city',
    }, DEFAULT_PRICING_CONFIG);
  };

  const PAYMENT_OPTIONS = [
    { id: 'wallet',   label: 'المحفظة', icon: 'account-balance-wallet', balance: `${user?.walletBalance?.toFixed(0) ?? 0} ج` },
    { id: 'cash',     label: 'نقدي',    icon: 'payments', balance: null },
    { id: 'instapay', label: 'إنستا باي', icon: 'mobile-friendly', balance: null },
  ];

  const selectedDriver = MOCK_DRIVERS.find(d => d.vehicleType === selectedVehicle) ?? MOCK_DRIVERS[0];
  const selectedFare = getFare(selectedVehicle);

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* ── Header ── */}
      <LinearGradient
        colors={['#0D2B1E', Colors.background]}
        style={styles.header}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
      >
        <View style={styles.headerRow}>
          <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
            <MaterialIcons name="arrow-forward" size={22} color={Colors.text} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>احجز رحلتك</Text>
          <View style={{ width: 40 }} />
        </View>

        {/* ── Search inputs ── */}
        <View style={styles.searchCard}>
          {/* From */}
          <TouchableOpacity
            style={[styles.searchField, activeInput === 'from' && styles.searchFieldActive]}
            onPress={() => setActiveInput('from')}
            activeOpacity={1}
          >
            <View style={[styles.dotFrom]} />
            {activeInput === 'from' ? (
              <TextInput
                style={styles.searchInput}
                value={fromText}
                onChangeText={t => { setFromText(t); handleSearch(t, 'from'); }}
                placeholder="من أين؟"
                placeholderTextColor={Colors.textTertiary}
                textAlign="right"
                autoFocus
                returnKeyType="next"
                onSubmitEditing={() => setActiveInput('to')}
              />
            ) : (
              <Text style={[styles.searchText, fromText ? styles.searchTextFilled : styles.searchTextPlaceholder]}>
                {fromText || 'من أين؟'}
              </Text>
            )}
          </TouchableOpacity>

          {/* Swap button */}
          <View style={styles.swapRow}>
            <View style={styles.swapLine} />
            <TouchableOpacity
              style={styles.swapBtn}
              onPress={() => {
                const temp = fromText;
                setFromText(toText);
                setToText(temp);
              }}
            >
              <MaterialIcons name="swap-vert" size={16} color={Colors.primary} />
            </TouchableOpacity>
          </View>

          {/* To */}
          <TouchableOpacity
            style={[styles.searchField, activeInput === 'to' && styles.searchFieldActive]}
            onPress={() => setActiveInput('to')}
            activeOpacity={1}
          >
            <View style={[styles.dotTo]} />
            {activeInput === 'to' ? (
              <TextInput
                style={styles.searchInput}
                value={toText}
                onChangeText={t => { setToText(t); handleSearch(t, 'to'); }}
                placeholder="إلى أين؟"
                placeholderTextColor={Colors.textTertiary}
                textAlign="right"
                autoFocus
                returnKeyType="search"
                onSubmitEditing={handleSearchConfirm}
              />
            ) : (
              <Text style={[styles.searchText, toText ? styles.searchTextFilled : styles.searchTextPlaceholder]}>
                {toText || 'إلى أين؟'}
              </Text>
            )}
          </TouchableOpacity>
        </View>

        {/* Search button */}
        {step === 'search' && toText.trim() ? (
          <TouchableOpacity style={styles.searchBtn} onPress={handleSearchConfirm}>
            <LinearGradient colors={[Colors.primary, Colors.primaryDark]} style={styles.searchBtnGrad}>
              <MaterialIcons name="search" size={18} color={Colors.textInverse} />
              <Text style={styles.searchBtnText}>ابحث عن سائق</Text>
            </LinearGradient>
          </TouchableOpacity>
        ) : null}
      </LinearGradient>

      {/* ── Autocomplete suggestions ── */}
      {(suggestions.length > 0 || isSearching) && activeInput ? (
        <View style={styles.suggestionsContainer}>
          {isSearching ? (
            <View style={styles.searchingRow}>
              <ActivityIndicator size="small" color={Colors.primary} />
              <Text style={styles.searchingText}>جارٍ البحث...</Text>
            </View>
          ) : (
            <FlatList
              data={suggestions}
              keyExtractor={item => item.id}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={styles.suggestionItem}
                  onPress={() => handleSuggestionSelect(item)}
                  activeOpacity={0.8}
                >
                  <View style={styles.suggestionIconBg}>
                    <MaterialIcons name={item.icon as any} size={16} color={Colors.primary} />
                  </View>
                  <View style={styles.suggestionInfo}>
                    <Text style={styles.suggestionTitle}>{item.title}</Text>
                    <Text style={styles.suggestionSub}>{item.subtitle}</Text>
                  </View>
                </TouchableOpacity>
              )}
              ItemSeparatorComponent={() => <View style={{ height: 1, backgroundColor: Colors.border, marginHorizontal: Spacing.base }} />}
            />
          )}
        </View>
      ) : null}

      {/* ── Default state: recent + popular ── */}
      {step === 'search' && !activeInput && !suggestions.length ? (
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.defaultContent}>
          {/* Recent */}
          <View style={styles.sectionBlock}>
            <Text style={styles.sectionTitle}>الأماكن الأخيرة</Text>
            {RECENT_PLACES.map(p => (
              <TouchableOpacity
                key={p.id}
                style={styles.placeItem}
                onPress={() => { setToText(p.title); setActiveInput(null); setStep('choose'); }}
              >
                <View style={[styles.placeIconBg, { backgroundColor: Colors.primaryFaded }]}>
                  <MaterialIcons name={p.icon as any} size={18} color={Colors.primary} />
                </View>
                <View style={styles.placeInfo}>
                  <Text style={styles.placeTitle}>{p.title}</Text>
                  <Text style={styles.placeSub}>{p.subtitle}</Text>
                </View>
                <MaterialIcons name="chevron-left" size={18} color={Colors.textTertiary} />
              </TouchableOpacity>
            ))}
          </View>

          {/* Popular */}
          <View style={styles.sectionBlock}>
            <Text style={styles.sectionTitle}>الأماكن الشائعة</Text>
            <View style={styles.popularGrid}>
              {POPULAR_PLACES.map(p => (
                <TouchableOpacity
                  key={p.id}
                  style={styles.popularCard}
                  onPress={() => { setToText(p.title); setActiveInput(null); setStep('choose'); }}
                  activeOpacity={0.82}
                >
                  <View style={[styles.popularIconBg, { backgroundColor: Colors.primaryFaded }]}>
                    <MaterialIcons name={p.icon as any} size={22} color={Colors.primary} />
                  </View>
                  <Text style={styles.popularTitle} numberOfLines={1}>{p.title}</Text>
                  <Text style={styles.popularSub} numberOfLines={1}>{p.subtitle}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </ScrollView>
      ) : null}

      {/* ── Vehicle choice panel ── */}
      {step === 'choose' || step === 'confirm' ? (
        <Animated.View
          style={[
            styles.choosePanel,
            { transform: [{ translateY: panelSlide }], opacity: panelOpacity },
          ]}
        >
          <View style={styles.panelHandle} />

          {/* Route summary */}
          <View style={styles.routeSummary}>
            <View style={styles.routeSummaryItem}>
              <View style={[styles.routeDot, { backgroundColor: Colors.primary }]} />
              <Text style={styles.routeSummaryText} numberOfLines={1}>{fromText}</Text>
            </View>
            <View style={styles.routeConnectorWrap}>
              <View style={styles.routeConnector} />
            </View>
            <View style={styles.routeSummaryItem}>
              <View style={[styles.routeDot, { backgroundColor: Colors.error }]} />
              <Text style={styles.routeSummaryText} numberOfLines={1}>{toText}</Text>
            </View>
            <View style={styles.routeStats}>
              <Text style={styles.routeStatText}>~{estimatedDistanceKm} كم</Text>
              <Text style={styles.routeStatDot}>·</Text>
              <Text style={styles.routeStatText}>~{estimatedDurationMin} دقيقة</Text>
            </View>
          </View>

          <ScrollView showsVerticalScrollIndicator={false}>
            {/* Vehicle options */}
            <Text style={styles.choosePanelTitle}>اختر نوع المركبة</Text>
            {VEHICLE_ORDER.map(vType => {
              const fare = getFare(vType);
              const isSelected = selectedVehicle === vType;
              const color = VEHICLE_COLOR[vType];
              const driver = MOCK_DRIVERS.find(d => d.vehicleType === vType);
              return (
                <TouchableOpacity
                  key={vType}
                  style={[
                    styles.vehicleOption,
                    isSelected && [styles.vehicleOptionSelected, { borderColor: color + '60', backgroundColor: color + '08' }],
                  ]}
                  onPress={() => handleVehicleSelect(vType)}
                  activeOpacity={0.88}
                >
                  {isSelected ? (
                    <View style={[styles.vehicleSelectedIndicator, { backgroundColor: color }]} />
                  ) : null}

                  <View style={styles.vehicleOptionLeft}>
                    <Text style={[styles.vehicleFare, { color }]}>
                      {fare.formattedPrice}
                    </Text>
                    {driver ? (
                      <View style={styles.etaRow}>
                        <MaterialIcons name="access-time" size={11} color={Colors.textTertiary} />
                        <Text style={styles.etaText}>{driver.eta} د</Text>
                      </View>
                    ) : null}
                  </View>

                  <View style={styles.vehicleOptionMid}>
                    <Text style={styles.vehicleOptionName}>{VEHICLE_LABELS[vType]}</Text>
                    <Text style={styles.vehicleOptionDesc}>{VEHICLE_DESC[vType]}</Text>
                    {fare.appliedPeakLabel ? (
                      <View style={styles.peakBadge}>
                        <MaterialIcons name="flash-on" size={10} color={Colors.warning} />
                        <Text style={styles.peakBadgeText}>{fare.appliedPeakLabel}</Text>
                      </View>
                    ) : null}
                  </View>

                  <View style={[styles.vehicleIconBg, { backgroundColor: color + '18', borderColor: color + '30' }]}>
                    <Text style={styles.vehicleEmoji}>{VEHICLE_ICONS[vType]}</Text>
                  </View>
                </TouchableOpacity>
              );
            })}

            {/* Payment method */}
            <Text style={styles.choosePanelTitle}>طريقة الدفع</Text>
            <View style={styles.paymentRow}>
              {PAYMENT_OPTIONS.map(p => (
                <TouchableOpacity
                  key={p.id}
                  style={[styles.payOption, selectedPayment === p.id && styles.payOptionSelected]}
                  onPress={() => setSelectedPayment(p.id)}
                >
                  <MaterialIcons
                    name={p.icon as any}
                    size={18}
                    color={selectedPayment === p.id ? Colors.primary : Colors.textSecondary}
                  />
                  <Text style={[styles.payOptionLabel, selectedPayment === p.id && { color: Colors.primary }]}>
                    {p.label}
                  </Text>
                  {p.balance ? (
                    <Text style={styles.payOptionBalance}>{p.balance}</Text>
                  ) : null}
                </TouchableOpacity>
              ))}
            </View>

            {/* Confirm button */}
            <View style={[styles.confirmRow, { paddingBottom: insets.bottom + 16 }]}>
              <TouchableOpacity
                style={styles.confirmBtn}
                onPress={step === 'choose' ? handleConfirmRide : handleBookRide}
                disabled={isBooking}
                activeOpacity={0.88}
              >
                <LinearGradient
                  colors={[Colors.primary, Colors.primaryDark]}
                  style={styles.confirmBtnGrad}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                >
                  {isBooking ? (
                    <ActivityIndicator color={Colors.textInverse} />
                  ) : (
                    <>
                      <MaterialIcons name="directions-car" size={20} color={Colors.textInverse} />
                      <Text style={styles.confirmBtnText}>
                        {step === 'choose'
                          ? `تأكيد الحجز · ${selectedFare.formattedPrice}`
                          : `احجز الآن · ${selectedFare.formattedPrice}`}
                      </Text>
                    </>
                  )}
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </Animated.View>
      ) : null}

      {/* Confirm overlay with driver preview */}
      {step === 'confirm' ? (
        <Animated.View
          style={[
            styles.confirmOverlay,
            { opacity: confirmOpacity, transform: [{ translateY: confirmSlide }] },
          ]}
        >
          <LinearGradient
            colors={['#0D2B1E', Colors.card]}
            style={styles.confirmCard}
          >
            <View style={styles.panelHandle} />
            <Text style={styles.confirmTitle}>تأكيد الحجز</Text>

            {/* Driver preview */}
            <View style={styles.driverPreviewRow}>
              <View style={styles.driverPreviewInfo}>
                <Text style={styles.driverPreviewName}>{selectedDriver.name}</Text>
                <View style={styles.driverPreviewMeta}>
                  <MaterialIcons name="star" size={13} color={Colors.gold} />
                  <Text style={styles.driverPreviewRating}>{selectedDriver.rating}</Text>
                  <Text style={styles.driverPreviewRides}>({selectedDriver.totalRides} رحلة)</Text>
                </View>
                <Text style={styles.driverPreviewPlate}>{selectedDriver.vehiclePlate}</Text>
              </View>
              <Image
                source={{ uri: selectedDriver.avatar }}
                style={styles.driverPreviewAvatar}
                contentFit="cover"
              />
            </View>

            {/* Price breakdown */}
            <View style={styles.priceBreakdownCard}>
              <View style={styles.priceRow}>
                <Text style={styles.priceVal}>{selectedFare.formattedPrice}</Text>
                <Text style={styles.priceLabel}>الإجمالي</Text>
              </View>
              <View style={styles.priceBreakDivider} />
              <View style={styles.priceDetailRow}>
                <Text style={styles.priceDetailVal}>{selectedFare.baseFare.toFixed(1)} ج.م</Text>
                <Text style={styles.priceDetailLabel}>أجرة البداية</Text>
              </View>
              <View style={styles.priceDetailRow}>
                <Text style={styles.priceDetailVal}>{selectedFare.distanceFare.toFixed(1)} ج.م</Text>
                <Text style={styles.priceDetailLabel}>رسوم المسافة</Text>
              </View>
              {selectedFare.appliedPeakLabel ? (
                <View style={styles.peakRow}>
                  <View style={styles.peakChip}>
                    <MaterialIcons name="flash-on" size={11} color={Colors.warning} />
                    <Text style={styles.peakChipText}>{selectedFare.appliedPeakLabel} ×{selectedFare.peakMultiplier}</Text>
                  </View>
                </View>
              ) : null}
            </View>

            {/* Payment */}
            <View style={styles.confirmPayRow}>
              <MaterialIcons name="account-balance-wallet" size={16} color={Colors.primary} />
              <Text style={styles.confirmPayText}>
                الدفع عبر {PAYMENT_OPTIONS.find(p => p.id === selectedPayment)?.label}
              </Text>
            </View>

            {/* Buttons */}
            <View style={[styles.confirmButtons, { paddingBottom: insets.bottom + 8 }]}>
              <TouchableOpacity
                style={styles.confirmBackBtn}
                onPress={() => setStep('choose')}
              >
                <Text style={styles.confirmBackBtnText}>تغيير</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.confirmBookBtn}
                onPress={handleBookRide}
                disabled={isBooking}
                activeOpacity={0.88}
              >
                <LinearGradient
                  colors={[Colors.primary, Colors.primaryDark]}
                  style={styles.confirmBookBtnGrad}
                >
                  {isBooking ? (
                    <ActivityIndicator color={Colors.textInverse} />
                  ) : (
                    <>
                      <MaterialIcons name="check" size={18} color={Colors.textInverse} />
                      <Text style={styles.confirmBookBtnText}>احجز الآن</Text>
                    </>
                  )}
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </LinearGradient>
        </Animated.View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },

  // Header
  header: {
    paddingHorizontal: Spacing.base,
    paddingBottom: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
    gap: Spacing.md,
  },
  headerRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: Spacing.sm,
  },
  backBtn: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: Colors.card, justifyContent: 'center', alignItems: 'center',
    borderWidth: 1, borderColor: Colors.border,
  },
  headerTitle: { fontSize: 18, fontWeight: Fonts.bold as any, color: Colors.text },

  // Search card
  searchCard: {
    backgroundColor: Colors.card,
    borderRadius: Radius.xl,
    borderWidth: 1,
    borderColor: Colors.border,
    overflow: 'hidden',
    gap: 0,
    ...Shadow.sm,
  },
  searchField: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: Spacing.sm,
    paddingHorizontal: Spacing.base,
    paddingVertical: 14,
  },
  searchFieldActive: { backgroundColor: Colors.primary + '06' },
  dotFrom: {
    width: 10, height: 10, borderRadius: 5,
    backgroundColor: Colors.primary,
    borderWidth: 2, borderColor: Colors.primary + '40',
  },
  dotTo: {
    width: 10, height: 10, borderRadius: 5,
    backgroundColor: Colors.error,
    borderWidth: 2, borderColor: Colors.error + '40',
  },
  searchText: { flex: 1, fontSize: 15, textAlign: 'right' },
  searchTextFilled: { color: Colors.text, fontWeight: Fonts.medium as any },
  searchTextPlaceholder: { color: Colors.textTertiary },
  searchInput: { flex: 1, fontSize: 15, color: Colors.text, textAlign: 'right', padding: 0 },

  swapRow: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: Spacing.base,
    gap: 8,
  },
  swapLine: { flex: 1, height: 1, backgroundColor: Colors.border },
  swapBtn: {
    width: 28, height: 28, borderRadius: 14,
    backgroundColor: Colors.primaryFaded, justifyContent: 'center', alignItems: 'center',
    borderWidth: 1, borderColor: Colors.primary + '30',
  },

  searchBtn: { borderRadius: Radius.md, overflow: 'hidden', ...Shadow.glow },
  searchBtnGrad: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center',
    gap: 8, paddingVertical: 14,
  },
  searchBtnText: { color: Colors.textInverse, fontSize: 15, fontWeight: Fonts.bold as any },

  // Suggestions
  suggestionsContainer: {
    position: 'absolute', top: 0, left: 0, right: 0,
    marginTop: 180, zIndex: 100,
    backgroundColor: Colors.surface,
    borderBottomLeftRadius: Radius.xl,
    borderBottomRightRadius: Radius.xl,
    maxHeight: 300,
    borderWidth: 1,
    borderColor: Colors.border,
    ...Shadow.lg,
  },
  searchingRow: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: 8,
    padding: Spacing.base,
  },
  searchingText: { color: Colors.textSecondary, fontSize: 14 },
  suggestionItem: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.md,
    paddingHorizontal: Spacing.base, paddingVertical: 13,
  },
  suggestionIconBg: {
    width: 38, height: 38, borderRadius: 12,
    backgroundColor: Colors.primaryFaded, justifyContent: 'center', alignItems: 'center',
    borderWidth: 1, borderColor: Colors.primary + '20',
  },
  suggestionInfo: { flex: 1, alignItems: 'flex-end', gap: 2 },
  suggestionTitle: { fontSize: 14, fontWeight: Fonts.medium as any, color: Colors.text },
  suggestionSub: { fontSize: 12, color: Colors.textTertiary },

  // Default content
  defaultContent: { padding: Spacing.base, gap: Spacing.xl, paddingBottom: 60 },
  sectionBlock: { gap: Spacing.sm },
  sectionTitle: { fontSize: 14, fontWeight: Fonts.semibold as any, color: Colors.textSecondary, textAlign: 'right' },
  placeItem: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.md,
    backgroundColor: Colors.card, borderRadius: Radius.lg, padding: Spacing.md,
    borderWidth: 1, borderColor: Colors.border,
  },
  placeIconBg: { width: 40, height: 40, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  placeInfo: { flex: 1, alignItems: 'flex-end', gap: 2 },
  placeTitle: { fontSize: 14, fontWeight: Fonts.semibold as any, color: Colors.text },
  placeSub: { fontSize: 12, color: Colors.textTertiary },
  popularGrid: { flexDirection: 'row-reverse', flexWrap: 'wrap', gap: Spacing.sm },
  popularCard: {
    width: (width - Spacing.base * 2 - Spacing.sm) / 2,
    backgroundColor: Colors.card, borderRadius: Radius.lg, padding: Spacing.md,
    gap: 6, alignItems: 'center', borderWidth: 1, borderColor: Colors.border,
  },
  popularIconBg: { width: 44, height: 44, borderRadius: 14, justifyContent: 'center', alignItems: 'center' },
  popularTitle: { fontSize: 13, fontWeight: Fonts.semibold as any, color: Colors.text },
  popularSub: { fontSize: 11, color: Colors.textTertiary },

  // Choose panel
  choosePanel: {
    position: 'absolute', bottom: 0, left: 0, right: 0,
    backgroundColor: Colors.surface,
    borderTopLeftRadius: Radius.xxl,
    borderTopRightRadius: Radius.xxl,
    maxHeight: '78%',
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    paddingHorizontal: Spacing.base,
    paddingTop: Spacing.sm,
    ...Shadow.lg,
  },
  panelHandle: {
    width: 40, height: 4, borderRadius: 2,
    backgroundColor: Colors.border, alignSelf: 'center', marginBottom: Spacing.md,
  },

  // Route summary
  routeSummary: {
    backgroundColor: Colors.card, borderRadius: Radius.lg, padding: Spacing.md,
    gap: 6, marginBottom: Spacing.md, borderWidth: 1, borderColor: Colors.border,
  },
  routeSummaryItem: { flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.sm },
  routeDot: { width: 8, height: 8, borderRadius: 4 },
  routeSummaryText: { flex: 1, fontSize: 13, color: Colors.textSecondary, textAlign: 'right' },
  routeConnectorWrap: { paddingRight: 3 },
  routeConnector: { width: 2, height: 14, backgroundColor: Colors.border, marginRight: 3 },
  routeStats: {
    flexDirection: 'row', gap: 6, justifyContent: 'flex-end',
    marginTop: 4, paddingRight: 3,
  },
  routeStatText: { fontSize: 11, color: Colors.textTertiary },
  routeStatDot: { fontSize: 11, color: Colors.textTertiary },

  choosePanelTitle: {
    fontSize: 14, fontWeight: Fonts.semibold as any, color: Colors.textSecondary,
    textAlign: 'right', marginBottom: Spacing.sm, marginTop: Spacing.sm,
  },

  // Vehicle option
  vehicleOption: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.md,
    backgroundColor: Colors.card, borderRadius: Radius.xl, padding: Spacing.base,
    marginBottom: Spacing.sm, borderWidth: 1.5, borderColor: Colors.border,
    position: 'relative', overflow: 'hidden',
  },
  vehicleOptionSelected: {},
  vehicleSelectedIndicator: {
    position: 'absolute', top: 0, bottom: 0, right: 0, width: 4,
    borderTopRightRadius: Radius.xl, borderBottomRightRadius: Radius.xl,
  },
  vehicleIconBg: {
    width: 54, height: 54, borderRadius: 14,
    justifyContent: 'center', alignItems: 'center',
    borderWidth: 1,
  },
  vehicleEmoji: { fontSize: 26 },
  vehicleOptionMid: { flex: 1, alignItems: 'flex-end', gap: 3 },
  vehicleOptionName: { fontSize: 15, fontWeight: Fonts.bold as any, color: Colors.text },
  vehicleOptionDesc: { fontSize: 12, color: Colors.textSecondary },
  peakBadge: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: 3,
    backgroundColor: Colors.warningFaded, borderRadius: Radius.full,
    paddingHorizontal: 7, paddingVertical: 2,
  },
  peakBadgeText: { fontSize: 10, color: Colors.warning, fontWeight: Fonts.medium as any },
  vehicleOptionLeft: { alignItems: 'flex-start', gap: 4 },
  vehicleFare: { fontSize: 17, fontWeight: Fonts.extrabold as any },
  etaRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 3 },
  etaText: { fontSize: 11, color: Colors.textTertiary },

  // Payment row
  paymentRow: { flexDirection: 'row-reverse', gap: Spacing.sm, marginBottom: Spacing.base },
  payOption: {
    flex: 1, alignItems: 'center', gap: 4, padding: Spacing.sm,
    borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.border,
    backgroundColor: Colors.card,
  },
  payOptionSelected: { borderColor: Colors.primary + '60', backgroundColor: Colors.primaryFaded },
  payOptionLabel: { fontSize: 11, color: Colors.textSecondary, textAlign: 'center' },
  payOptionBalance: { fontSize: 10, color: Colors.primary, fontWeight: Fonts.semibold as any },

  // Confirm row
  confirmRow: { gap: Spacing.sm },
  confirmBtn: { borderRadius: Radius.lg, overflow: 'hidden', ...Shadow.glow },
  confirmBtnGrad: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center',
    gap: 8, paddingVertical: 16,
  },
  confirmBtnText: { color: Colors.textInverse, fontSize: 16, fontWeight: Fonts.bold as any },

  // Confirm overlay
  confirmOverlay: {
    position: 'absolute', bottom: 0, left: 0, right: 0, zIndex: 50,
  },
  confirmCard: {
    borderTopLeftRadius: Radius.xxl,
    borderTopRightRadius: Radius.xxl,
    padding: Spacing.base,
    paddingTop: Spacing.sm,
    borderTopWidth: 1,
    borderTopColor: Colors.primary + '30',
    ...Shadow.lg,
  },
  confirmTitle: {
    fontSize: 18, fontWeight: Fonts.bold as any, color: Colors.text,
    textAlign: 'center', marginBottom: Spacing.md,
  },

  // Driver preview
  driverPreviewRow: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.md,
    backgroundColor: Colors.surface, borderRadius: Radius.lg, padding: Spacing.md,
    borderWidth: 1, borderColor: Colors.border, marginBottom: Spacing.md,
  },
  driverPreviewAvatar: { width: 56, height: 56, borderRadius: 28, borderWidth: 2, borderColor: Colors.primary },
  driverPreviewInfo: { flex: 1, alignItems: 'flex-end', gap: 4 },
  driverPreviewName: { fontSize: 16, fontWeight: Fonts.bold as any, color: Colors.text },
  driverPreviewMeta: { flexDirection: 'row-reverse', alignItems: 'center', gap: 4 },
  driverPreviewRating: { fontSize: 13, color: Colors.gold, fontWeight: Fonts.semibold as any },
  driverPreviewRides: { fontSize: 12, color: Colors.textTertiary },
  driverPreviewPlate: { fontSize: 12, color: Colors.textSecondary },

  // Price breakdown
  priceBreakdownCard: {
    backgroundColor: Colors.card, borderRadius: Radius.lg, padding: Spacing.md,
    borderWidth: 1, borderColor: Colors.border, gap: 6, marginBottom: Spacing.md,
  },
  priceRow: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between',
  },
  priceLabel: { fontSize: 13, color: Colors.textSecondary },
  priceVal: { fontSize: 22, fontWeight: Fonts.extrabold as any, color: Colors.primary },
  priceBreakDivider: { height: 1, backgroundColor: Colors.border },
  priceDetailRow: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between' },
  priceDetailLabel: { fontSize: 12, color: Colors.textTertiary },
  priceDetailVal: { fontSize: 13, color: Colors.textSecondary },
  peakRow: { alignItems: 'flex-end' },
  peakChip: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: 3,
    backgroundColor: Colors.warningFaded, borderRadius: Radius.full,
    paddingHorizontal: 8, paddingVertical: 3,
  },
  peakChipText: { fontSize: 11, color: Colors.warning },

  // Confirm pay
  confirmPayRow: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: 6,
    backgroundColor: Colors.primaryFaded, borderRadius: Radius.md, padding: Spacing.sm,
    borderWidth: 1, borderColor: Colors.primary + '30', marginBottom: Spacing.md,
    justifyContent: 'center',
  },
  confirmPayText: { fontSize: 13, color: Colors.primary, fontWeight: Fonts.medium as any },

  // Confirm buttons
  confirmButtons: { flexDirection: 'row-reverse', gap: Spacing.sm },
  confirmBackBtn: {
    flex: 0.7, paddingVertical: 15, borderRadius: Radius.md,
    backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border,
    alignItems: 'center',
  },
  confirmBackBtnText: { color: Colors.textSecondary, fontSize: 14, fontWeight: Fonts.medium as any },
  confirmBookBtn: { flex: 1.5, borderRadius: Radius.md, overflow: 'hidden', ...Shadow.glow },
  confirmBookBtnGrad: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center',
    gap: 8, paddingVertical: 15,
  },
  confirmBookBtnText: { color: Colors.textInverse, fontSize: 15, fontWeight: Fonts.bold as any },
});
