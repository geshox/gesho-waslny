// Powered by OnSpace.AI
import React, { useEffect, useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Alert,
  Platform,
  ScrollView,
} from 'react-native';
import { Image } from 'expo-image';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Spacing, Radius, Fonts, Shadow } from '@/constants/theme';
import { useRide } from '@/hooks/useRide';
import { VEHICLE_ICONS, VEHICLE_LABELS } from '@/constants/mockData';

const STATUS_INFO: Record<string, { title: string; subtitle: string; color: string; icon: string }> = {
  searching: {
    title: 'جارٍ البحث عن سائق...',
    subtitle: 'يرجى الانتظار قليلاً',
    color: Colors.accent,
    icon: 'search',
  },
  driver_assigned: {
    title: 'تم تعيين السائق',
    subtitle: 'السائق قبل طلبك',
    color: Colors.primary,
    icon: 'check-circle',
  },
  driver_arriving: {
    title: 'السائق في الطريق إليك',
    subtitle: 'السائق يتجه نحو موقعك',
    color: Colors.gold,
    icon: 'directions',
  },
  in_progress: {
    title: 'الرحلة جارية',
    subtitle: 'في طريقك إلى وجهتك',
    color: Colors.success,
    icon: 'navigation',
  },
};

// SOS overlay state
function SOSModal({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  if (!visible) return null;
  return (
    <View style={sos.overlay}>
      <View style={sos.card}>
        <LinearGradient colors={['#FF1A1A', '#8B0000']} style={sos.iconBg}>
          <MaterialIcons name="sos" size={40} color="#fff" />
        </LinearGradient>
        <Text style={sos.title}>نداء استغاثة (SOS)</Text>
        <Text style={sos.desc}>
          سيتم إرسال موقعك الحالي ومعلومات الرحلة فوراً إلى جهات الطوارئ وعائلتك المسجّلة.
        </Text>
        <View style={sos.actions}>
          <TouchableOpacity style={sos.cancelBtn} onPress={onClose}>
            <Text style={sos.cancelText}>إلغاء</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={sos.confirmBtn}
            onPress={() => {
              onClose();
              if (Platform.OS !== 'web')
                Alert.alert('SOS', 'تم إرسال موقعك لجهات الطوارئ');
            }}
          >
            <LinearGradient colors={['#EF4444', '#B91C1C']} style={sos.confirmGradient}>
              <Text style={sos.confirmText}>إرسال SOS الآن</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const sos = StyleSheet.create({
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.85)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 999,
    padding: Spacing.base,
  },
  card: {
    backgroundColor: '#0F1220',
    borderRadius: Radius.xl,
    padding: Spacing.xl,
    alignItems: 'center',
    gap: Spacing.md,
    borderWidth: 1.5,
    borderColor: '#EF4444',
    width: '100%',
  },
  iconBg: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: Spacing.sm,
  },
  title: {
    fontSize: 22,
    fontWeight: Fonts.bold as any,
    color: '#F1F5F9',
    textAlign: 'center',
  },
  desc: {
    fontSize: 14,
    color: '#94A3B8',
    textAlign: 'center',
    lineHeight: 22,
  },
  actions: { flexDirection: 'row-reverse', gap: Spacing.sm, width: '100%' },
  cancelBtn: {
    flex: 1,
    paddingVertical: 14,
    borderRadius: Radius.md,
    backgroundColor: '#1E293B',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#334155',
  },
  cancelText: { color: '#94A3B8', fontSize: 14, fontWeight: Fonts.medium as any },
  confirmBtn: { flex: 1.5, borderRadius: Radius.md, overflow: 'hidden' },
  confirmGradient: { paddingVertical: 14, alignItems: 'center' },
  confirmText: { color: '#fff', fontSize: 15, fontWeight: Fonts.bold as any },
});

export default function ActiveRideScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { activeRide, rideStatus, cancelRide, completeRide } = useRide();

  const [elapsed, setElapsed] = useState(0);
  const [eta, setEta] = useState(activeRide?.estimatedArrival ?? 8);
  const [sosVisible, setSosVisible] = useState(false);

  // animations
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const carXAnim = useRef(new Animated.Value(0)).current;
  const carYAnim = useRef(new Animated.Value(0)).current;

  // elapsed timer
  useEffect(() => {
    const t = setInterval(() => setElapsed(e => e + 1), 1000);
    return () => clearInterval(t);
  }, []);

  // ETA countdown
  useEffect(() => {
    if (eta <= 0) return;
    const t = setInterval(() => setEta(e => Math.max(0, e - 1 / 60)), 1000);
    return () => clearInterval(t);
  }, []);

  // pulse animation for waiting states
  useEffect(() => {
    if (rideStatus === 'searching' || rideStatus === 'driver_assigned') {
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, { toValue: 1.25, duration: 750, useNativeDriver: true }),
          Animated.timing(pulseAnim, { toValue: 1, duration: 750, useNativeDriver: true }),
        ])
      ).start();
    } else {
      pulseAnim.setValue(1);
    }
  }, [rideStatus]);

  // car-moving animation
  useEffect(() => {
    if (rideStatus === 'in_progress' || rideStatus === 'driver_arriving') {
      Animated.loop(
        Animated.sequence([
          Animated.timing(carXAnim, { toValue: 30, duration: 2000, useNativeDriver: true }),
          Animated.timing(carXAnim, { toValue: -15, duration: 1500, useNativeDriver: true }),
          Animated.timing(carXAnim, { toValue: 0, duration: 1000, useNativeDriver: true }),
        ])
      ).start();
    }
  }, [rideStatus]);

  const formatClock = (seconds: number) => {
    const m = Math.floor(seconds / 60).toString().padStart(2, '0');
    const s = (seconds % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  const handleCancel = () => {
    if (Platform.OS !== 'web') {
      Alert.alert('إلغاء الرحلة', 'هل تريد إلغاء هذه الرحلة؟', [
        { text: 'لا', style: 'cancel' },
        { text: 'نعم، إلغاء', style: 'destructive', onPress: () => { cancelRide(); router.back(); } },
      ]);
    } else {
      cancelRide();
      router.back();
    }
  };

  const handleComplete = () => {
    completeRide();
    router.replace('/ride/rating');
  };

  if (!activeRide && rideStatus !== 'searching') {
    return (
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <View style={styles.noRide}>
          <MaterialIcons name="directions-car" size={64} color={Colors.textTertiary} />
          <Text style={styles.noRideText}>لا توجد رحلة نشطة</Text>
          <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
            <Text style={styles.backBtnText}>العودة للرئيسية</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  const currentStatus = STATUS_INFO[rideStatus] || STATUS_INFO.searching;
  const driver = activeRide?.driver;

  return (
    <View style={[styles.container, { paddingBottom: insets.bottom }]}>
      <SOSModal visible={sosVisible} onClose={() => setSosVisible(false)} />

      {/* ── Live Map Area ── */}
      <View style={styles.mapArea}>
        <LinearGradient
          colors={['#060D1A', '#0D1A2E', '#06121F']}
          style={StyleSheet.absoluteFill}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        />

        {/* Star field */}
        {[...Array(18)].map((_, i) => (
          <View
            key={i}
            style={[
              styles.star,
              {
                top: `${5 + (i * 31 % 85)}%` as any,
                left: `${(i * 47 % 90)}%` as any,
                width: i % 3 === 0 ? 3 : 2,
                height: i % 3 === 0 ? 3 : 2,
                opacity: 0.3 + (i % 5) * 0.1,
              },
            ]}
          />
        ))}

        {/* Road grid */}
        {[15, 38, 60, 80].map(pct => (
          <View key={`h${pct}`} style={[styles.roadH, { top: `${pct}%` as any }]} />
        ))}
        {[20, 42, 65, 85].map(pct => (
          <View key={`v${pct}`} style={[styles.roadV, { left: `${pct}%` as any }]} />
        ))}

        {/* Route line with dashes */}
        <View style={styles.routeLineOuter}>
          {[...Array(8)].map((_, i) => (
            <View key={i} style={styles.routeDash} />
          ))}
        </View>

        {/* Destination pin with pulse rings */}
        <View style={styles.destContainer}>
          <Animated.View style={styles.destRing2} />
          <Animated.View style={styles.destRing1} />
          <View style={styles.destPinBg}>
            <MaterialIcons name="flag" size={20} color="#EF4444" />
          </View>
        </View>

        {/* Animated driver vehicle */}
        <Animated.View
          style={[
            styles.driverPinWrapper,
            { transform: [{ scale: pulseAnim }, { translateX: carXAnim }] },
          ]}
        >
          <LinearGradient
            colors={[currentStatus.color, currentStatus.color + 'BB']}
            style={styles.driverPinGradient}
          >
            <Text style={styles.driverPinEmoji}>
              {driver ? VEHICLE_ICONS[driver.vehicleType] : '🚗'}
            </Text>
          </LinearGradient>
          {/* Glow ring */}
          <View style={[styles.driverGlow, { shadowColor: currentStatus.color }]} />
        </Animated.View>

        {/* Top status bar */}
        <View style={styles.statusBar}>
          <View style={[styles.statusPill, { borderColor: currentStatus.color + '50', backgroundColor: currentStatus.color + '18' }]}>
            <MaterialIcons name={currentStatus.icon as any} size={15} color={currentStatus.color} />
            <Text style={[styles.statusPillText, { color: currentStatus.color }]}>
              {currentStatus.title}
            </Text>
          </View>
        </View>

        {/* ETA badge */}
        <View style={styles.etaBadge}>
          <Text style={styles.etaValue}>{Math.ceil(eta)}</Text>
          <Text style={styles.etaUnit}>دقيقة</Text>
        </View>

        {/* SOS button on map */}
        <TouchableOpacity style={styles.sosMapBtn} onPress={() => setSosVisible(true)}>
          <LinearGradient colors={['#EF4444', '#B91C1C']} style={styles.sosMapBtnGradient}>
            <Text style={styles.sosMapBtnText}>SOS</Text>
          </LinearGradient>
        </TouchableOpacity>
      </View>

      {/* ── Bottom Panel ── */}
      <View style={styles.bottomPanel}>

        {/* Trip stats row */}
        <View style={styles.statsRow}>
          <View style={styles.statItem}>
            <MaterialIcons name="attach-money" size={16} color={Colors.primary} />
            <Text style={styles.statValue}>{activeRide?.price || 0} ج.م</Text>
            <Text style={styles.statLabel}>التكلفة</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <MaterialIcons name="timer" size={16} color={Colors.accent} />
            <Text style={styles.statValue}>{formatClock(elapsed)}</Text>
            <Text style={styles.statLabel}>الوقت</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <MaterialIcons name="navigation" size={16} color={Colors.gold} />
            <Text style={styles.statValue}>{Math.ceil(eta)} د</Text>
            <Text style={styles.statLabel}>الوصول</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <MaterialIcons name="directions" size={16} color={Colors.textSecondary} />
            <Text style={styles.statValue}>{activeRide?.distance?.toFixed(1) ?? '—'} كم</Text>
            <Text style={styles.statLabel}>المسافة</Text>
          </View>
        </View>

        {/* Driver card */}
        {driver ? (
          <View style={styles.driverCard}>
            <View style={styles.driverActions}>
              <TouchableOpacity style={[styles.driverActionBtn, styles.callBtn]}>
                <MaterialIcons name="phone" size={18} color={Colors.primary} />
              </TouchableOpacity>
              <TouchableOpacity style={[styles.driverActionBtn, styles.chatBtn]} onPress={() => router.push('/ride/chat')}>
                <MaterialIcons name="chat-bubble" size={18} color={Colors.accent} />
              </TouchableOpacity>
            </View>

            <View style={styles.driverInfo}>
              <View style={styles.driverMeta}>
                <View style={styles.ratingRow}>
                  <MaterialIcons name="star" size={13} color={Colors.gold} />
                  <Text style={styles.ratingText}>{driver.rating}</Text>
                </View>
                <Text style={styles.driverName}>{driver.name}</Text>
              </View>
              <Text style={styles.plateText}>
                {VEHICLE_ICONS[driver.vehicleType]} {driver.vehiclePlate} · {VEHICLE_LABELS[driver.vehicleType]}
              </Text>
            </View>

            <View style={styles.avatarWrapper}>
              <Image source={{ uri: driver.avatar }} style={styles.driverAvatar} contentFit="cover" />
              <View style={[styles.onlineDot]} />
            </View>
          </View>
        ) : null}

        {/* Route */}
        <View style={styles.routeCard}>
          <View style={styles.routeRow}>
            <View style={[styles.routeDot, { backgroundColor: Colors.primary }]} />
            <Text style={styles.routeText} numberOfLines={1}>{activeRide?.from ?? 'موقعك الحالي'}</Text>
          </View>
          <View style={styles.routeConnector} />
          <View style={styles.routeRow}>
            <View style={[styles.routeDot, { backgroundColor: Colors.error }]} />
            <Text style={styles.routeText} numberOfLines={1}>{activeRide?.to ?? 'الوجهة'}</Text>
          </View>
        </View>

        {/* Action buttons */}
        <View style={styles.actionsRow}>
          {rideStatus !== 'in_progress' ? (
            <TouchableOpacity style={styles.cancelBtn} onPress={handleCancel}>
              <MaterialIcons name="close" size={18} color={Colors.error} />
              <Text style={styles.cancelText}>إلغاء الرحلة</Text>
            </TouchableOpacity>
          ) : null}

          {rideStatus === 'in_progress' ? (
            <TouchableOpacity style={styles.completeBtn} onPress={handleComplete}>
              <LinearGradient
                colors={[Colors.primary, Colors.primaryDark]}
                style={styles.completeBtnGradient}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
              >
                <MaterialIcons name="flag" size={18} color={Colors.textInverse} />
                <Text style={styles.completeBtnText}>إتمام الرحلة</Text>
              </LinearGradient>
            </TouchableOpacity>
          ) : (
            <View style={[styles.waitingBadge, { borderColor: currentStatus.color + '40', backgroundColor: currentStatus.color + '12' }]}>
              <MaterialIcons name={currentStatus.icon as any} size={16} color={currentStatus.color} />
              <Text style={[styles.waitingText, { color: currentStatus.color }]}>
                {currentStatus.subtitle}
              </Text>
            </View>
          )}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },

  // ── Map ──────────────────────────────────
  mapArea: {
    flex: 1,
    position: 'relative',
    overflow: 'hidden',
  },
  star: {
    position: 'absolute',
    backgroundColor: '#fff',
    borderRadius: 2,
  },
  roadH: {
    position: 'absolute',
    left: 0,
    right: 0,
    height: 1.5,
    backgroundColor: 'rgba(30,45,70,0.9)',
  },
  roadV: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    width: 1.5,
    backgroundColor: 'rgba(30,45,70,0.9)',
  },
  routeLineOuter: {
    position: 'absolute',
    flexDirection: 'row',
    left: '26%',
    right: '28%',
    top: '43%',
    alignItems: 'center',
    gap: 4,
    transform: [{ rotate: '-8deg' }],
  },
  routeDash: {
    flex: 1,
    height: 3,
    backgroundColor: Colors.primary,
    borderRadius: 2,
    opacity: 0.7,
  },
  destContainer: {
    position: 'absolute',
    right: '25%',
    top: '22%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  destRing2: {
    position: 'absolute',
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: 'rgba(239,68,68,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.2)',
  },
  destRing1: {
    position: 'absolute',
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: 'rgba(239,68,68,0.14)',
  },
  destPinBg: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(239,68,68,0.22)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: '#EF4444',
  },
  driverPinWrapper: {
    position: 'absolute',
    left: '32%',
    top: '48%',
    width: 54,
    height: 54,
    borderRadius: 27,
    overflow: 'visible',
    borderWidth: 2.5,
    borderColor: Colors.background,
    shadowColor: Colors.primary,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 12,
    elevation: 10,
  },
  driverPinGradient: {
    flex: 1,
    borderRadius: 27,
    justifyContent: 'center',
    alignItems: 'center',
  },
  driverPinEmoji: { fontSize: 22 },
  driverGlow: {
    position: 'absolute',
    top: -6,
    left: -6,
    right: -6,
    bottom: -6,
    borderRadius: 33,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 14,
  },
  statusBar: {
    position: 'absolute',
    top: 16,
    left: 16,
    right: 16,
    alignItems: 'center',
  },
  statusPill: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 8,
    borderRadius: Radius.full,
    paddingHorizontal: 18,
    paddingVertical: 10,
    borderWidth: 1,
    backgroundColor: Colors.surface,
    ...Shadow.md,
  },
  statusPillText: {
    fontSize: 14,
    fontWeight: Fonts.semibold as any,
  },
  etaBadge: {
    position: 'absolute',
    bottom: 20,
    left: 20,
    backgroundColor: Colors.card,
    borderRadius: Radius.lg,
    paddingHorizontal: 16,
    paddingVertical: 10,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.gold + '40',
    ...Shadow.md,
  },
  etaValue: {
    fontSize: 22,
    fontWeight: Fonts.extrabold as any,
    color: Colors.gold,
  },
  etaUnit: {
    fontSize: 11,
    color: Colors.textTertiary,
  },
  sosMapBtn: {
    position: 'absolute',
    bottom: 20,
    right: 20,
    borderRadius: Radius.lg,
    overflow: 'hidden',
    ...Shadow.md,
  },
  sosMapBtnGradient: {
    paddingHorizontal: 18,
    paddingVertical: 12,
    alignItems: 'center',
  },
  sosMapBtnText: {
    color: '#fff',
    fontSize: 13,
    fontWeight: Fonts.extrabold as any,
    letterSpacing: 1,
  },

  // ── Bottom Panel ─────────────────────────
  bottomPanel: {
    backgroundColor: Colors.surface,
    borderTopLeftRadius: Radius.xxl,
    borderTopRightRadius: Radius.xxl,
    padding: Spacing.base,
    gap: Spacing.sm,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  statsRow: {
    flexDirection: 'row-reverse',
    backgroundColor: Colors.card,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.border,
    overflow: 'hidden',
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: Spacing.md,
    gap: 3,
  },
  statDivider: {
    width: 1,
    backgroundColor: Colors.border,
    marginVertical: 8,
  },
  statValue: {
    fontSize: 14,
    fontWeight: Fonts.bold as any,
    color: Colors.text,
  },
  statLabel: {
    fontSize: 10,
    color: Colors.textTertiary,
  },
  driverCard: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    backgroundColor: Colors.card,
    borderRadius: Radius.md,
    padding: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.border,
    gap: Spacing.md,
  },
  avatarWrapper: { position: 'relative' },
  driverAvatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    borderWidth: 2,
    borderColor: Colors.primary,
  },
  onlineDot: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: Colors.success,
    borderWidth: 2,
    borderColor: Colors.card,
  },
  driverInfo: { flex: 1, alignItems: 'flex-end', gap: 4 },
  driverMeta: { flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.sm },
  driverName: { fontSize: 15, fontWeight: Fonts.bold as any, color: Colors.text },
  ratingRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 3 },
  ratingText: { fontSize: 13, color: Colors.gold, fontWeight: Fonts.semibold as any },
  plateText: { fontSize: 12, color: Colors.textSecondary },
  driverActions: { flexDirection: 'column', gap: Spacing.sm },
  driverActionBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
  },
  callBtn: { borderColor: Colors.primary + '40', backgroundColor: Colors.primaryFaded },
  chatBtn: { borderColor: Colors.accent + '40', backgroundColor: Colors.accentFaded },
  routeCard: {
    backgroundColor: Colors.card,
    borderRadius: Radius.md,
    padding: Spacing.md,
    gap: 6,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  routeRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.sm },
  routeDot: { width: 8, height: 8, borderRadius: 4 },
  routeConnector: {
    width: 1,
    height: 14,
    backgroundColor: Colors.border,
    marginRight: 3.5,
  },
  routeText: {
    flex: 1,
    fontSize: 13,
    color: Colors.textSecondary,
    textAlign: 'right',
  },
  actionsRow: { flexDirection: 'row-reverse', gap: Spacing.sm },
  cancelBtn: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: Spacing.base,
    paddingVertical: 14,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.error + '40',
    backgroundColor: Colors.errorFaded,
  },
  cancelText: { color: Colors.error, fontSize: 14, fontWeight: Fonts.medium as any },
  completeBtn: { flex: 1, borderRadius: Radius.md, overflow: 'hidden', ...Shadow.glow },
  completeBtnGradient: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 15,
  },
  completeBtnText: { color: Colors.textInverse, fontSize: 15, fontWeight: Fonts.bold as any },
  waitingBadge: {
    flex: 1,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 15,
    borderRadius: Radius.md,
    borderWidth: 1,
  },
  waitingText: { fontSize: 14, fontWeight: Fonts.medium as any },
  noRide: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: Spacing.base },
  noRideText: { fontSize: 18, color: Colors.textSecondary },
  backBtn: {
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: Radius.md,
    backgroundColor: Colors.primaryFaded,
    borderWidth: 1,
    borderColor: Colors.primary + '40',
  },
  backBtnText: { color: Colors.primary, fontSize: 15, fontWeight: Fonts.semibold as any },
});
