// Powered by OnSpace.AI
import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  ActivityIndicator,
  Animated,
  Dimensions,
} from 'react-native';
import { Image } from 'expo-image';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Spacing, Radius, Fonts, Shadow } from '@/constants/theme';
import { useAuth } from '@/hooks/useAuth';

const { width, height } = Dimensions.get('window');

const COUNTRY_CODES = [
  { flag: '🇪🇬', code: '+20', name: 'مصر' },
  { flag: '🇸🇦', code: '+966', name: 'السعودية' },
  { flag: '🇦🇪', code: '+971', name: 'الإمارات' },
  { flag: '🇯🇴', code: '+962', name: 'الأردن' },
];

export default function Login() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { login, isLoading, authError, clearAuthError } = useAuth();
  const [phone, setPhone] = useState('');
  const [selectedCountry, setSelectedCountry] = useState(COUNTRY_CODES[0]);
  const [showCountryPicker, setShowCountryPicker] = useState(false);
  const [error, setError] = useState('');
  const [inputFocused, setInputFocused] = useState(false);

  // Animations
  const logoScale   = useRef(new Animated.Value(0.8)).current;
  const logoOpacity = useRef(new Animated.Value(0)).current;
  const formSlide   = useRef(new Animated.Value(40)).current;
  const formOpacity = useRef(new Animated.Value(0)).current;
  const pulseAnim   = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.sequence([
      Animated.parallel([
        Animated.spring(logoScale,   { toValue: 1, tension: 60, friction: 8, useNativeDriver: true }),
        Animated.timing(logoOpacity, { toValue: 1, duration: 600, useNativeDriver: true }),
      ]),
      Animated.parallel([
        Animated.timing(formSlide,   { toValue: 0, duration: 450, useNativeDriver: true }),
        Animated.timing(formOpacity, { toValue: 1, duration: 450, useNativeDriver: true }),
      ]),
    ]).start();

    // Pulse glow on logo
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.05, duration: 1600, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1,    duration: 1600, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  useEffect(() => {
    if (authError) setError(authError);
  }, [authError]);

  const handleLogin = async () => {
    const cleaned = phone.replace(/\s/g, '');
    if (cleaned.length < 9) {
      setError('يرجى إدخال رقم هاتف صحيح');
      return;
    }
    setError('');
    clearAuthError();
    await login(phone);
    router.push({ pathname: '/auth/otp', params: { phone } });
  };

  return (
    <View style={styles.root}>
      {/* Background layers */}
      <LinearGradient
        colors={['#1A0E00', '#120900', Colors.background]}
        style={StyleSheet.absoluteFill}
      />
      {/* Decorative circles */}
      <View style={styles.decor1} />
      <View style={styles.decor2} />
      <View style={styles.decor3} />

      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <ScrollView
          contentContainerStyle={[
            styles.scroll,
            { paddingTop: insets.top + 24, paddingBottom: insets.bottom + 32 },
          ]}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* ── Logo Section ── */}
          <Animated.View
            style={[
              styles.logoSection,
              { opacity: logoOpacity, transform: [{ scale: logoScale }] },
            ]}
          >
            {/* Hero image strip */}
            <View style={styles.heroStrip}>
              <Image
                source={require('@/assets/images/welcome_hero.jpg')}
                style={styles.heroStripImg}
                contentFit="cover"
                transition={300}
              />
              <LinearGradient
                colors={['transparent', Colors.background]}
                style={styles.heroStripGrad}
              />
            </View>

            {/* App name */}
            <Animated.View style={[styles.appBadgeWrap, { transform: [{ scale: pulseAnim }] }]}>
              <LinearGradient
                colors={[Colors.primaryLight, Colors.primary, Colors.primaryDark]}
                style={styles.appBadge}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
              >
                <Text style={styles.appBadgeEmoji}>🛺</Text>
                <Text style={styles.appBadgeName}>تك توكي</Text>
              </LinearGradient>
            </Animated.View>

            <Text style={styles.tagline}>تنقّل بسهولة وأمان</Text>
          </Animated.View>

          {/* ── Form Section ── */}
          <Animated.View
            style={[
              styles.formCard,
              {
                opacity: formOpacity,
                transform: [{ translateY: formSlide }],
              },
            ]}
          >
            <Text style={styles.welcomeTitle}>أهلاً بك 👋</Text>
            <Text style={styles.welcomeSubtitle}>
              أدخل رقم هاتفك لاستقبال رمز التحقق
            </Text>

            {/* Phone input */}
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>رقم الهاتف</Text>
              <View
                style={[
                  styles.inputContainer,
                  inputFocused && styles.inputContainerFocused,
                  error ? styles.inputContainerError : null,
                ]}
              >
                {/* Country picker */}
                <TouchableOpacity
                  style={styles.countryBtn}
                  onPress={() => setShowCountryPicker(!showCountryPicker)}
                >
                  <MaterialIcons
                    name={showCountryPicker ? 'expand-less' : 'expand-more'}
                    size={16}
                    color={Colors.textTertiary}
                  />
                  <Text style={styles.countryCode}>{selectedCountry.code}</Text>
                  <Text style={styles.countryFlag}>{selectedCountry.flag}</Text>
                </TouchableOpacity>
                <View style={styles.inputDivider} />
                <TextInput
                  style={styles.phoneInput}
                  placeholder="01X XXXX XXXX"
                  placeholderTextColor={Colors.textTertiary}
                  value={phone}
                  onChangeText={(t) => { setPhone(t); setError(''); clearAuthError(); }}
                  keyboardType="phone-pad"
                  maxLength={13}
                  textAlign="right"
                  onFocus={() => setInputFocused(true)}
                  onBlur={() => setInputFocused(false)}
                />
              </View>

              {/* Country dropdown */}
              {showCountryPicker ? (
                <View style={styles.countryDropdown}>
                  {COUNTRY_CODES.map((c) => (
                    <TouchableOpacity
                      key={c.code}
                      style={styles.countryOption}
                      onPress={() => { setSelectedCountry(c); setShowCountryPicker(false); }}
                    >
                      <Text style={styles.countryOptionCode}>{c.code}</Text>
                      <Text style={styles.countryOptionName}>{c.name}</Text>
                      <Text style={styles.countryFlag}>{c.flag}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
              ) : null}

              {error ? (
                <View style={styles.errorRow}>
                  <MaterialIcons name="error-outline" size={14} color={Colors.error} />
                  <Text style={styles.errorText}>{error}</Text>
                </View>
              ) : null}
            </View>

            {/* Login button */}
            <TouchableOpacity
              style={styles.loginBtn}
              onPress={handleLogin}
              disabled={isLoading}
              activeOpacity={0.88}
            >
              <LinearGradient
                colors={[Colors.primaryLight, Colors.primary, Colors.primaryDark]}
                style={styles.loginBtnGrad}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
              >
                {isLoading ? (
                  <ActivityIndicator color={Colors.textInverse} />
                ) : (
                  <>
                    <MaterialIcons name="sms" size={18} color={Colors.textInverse} />
                    <Text style={styles.loginBtnText}>إرسال رمز التحقق</Text>
                  </>
                )}
              </LinearGradient>
            </TouchableOpacity>

            {/* Divider */}
            <View style={styles.orRow}>
              <View style={styles.orLine} />
              <Text style={styles.orText}>أو</Text>
              <View style={styles.orLine} />
            </View>

            {/* Driver register */}
            <TouchableOpacity
              style={styles.driverBtn}
              onPress={() => router.push('/auth/driver-register')}
              activeOpacity={0.82}
            >
              <MaterialIcons name="drive-eta" size={20} color={Colors.primary} />
              <Text style={styles.driverBtnText}>التسجيل كسائق جديد</Text>
            </TouchableOpacity>
          </Animated.View>

          {/* Feature badges */}
          <Animated.View style={[styles.badgesRow, { opacity: formOpacity }]}>
            {[
              { icon: 'flash-on',   label: 'حجز سريع' },
              { icon: 'verified',   label: 'سائقون موثّقون' },
              { icon: 'lock',       label: 'آمن ومشفّر' },
            ].map((b, i) => (
              <View key={i} style={styles.badge}>
                <MaterialIcons name={b.icon as any} size={13} color={Colors.primary} />
                <Text style={styles.badgeText}>{b.label}</Text>
              </View>
            ))}
          </Animated.View>

          <Text style={styles.terms}>
            بالمتابعة، أنت توافق على{' '}
            <Text style={styles.termsLink}>شروط الاستخدام</Text>
            {' '}و{' '}
            <Text style={styles.termsLink}>سياسة الخصوصية</Text>
          </Text>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: Colors.background },

  // Decorative circles
  decor1: {
    position: 'absolute',
    width: 300, height: 300, borderRadius: 150,
    backgroundColor: Colors.primary + '06',
    top: -80, right: -80,
  },
  decor2: {
    position: 'absolute',
    width: 200, height: 200, borderRadius: 100,
    backgroundColor: Colors.primary + '04',
    top: 100, left: -60,
  },
  decor3: {
    position: 'absolute',
    width: 150, height: 150, borderRadius: 75,
    backgroundColor: Colors.primary + '05',
    bottom: 100, right: -40,
  },

  scroll: {
    flexGrow: 1,
    paddingHorizontal: Spacing.xl,
    alignItems: 'center',
  },

  // Logo section
  logoSection: { width: '100%', alignItems: 'center', marginBottom: Spacing.lg },
  heroStrip: {
    width: width - Spacing.xl * 2,
    height: 120,
    borderRadius: Radius.xl,
    overflow: 'hidden',
    marginBottom: -20,
    ...Shadow.md,
  },
  heroStripImg: { width: '100%', height: '100%' },
  heroStripGrad: {
    position: 'absolute',
    bottom: 0, left: 0, right: 0,
    height: 80,
  },
  appBadgeWrap: {
    borderRadius: Radius.lg,
    overflow: 'hidden',
    ...Shadow.glow,
    marginBottom: Spacing.sm,
  },
  appBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 24,
    paddingVertical: 11,
  },
  appBadgeEmoji: { fontSize: 26 },
  appBadgeName: {
    fontSize: 30,
    fontWeight: Fonts.black as any,
    color: Colors.background,
    letterSpacing: -0.5,
  },
  tagline: {
    fontSize: 14,
    color: Colors.textSecondary,
    textAlign: 'center',
    marginTop: 4,
  },

  // Form card
  formCard: {
    width: '100%',
    backgroundColor: Colors.card,
    borderRadius: Radius.xl,
    padding: Spacing.xl,
    borderWidth: 1,
    borderColor: Colors.border,
    marginBottom: Spacing.lg,
    ...Shadow.md,
  },
  welcomeTitle: {
    fontSize: 22,
    fontWeight: Fonts.bold as any,
    color: Colors.text,
    textAlign: 'right',
    marginBottom: 6,
  },
  welcomeSubtitle: {
    fontSize: 14,
    color: Colors.textSecondary,
    textAlign: 'right',
    lineHeight: 21,
    marginBottom: Spacing.xl,
  },
  inputGroup: { marginBottom: Spacing.lg },
  inputLabel: {
    fontSize: 13,
    fontWeight: Fonts.medium as any,
    color: Colors.textSecondary,
    textAlign: 'right',
    marginBottom: 8,
  },
  inputContainer: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    backgroundColor: Colors.surface,
    borderRadius: Radius.md,
    borderWidth: 1.5,
    borderColor: Colors.border,
    height: 54,
    overflow: 'hidden',
  },
  inputContainerFocused: {
    borderColor: Colors.primary,
    backgroundColor: Colors.primary + '08',
  },
  inputContainerError: { borderColor: Colors.error },
  countryBtn: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    paddingHorizontal: Spacing.md,
    gap: 5,
  },
  countryCode: {
    color: Colors.text,
    fontSize: 14,
    fontWeight: Fonts.semibold as any,
  },
  countryFlag: { fontSize: 20 },
  inputDivider: { width: 1, height: 28, backgroundColor: Colors.border },
  phoneInput: {
    flex: 1,
    paddingHorizontal: Spacing.md,
    color: Colors.text,
    fontSize: 16,
    fontWeight: Fonts.medium as any,
    height: 54,
  },
  countryDropdown: {
    backgroundColor: Colors.cardElevated,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.border,
    marginTop: 4,
    overflow: 'hidden',
  },
  countryOption: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    paddingHorizontal: Spacing.md,
    paddingVertical: 11,
    gap: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  countryOptionName: {
    flex: 1,
    textAlign: 'right',
    color: Colors.text,
    fontSize: 14,
  },
  countryOptionCode: { color: Colors.textSecondary, fontSize: 13 },
  errorRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 4,
    marginTop: 6,
  },
  errorText: { color: Colors.error, fontSize: 12 },

  loginBtn: {
    borderRadius: Radius.md,
    overflow: 'hidden',
    ...Shadow.glow,
  },
  loginBtnGrad: {
    paddingVertical: 16,
    alignItems: 'center',
    flexDirection: 'row-reverse',
    justifyContent: 'center',
    gap: 8,
  },
  loginBtnText: {
    color: Colors.textInverse,
    fontSize: 16,
    fontWeight: Fonts.bold as any,
  },

  orRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: Spacing.lg,
    gap: Spacing.md,
  },
  orLine: { flex: 1, height: 1, backgroundColor: Colors.border },
  orText: { color: Colors.textTertiary, fontSize: 13 },

  driverBtn: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1.5,
    borderColor: Colors.primary + '45',
    borderRadius: Radius.md,
    paddingVertical: 14,
    gap: 8,
    backgroundColor: Colors.primary + '10',
  },
  driverBtnText: {
    color: Colors.primary,
    fontSize: 15,
    fontWeight: Fonts.semibold as any,
  },

  badgesRow: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: Spacing.md,
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: Colors.card,
    borderRadius: Radius.full,
    paddingHorizontal: 11,
    paddingVertical: 6,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  badgeText: {
    fontSize: 12,
    color: Colors.textSecondary,
    fontWeight: Fonts.medium as any,
  },

  terms: {
    textAlign: 'center',
    color: Colors.textTertiary,
    fontSize: 12,
    lineHeight: 19,
  },
  termsLink: {
    color: Colors.primary,
    fontWeight: Fonts.medium as any,
  },
});
