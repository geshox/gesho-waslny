// Powered by OnSpace.AI
import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput,
  KeyboardAvoidingView, Platform, ActivityIndicator, Alert,
} from 'react-native';
import { Image } from 'expo-image';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { Colors, Spacing, Radius, Fonts, Shadow } from '@/constants/theme';
import { isSupabaseConfigured, supabase } from '@/lib/supabase';

type VehicleType = 'car' | 'tuk' | 'moto' | 'microbus' | 'other';

const VEHICLE_OPTIONS: { type: VehicleType; label: string; icon: string }[] = [
  { type: 'car',      label: 'سيارة',      icon: '🚗' },
  { type: 'tuk',      label: 'توكتوك',     icon: '🛺' },
  { type: 'moto',     label: 'موتوسيكل',   icon: '🏍️' },
  { type: 'microbus', label: 'ميكروباص',   icon: '🚐' },
  { type: 'other',    label: 'أخرى',       icon: '🚌' },
];

type Step = 1 | 2 | 3 | 4;

interface DocState {
  id: string;
  label: string;
  sublabel: string;
  icon: string;
  required: boolean;
  uri: string | null;
  uploadedUrl?: string;
}

export default function DriverRegister() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [step, setStep] = useState<Step>(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  // Step 1
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [nationalId, setNationalId] = useState('');

  // Step 2
  const [vehicleType, setVehicleType] = useState<VehicleType | null>(null);
  const [vehicleModel, setVehicleModel] = useState('');
  const [vehiclePlate, setVehiclePlate] = useState('');
  const [vehicleYear, setVehicleYear] = useState('');
  const [vehicleColor, setVehicleColor] = useState('');

  // Step 3 — Documents with real image picker
  const [docs, setDocs] = useState<DocState[]>([
    { id: 'face_verify',     label: 'التحقق من الوجه',          sublabel: 'صورة سيلفي واضحة للوجه — ستُقارن بالهوية', icon: '🤳', required: true,  uri: null },
    { id: 'national_id',     label: 'بطاقة الهوية الوطنية',     sublabel: 'صورة واضحة من الوجهين',                    icon: '🪪', required: true,  uri: null },
    { id: 'driver_license',  label: 'رخصة القيادة',              sublabel: 'رخصة سارية ومن نفس نوع المركبة',            icon: '📋', required: true,  uri: null },
    { id: 'vehicle_license', label: 'ترخيص/ملكية المركبة',       sublabel: 'وثيقة ملكية أو ترخيص ساري',                icon: '📄', required: true,  uri: null },
    { id: 'vehicle_photo',   label: 'صورة المركبة',               sublabel: 'صورة واضحة للمركبة من الأمام',             icon: '📸', required: false, uri: null },
  ]);

  const requiredUploaded = docs.filter(d => d.required).every(d => d.uri !== null);

  const handlePickImage = async (docId: string) => {
    const permResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permResult.granted) {
      // Try camera for face_verify
      const camPerm = await ImagePicker.requestCameraPermissionsAsync();
      if (!camPerm.granted) {
        if (Platform.OS !== 'web') Alert.alert('الإذن مرفوض', 'يرجى السماح للتطبيق بالوصول إلى الكاميرا أو المعرض');
        return;
      }
    }

    const isFace = docId === 'face_verify';
    const result = await (isFace
      ? ImagePicker.launchCameraAsync({
          mediaTypes: 'images',
          allowsEditing: true,
          aspect: [1, 1],
          quality: 0.85,
        })
      : ImagePicker.launchImageLibraryAsync({
          mediaTypes: 'images',
          allowsEditing: true,
          quality: 0.85,
        })
    );

    if (!result.canceled && result.assets[0]) {
      setDocs(prev =>
        prev.map(d => d.id === docId ? { ...d, uri: result.assets[0].uri } : d)
      );
    }
  };

  const handleRemoveDoc = (docId: string) => {
    setDocs(prev => prev.map(d => d.id === docId ? { ...d, uri: null } : d));
  };

  const uploadDocToSupabase = async (docId: string, uri: string): Promise<string | null> => {
    if (!isSupabaseConfigured) return uri; // Return local URI in mock mode

    try {
      const ext = uri.split('.').pop() ?? 'jpg';
      const filename = `${docId}_${Date.now()}.${ext}`;
      const path = `driver_docs/${filename}`;

      const response = await fetch(uri);
      const blob = await response.blob();

      const { error } = await supabase.storage
        .from('driver-documents')
        .upload(path, blob, { contentType: 'image/jpeg', upsert: true });

      if (error) return null;

      const { data } = supabase.storage.from('driver-documents').getPublicUrl(path);
      return data.publicUrl;
    } catch {
      return null;
    }
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);

    if (isSupabaseConfigured) {
      // Upload all docs
      const uploadedDocs: Record<string, string> = {};
      for (const doc of docs) {
        if (doc.uri) {
          const url = await uploadDocToSupabase(doc.id, doc.uri);
          if (url) uploadedDocs[doc.id] = url;
        }
      }

      // Insert driver record
      const { error } = await supabase.from('drivers').insert({
        vehicle_type: (vehicleType ?? 'car') as any,
        vehicle_model: vehicleModel,
        vehicle_plate: vehiclePlate,
        vehicle_color: vehicleColor,
        vehicle_year: parseInt(vehicleYear) || 2020,
        national_id: nationalId,
        license_number: uploadedDocs['driver_license'] ?? '',
        face_photo_url: uploadedDocs['face_verify'] ?? null,
        national_id_url: uploadedDocs['national_id'] ?? null,
        license_url: uploadedDocs['driver_license'] ?? null,
        vehicle_photo_url: uploadedDocs['vehicle_photo'] ?? null,
        approval_status: 'pending',
      } as any);

      if (error && Platform.OS !== 'web') {
        Alert.alert('خطأ', 'لم يتم إرسال الطلب، حاول مجدداً');
        setIsSubmitting(false);
        return;
      }
    } else {
      // Mock delay
      await new Promise(r => setTimeout(r, 2000));
    }

    setIsSubmitting(false);
    setSubmitted(true);
  };

  const STEP_LABELS = ['البيانات الشخصية', 'بيانات المركبة', 'المستندات', 'المراجعة'];

  if (submitted) {
    return (
      <View style={[styles.container, { paddingTop: insets.top, justifyContent: 'center' }]}>
        <LinearGradient colors={[Colors.primaryFaded, Colors.background]} style={styles.successGrad}>
          <View style={styles.successIconWrap}>
            <LinearGradient colors={[Colors.primary, Colors.primaryDark]} style={styles.successIconBg}>
              <MaterialIcons name="hourglass-empty" size={44} color={Colors.textInverse} />
            </LinearGradient>
          </View>
          <Text style={styles.successTitle}>طلبك قيد المراجعة</Text>
          <Text style={styles.successDesc}>
            تم استلام طلبك وسيقوم فريق الإدارة بمراجعة مستنداتك خلال 24-48 ساعة، وستصلك رسالة بقرار القبول.
          </Text>

          {/* Face verification status */}
          <View style={styles.faceVerifyStatus}>
            <MaterialIcons name="face" size={20} color={Colors.primary} />
            <Text style={styles.faceVerifyText}>
              {docs.find(d => d.id === 'face_verify')?.uri
                ? 'صورة الوجه مرفوعة — سيتم التحقق من الوجه بمقارنتها بالهوية'
                : 'لم يتم رفع صورة الوجه — يرجى إعادة التقديم'}
            </Text>
          </View>

          <View style={styles.reviewSteps}>
            {[
              { label: 'استلام الطلب',         done: true },
              { label: 'مراجعة المستندات',      done: false },
              { label: 'التحقق من الوجه',       done: false },
              { label: 'تفعيل الحساب',          done: false },
            ].map((s, i) => (
              <View key={i} style={styles.reviewStep}>
                <View style={[styles.stepDot2, s.done && styles.stepDot2Done]}>
                  {s.done
                    ? <MaterialIcons name="check" size={14} color={Colors.textInverse} />
                    : <Text style={styles.stepNum2}>{i + 1}</Text>}
                </View>
                <Text style={[styles.stepLabel2, s.done && styles.stepLabel2Done]}>{s.label}</Text>
              </View>
            ))}
          </View>
          <TouchableOpacity style={styles.backBtn2} onPress={() => router.replace('/auth/login')}>
            <Text style={styles.backBtn2Text}>العودة للصفحة الرئيسية</Text>
          </TouchableOpacity>
        </LinearGradient>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: Colors.background }}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <View style={[styles.container, { paddingTop: insets.top }]}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity style={styles.backBtn} onPress={() => step > 1 ? setStep((step - 1) as Step) : router.back()}>
            <MaterialIcons name="arrow-forward" size={22} color={Colors.text} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>تسجيل سائق جديد</Text>
          <View style={{ width: 40 }} />
        </View>

        {/* Progress */}
        <View style={styles.progress}>
          <View style={styles.progressBar}>
            <View style={[styles.progressFill, { width: `${(step / 4) * 100}%` }]} />
          </View>
          <View style={styles.stepsRow}>
            {STEP_LABELS.map((label, i) => {
              const n = i + 1;
              const isActive = n === step;
              const isDone = n < step;
              return (
                <View key={i} style={styles.stepItem}>
                  <View style={[styles.stepDot, isActive && styles.stepDotActive, isDone && styles.stepDotDone]}>
                    {isDone
                      ? <MaterialIcons name="check" size={12} color={Colors.textInverse} />
                      : <Text style={[styles.stepNum, (isActive || isDone) && styles.stepNumActive]}>{n}</Text>}
                  </View>
                  <Text style={[styles.stepLabel, isActive && styles.stepLabelActive]}>{label}</Text>
                </View>
              );
            })}
          </View>
        </View>

        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
          {/* STEP 1 */}
          {step === 1 ? (
            <View style={styles.stepContent}>
              <Text style={styles.stepTitle}>البيانات الشخصية</Text>
              <Text style={styles.stepDesc}>أدخل بياناتك الشخصية كما هي في بطاقة الهوية الوطنية</Text>
              {!isSupabaseConfigured ? (
                <View style={styles.mockBadge}>
                  <MaterialIcons name="info" size={14} color={Colors.warning} />
                  <Text style={styles.mockText}>وضع تجريبي — أدخل أي بيانات</Text>
                </View>
              ) : null}
              {[
                { label: 'الاسم الكامل',        value: name,       setter: setName,       placeholder: 'محمد أحمد السيد',    type: 'default'   },
                { label: 'رقم الهاتف',           value: phone,      setter: setPhone,      placeholder: '01X XXXX XXXX',      type: 'phone-pad' },
                { label: 'رقم الهوية الوطنية',   value: nationalId, setter: setNationalId, placeholder: '29XXXXXXXXXXXXXX',   type: 'phone-pad' },
              ].map((f, i) => (
                <View key={i} style={styles.fieldGroup}>
                  <Text style={styles.fieldLabel}>{f.label}</Text>
                  <TextInput
                    style={styles.fieldInput}
                    value={f.value}
                    onChangeText={f.setter}
                    placeholder={f.placeholder}
                    placeholderTextColor={Colors.textTertiary}
                    keyboardType={f.type as any}
                    textAlign="right"
                  />
                </View>
              ))}
            </View>

          ) : step === 2 ? (
            <View style={styles.stepContent}>
              <Text style={styles.stepTitle}>بيانات المركبة</Text>
              <Text style={styles.stepDesc}>اختر نوع وسيلة النقل وأدخل بياناتها بدقة</Text>
              <Text style={styles.fieldLabel}>نوع وسيلة النقل</Text>
              <View style={styles.vehicleGrid}>
                {VEHICLE_OPTIONS.map(v => (
                  <TouchableOpacity
                    key={v.type}
                    style={[styles.vehicleCard, vehicleType === v.type && styles.vehicleCardSelected]}
                    onPress={() => setVehicleType(v.type)}
                  >
                    <Text style={styles.vehicleIcon}>{v.icon}</Text>
                    <Text style={[styles.vehicleLabel, vehicleType === v.type && styles.vehicleLabelSelected]}>
                      {v.label}
                    </Text>
                    {vehicleType === v.type ? (
                      <View style={styles.vehicleCheck}>
                        <MaterialIcons name="check-circle" size={16} color={Colors.primary} />
                      </View>
                    ) : null}
                  </TouchableOpacity>
                ))}
              </View>
              {[
                { label: 'موديل المركبة', value: vehicleModel, setter: setVehicleModel, placeholder: 'تويوتا كورولا 2022', type: 'default' },
                { label: 'رقم اللوحة',   value: vehiclePlate, setter: setVehiclePlate, placeholder: 'أ ب ج 1234',         type: 'default' },
                { label: 'سنة الصنع',    value: vehicleYear,  setter: setVehicleYear,  placeholder: '2022',                type: 'phone-pad' },
                { label: 'لون المركبة',  value: vehicleColor, setter: setVehicleColor, placeholder: 'أبيض',                type: 'default' },
              ].map((f, i) => (
                <View key={i} style={styles.fieldGroup}>
                  <Text style={styles.fieldLabel}>{f.label}</Text>
                  <TextInput
                    style={styles.fieldInput}
                    value={f.value}
                    onChangeText={f.setter}
                    placeholder={f.placeholder}
                    placeholderTextColor={Colors.textTertiary}
                    keyboardType={f.type as any}
                    textAlign="right"
                  />
                </View>
              ))}
            </View>

          ) : step === 3 ? (
            <View style={styles.stepContent}>
              <Text style={styles.stepTitle}>رفع المستندات</Text>
              <Text style={styles.stepDesc}>يجب رفع جميع المستندات المطلوبة للحصول على الموافقة</Text>

              <View style={styles.securityAlert}>
                <MaterialIcons name="security" size={16} color={Colors.accent} />
                <Text style={styles.securityText}>
                  جميع المستندات مشفرة وآمنة. لن تُشارك مع أي طرف ثالث.
                </Text>
              </View>

              {/* Face verification special card */}
              <View style={styles.faceCard}>
                <LinearGradient
                  colors={[Colors.primaryFaded, Colors.background]}
                  style={styles.faceCardGrad}
                >
                  <View style={styles.faceCardHeader}>
                    <View style={styles.requiredBadge}>
                      <Text style={styles.requiredText}>مطلوب</Text>
                    </View>
                    <Text style={styles.faceCardTitle}>التحقق من الوجه 🤳</Text>
                  </View>
                  <Text style={styles.faceCardDesc}>
                    سيتم مقارنة صورة وجهك بصورة الهوية الوطنية للتحقق من هويتك بدقة
                  </Text>

                  {docs[0].uri ? (
                    <View style={styles.facePreviewWrap}>
                      <Image source={{ uri: docs[0].uri }} style={styles.facePreview} contentFit="cover" />
                      <View style={styles.facePreviewOverlay}>
                        <TouchableOpacity
                          style={styles.faceRetakeBtn}
                          onPress={() => handlePickImage('face_verify')}
                        >
                          <MaterialIcons name="refresh" size={14} color={Colors.textInverse} />
                          <Text style={styles.faceRetakeText}>إعادة التصوير</Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                          style={styles.faceRemoveBtn}
                          onPress={() => handleRemoveDoc('face_verify')}
                        >
                          <MaterialIcons name="delete" size={14} color={Colors.error} />
                        </TouchableOpacity>
                      </View>
                      <View style={styles.faceVerifiedBadge}>
                        <MaterialIcons name="check-circle" size={14} color={Colors.success} />
                        <Text style={styles.faceVerifiedText}>صورة مرفوعة</Text>
                      </View>
                    </View>
                  ) : (
                    <TouchableOpacity style={styles.faceCameraBtn} onPress={() => handlePickImage('face_verify')}>
                      <LinearGradient colors={[Colors.primary, Colors.primaryDark]} style={styles.faceCameraGrad}>
                        <MaterialIcons name="camera-alt" size={22} color={Colors.textInverse} />
                        <Text style={styles.faceCameraBtnText}>التقاط صورة الوجه</Text>
                      </LinearGradient>
                    </TouchableOpacity>
                  )}
                </LinearGradient>
              </View>

              {/* Other documents */}
              {docs.slice(1).map(doc => (
                <TouchableOpacity
                  key={doc.id}
                  style={[styles.docCard, doc.uri && styles.docCardUploaded]}
                  onPress={() => doc.uri ? handleRemoveDoc(doc.id) : handlePickImage(doc.id)}
                >
                  <View style={styles.docRight}>
                    <View style={[styles.docIconBg, doc.uri && styles.docIconBgUploaded]}>
                      {doc.uri
                        ? <MaterialIcons name="check-circle" size={22} color={Colors.primary} />
                        : <MaterialIcons name="cloud-upload" size={22} color={Colors.textTertiary} />}
                    </View>
                    <View style={styles.docInfo}>
                      <View style={styles.docLabelRow}>
                        {doc.required ? (
                          <View style={styles.requiredBadge}>
                            <Text style={styles.requiredText}>مطلوب</Text>
                          </View>
                        ) : null}
                        <Text style={[styles.docLabel, doc.uri && styles.docLabelUploaded]}>
                          {doc.label}
                        </Text>
                        <Text style={styles.docEmoji}>{doc.icon}</Text>
                      </View>
                      <Text style={styles.docSublabel}>{doc.sublabel}</Text>
                      {doc.uri ? (
                        <Text style={styles.docUriText} numberOfLines={1}>
                          ✅ تم رفع الصورة
                        </Text>
                      ) : null}
                    </View>
                  </View>
                  {doc.uri ? (
                    <View style={styles.docPreviewWrap}>
                      <Image source={{ uri: doc.uri }} style={styles.docPreviewThumb} contentFit="cover" />
                    </View>
                  ) : (
                    <MaterialIcons name="add-circle-outline" size={20} color={Colors.textTertiary} />
                  )}
                </TouchableOpacity>
              ))}

              {!requiredUploaded ? (
                <View style={styles.warningAlert}>
                  <MaterialIcons name="warning" size={14} color={Colors.warning} />
                  <Text style={styles.warningText}>يرجى رفع جميع المستندات المطلوبة للمتابعة</Text>
                </View>
              ) : null}
            </View>

          ) : (
            <View style={styles.stepContent}>
              <Text style={styles.stepTitle}>مراجعة البيانات</Text>
              <Text style={styles.stepDesc}>راجع بياناتك قبل إرسال الطلب للاعتماد</Text>

              {[
                { title: 'البيانات الشخصية', items: [
                  { label: 'الاسم',         value: name || 'لم يُدخل' },
                  { label: 'رقم الهاتف',    value: phone || 'لم يُدخل' },
                  { label: 'رقم الهوية',    value: nationalId ? nationalId.slice(0, 4) + '**********' : 'لم يُدخل' },
                ]},
                { title: 'بيانات المركبة', items: [
                  { label: 'نوع المركبة',   value: vehicleType ? VEHICLE_OPTIONS.find(v => v.type === vehicleType)?.label ?? '-' : 'لم يُختر' },
                  { label: 'الموديل',       value: vehicleModel  || 'لم يُدخل' },
                  { label: 'رقم اللوحة',   value: vehiclePlate  || 'لم يُدخل' },
                  { label: 'اللون',         value: vehicleColor  || 'لم يُدخل' },
                  { label: 'سنة الصنع',     value: vehicleYear   || 'لم يُدخل' },
                ]},
                { title: 'المستندات', items: docs.map(d => ({
                  label: d.label,
                  value: d.uri ? '✅ مرفوع' : d.required ? '❌ غير مرفوع' : '— اختياري',
                }))},
              ].map((section, si) => (
                <View key={si} style={styles.reviewSection}>
                  <Text style={styles.reviewSectionTitle}>{section.title}</Text>
                  <View style={styles.reviewItems}>
                    {section.items.map((item, ii) => (
                      <View key={ii} style={[styles.reviewItem, ii < section.items.length - 1 && styles.reviewItemBorder]}>
                        <Text style={styles.reviewVal}>{item.value}</Text>
                        <Text style={styles.reviewLbl}>{item.label}</Text>
                      </View>
                    ))}
                  </View>
                </View>
              ))}

              <View style={styles.termsBox}>
                <MaterialIcons name="info" size={16} color={Colors.textTertiary} />
                <Text style={styles.termsText}>
                  بإرسال الطلب توافق على شروط وأحكام عمل السائقين في تطبيق تك توكي وسياسة الخصوصية.
                </Text>
              </View>
            </View>
          )}
        </ScrollView>

        {/* Bottom Button */}
        <View style={[styles.bottomAction, { paddingBottom: insets.bottom + 16 }]}>
          {step < 4 ? (
            <TouchableOpacity
              style={[styles.nextBtn, step === 3 && !requiredUploaded && { opacity: 0.4 }]}
              onPress={() => setStep((step + 1) as Step)}
              disabled={step === 3 && !requiredUploaded}
            >
              <LinearGradient
                colors={step === 3 && !requiredUploaded ? [Colors.border, Colors.border] : [Colors.primary, Colors.primaryDark]}
                style={styles.nextBtnGrad}
              >
                <MaterialIcons name="arrow-back" size={18} color={step === 3 && !requiredUploaded ? Colors.textTertiary : Colors.textInverse} />
                <Text style={[styles.nextBtnText, step === 3 && !requiredUploaded && { color: Colors.textTertiary }]}>التالي</Text>
              </LinearGradient>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity style={styles.nextBtn} onPress={handleSubmit} disabled={isSubmitting}>
              <LinearGradient colors={[Colors.primary, Colors.primaryDark]} style={styles.nextBtnGrad}>
                {isSubmitting
                  ? <ActivityIndicator color={Colors.textInverse} />
                  : <>
                      <MaterialIcons name="send" size={18} color={Colors.textInverse} />
                      <Text style={styles.nextBtnText}>إرسال الطلب للمراجعة</Text>
                    </>}
              </LinearGradient>
            </TouchableOpacity>
          )}
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.base, paddingVertical: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  backBtn: {
    width: 40, height: 40, justifyContent: 'center', alignItems: 'center',
    backgroundColor: Colors.card, borderRadius: 20, borderWidth: 1, borderColor: Colors.border,
  },
  headerTitle: { fontSize: 18, fontWeight: Fonts.bold as any, color: Colors.text },
  progress: { paddingHorizontal: Spacing.base, paddingVertical: Spacing.md, gap: Spacing.sm },
  progressBar: { height: 4, backgroundColor: Colors.border, borderRadius: 2, overflow: 'hidden' },
  progressFill: { height: '100%', backgroundColor: Colors.primary, borderRadius: 2 },
  stepsRow: { flexDirection: 'row-reverse', justifyContent: 'space-between' },
  stepItem: { alignItems: 'center', gap: 4, flex: 1 },
  stepDot: {
    width: 24, height: 24, borderRadius: 12, backgroundColor: Colors.border,
    justifyContent: 'center', alignItems: 'center', borderWidth: 2, borderColor: Colors.border,
  },
  stepDotActive: { backgroundColor: Colors.primaryFaded, borderColor: Colors.primary },
  stepDotDone: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  stepNum: { fontSize: 11, color: Colors.textTertiary, fontWeight: Fonts.bold as any },
  stepNumActive: { color: Colors.primary },
  stepLabel: { fontSize: 10, color: Colors.textTertiary, textAlign: 'center' },
  stepLabelActive: { color: Colors.primary, fontWeight: Fonts.semibold as any },
  content: { padding: Spacing.base, paddingBottom: 120 },
  stepContent: { gap: Spacing.base },
  stepTitle: { fontSize: 20, fontWeight: Fonts.bold as any, color: Colors.text, textAlign: 'right' },
  stepDesc: { fontSize: 14, color: Colors.textSecondary, textAlign: 'right', lineHeight: 22 },
  mockBadge: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: 6,
    backgroundColor: Colors.warningFaded, borderRadius: Radius.full,
    paddingHorizontal: 12, paddingVertical: 6, alignSelf: 'flex-end',
    borderWidth: 1, borderColor: Colors.warning + '30',
  },
  mockText: { color: Colors.warning, fontSize: 12 },
  fieldGroup: { gap: 6 },
  fieldLabel: { fontSize: 14, color: Colors.textSecondary, textAlign: 'right', fontWeight: Fonts.medium as any },
  fieldInput: {
    height: 52, backgroundColor: Colors.card, borderRadius: Radius.md,
    borderWidth: 1, borderColor: Colors.border, paddingHorizontal: Spacing.md,
    color: Colors.text, fontSize: 15,
  },
  vehicleGrid: { flexDirection: 'row-reverse', flexWrap: 'wrap', gap: Spacing.sm, marginBottom: Spacing.sm },
  vehicleCard: {
    width: '31%', backgroundColor: Colors.card, borderRadius: Radius.md, padding: Spacing.sm,
    alignItems: 'center', gap: 6, borderWidth: 1.5, borderColor: Colors.border, position: 'relative',
  },
  vehicleCardSelected: { borderColor: Colors.primary, backgroundColor: Colors.primaryFaded },
  vehicleIcon: { fontSize: 28 },
  vehicleLabel: { fontSize: 12, color: Colors.textSecondary, fontWeight: Fonts.medium as any },
  vehicleLabelSelected: { color: Colors.primary, fontWeight: Fonts.semibold as any },
  vehicleCheck: { position: 'absolute', top: 4, left: 4 },
  securityAlert: {
    flexDirection: 'row-reverse', alignItems: 'flex-start', gap: Spacing.sm,
    backgroundColor: Colors.accentFaded, borderRadius: Radius.md, padding: Spacing.md,
    borderWidth: 1, borderColor: Colors.accent + '30',
  },
  securityText: { flex: 1, fontSize: 13, color: Colors.accent, lineHeight: 20, textAlign: 'right' },
  // Face Verification Card
  faceCard: { borderRadius: Radius.xl, overflow: 'hidden', borderWidth: 1.5, borderColor: Colors.primary + '40' },
  faceCardGrad: { padding: Spacing.base, gap: Spacing.md },
  faceCardHeader: { flexDirection: 'row-reverse', alignItems: 'center', gap: 8 },
  faceCardTitle: { fontSize: 16, fontWeight: Fonts.bold as any, color: Colors.text },
  faceCardDesc: { fontSize: 13, color: Colors.textSecondary, textAlign: 'right', lineHeight: 20 },
  facePreviewWrap: { position: 'relative', alignSelf: 'center' },
  facePreview: { width: 120, height: 120, borderRadius: 60, borderWidth: 3, borderColor: Colors.primary },
  facePreviewOverlay: {
    position: 'absolute', bottom: 0, left: 0, right: 0,
    flexDirection: 'row-reverse', justifyContent: 'center', gap: 8,
  },
  faceRetakeBtn: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: 4,
    backgroundColor: Colors.primary, borderRadius: Radius.full,
    paddingHorizontal: 10, paddingVertical: 5,
  },
  faceRetakeText: { fontSize: 11, color: Colors.textInverse, fontWeight: Fonts.medium as any },
  faceRemoveBtn: {
    backgroundColor: Colors.errorFaded, borderRadius: Radius.full,
    padding: 6, borderWidth: 1, borderColor: Colors.error + '40',
  },
  faceVerifiedBadge: {
    position: 'absolute', top: -8, right: -8,
    flexDirection: 'row-reverse', alignItems: 'center', gap: 3,
    backgroundColor: Colors.successFaded, borderRadius: Radius.full,
    paddingHorizontal: 8, paddingVertical: 4,
    borderWidth: 1, borderColor: Colors.success + '40',
  },
  faceVerifiedText: { fontSize: 10, color: Colors.success, fontWeight: Fonts.semibold as any },
  faceCameraBtn: { borderRadius: Radius.md, overflow: 'hidden', ...Shadow.glow },
  faceCameraGrad: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center',
    gap: 8, paddingVertical: 14,
  },
  faceCameraBtnText: { color: Colors.textInverse, fontSize: 15, fontWeight: Fonts.bold as any },
  // Document cards
  docCard: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: Colors.card, borderRadius: Radius.lg, padding: Spacing.base,
    borderWidth: 1.5, borderColor: Colors.border,
  },
  docCardUploaded: { borderColor: Colors.primary + '60', backgroundColor: Colors.primaryFaded },
  docRight: { flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.md, flex: 1 },
  docIconBg: {
    width: 44, height: 44, borderRadius: 12, backgroundColor: Colors.surface,
    justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: Colors.border,
  },
  docIconBgUploaded: { borderColor: Colors.primary + '40', backgroundColor: Colors.primaryFaded },
  docInfo: { flex: 1, alignItems: 'flex-end', gap: 4 },
  docLabelRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 6 },
  docEmoji: { fontSize: 16 },
  docLabel: { fontSize: 14, fontWeight: Fonts.semibold as any, color: Colors.text },
  docLabelUploaded: { color: Colors.primary },
  requiredBadge: {
    backgroundColor: Colors.errorFaded, borderRadius: Radius.full,
    paddingHorizontal: 6, paddingVertical: 2,
  },
  requiredText: { fontSize: 10, color: Colors.error, fontWeight: Fonts.semibold as any },
  docSublabel: { fontSize: 12, color: Colors.textTertiary, textAlign: 'right' },
  docUriText: { fontSize: 11, color: Colors.primary },
  docPreviewWrap: { width: 44, height: 44, borderRadius: 8, overflow: 'hidden' },
  docPreviewThumb: { width: 44, height: 44 },
  warningAlert: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.sm,
    backgroundColor: Colors.warningFaded, borderRadius: Radius.md, padding: Spacing.md,
    borderWidth: 1, borderColor: Colors.warning + '30',
  },
  warningText: { flex: 1, fontSize: 13, color: Colors.warning, textAlign: 'right' },
  // Review
  reviewSection: { gap: Spacing.sm },
  reviewSectionTitle: {
    fontSize: 14, fontWeight: Fonts.semibold as any, color: Colors.textSecondary,
    textAlign: 'right', textTransform: 'uppercase',
  },
  reviewItems: {
    backgroundColor: Colors.card, borderRadius: Radius.lg,
    borderWidth: 1, borderColor: Colors.border, overflow: 'hidden',
  },
  reviewItem: {
    flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center',
    padding: Spacing.md,
  },
  reviewItemBorder: { borderBottomWidth: 1, borderBottomColor: Colors.border },
  reviewLbl: { fontSize: 13, color: Colors.textSecondary },
  reviewVal: { fontSize: 13, fontWeight: Fonts.semibold as any, color: Colors.text },
  termsBox: {
    flexDirection: 'row-reverse', alignItems: 'flex-start', gap: Spacing.sm,
    backgroundColor: Colors.card, borderRadius: Radius.md, padding: Spacing.md,
    borderWidth: 1, borderColor: Colors.border,
  },
  termsText: { flex: 1, fontSize: 12, color: Colors.textTertiary, lineHeight: 18, textAlign: 'right' },
  // app name update: تك توكي
  bottomAction: {
    position: 'absolute', bottom: 0, left: 0, right: 0,
    paddingHorizontal: Spacing.base, paddingTop: Spacing.md,
    backgroundColor: Colors.background, borderTopWidth: 1, borderTopColor: Colors.border,
  },
  nextBtn: { borderRadius: Radius.md, overflow: 'hidden', ...Shadow.glow },
  nextBtnGrad: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center',
    gap: 8, paddingVertical: 16,
  },
  nextBtnText: { color: Colors.textInverse, fontSize: 16, fontWeight: Fonts.bold as any },
  // Success
  successGrad: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: Spacing.xl, gap: Spacing.lg },
  successIconWrap: { borderRadius: 60, overflow: 'hidden', ...Shadow.glow, marginBottom: Spacing.sm },
  successIconBg: { width: 100, height: 100, justifyContent: 'center', alignItems: 'center' },
  successTitle: { fontSize: 26, fontWeight: Fonts.bold as any, color: Colors.text, textAlign: 'center' },
  successDesc: { fontSize: 14, color: Colors.textSecondary, textAlign: 'center', lineHeight: 22 },
  faceVerifyStatus: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: 8,
    backgroundColor: Colors.primaryFaded, borderRadius: Radius.md, padding: Spacing.md,
    borderWidth: 1, borderColor: Colors.primary + '30', width: '100%',
  },
  faceVerifyText: { flex: 1, fontSize: 13, color: Colors.primary, textAlign: 'right', lineHeight: 20 },
  reviewSteps: { gap: Spacing.md, width: '100%', marginTop: Spacing.md },
  reviewStep: { flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.md },
  stepDot2: {
    width: 30, height: 30, borderRadius: 15, backgroundColor: Colors.border,
    justifyContent: 'center', alignItems: 'center',
  },
  stepDot2Done: { backgroundColor: Colors.primary },
  stepNum2: { fontSize: 13, color: Colors.textTertiary, fontWeight: Fonts.bold as any },
  stepLabel2: { fontSize: 14, color: Colors.textTertiary },
  stepLabel2Done: { color: Colors.primary, fontWeight: Fonts.semibold as any },
  backBtn2: {
    marginTop: Spacing.md, paddingVertical: 14, paddingHorizontal: Spacing.xxl,
    borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.primary + '50',
    backgroundColor: Colors.primaryFaded,
  },
  backBtn2Text: { color: Colors.primary, fontWeight: Fonts.semibold as any, fontSize: 15 },
});
