// Powered by OnSpace.AI
import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Alert,
  Platform,
} from 'react-native';
import { Image } from 'expo-image';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Spacing, Radius, Fonts, Shadow } from '@/constants/theme';
import { useAuth } from '@/hooks/useAuth';
import { useRide } from '@/hooks/useRide';
import { useTheme } from '@/hooks/useTheme';
import { ThemeToggle } from '@/components/ThemeToggle';

interface SettingItem {
  id: string;
  icon: string;
  label: string;
  value?: string;
  type: 'link' | 'toggle' | 'danger' | 'theme';
  toggle?: boolean;
}

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { user, logout } = useAuth();
  const { rideHistory } = useRide();
  const { isDark } = useTheme();
  const [notifications, setNotifications] = useState(true);
  const [locationSharing, setLocationSharing] = useState(true);

  const completedRides = rideHistory.filter(r => r.status === 'completed').length;
  const avgRating = rideHistory
    .filter(r => r.status === 'completed' && r.rating)
    .reduce((sum, r) => sum + (r.rating || 0), 0) /
    (rideHistory.filter(r => r.rating).length || 1);

  const SETTINGS_GROUPS: { title: string; items: SettingItem[] }[] = [
    {
      title: 'الحساب',
      items: [
        { id: 'edit', icon: 'edit', label: 'تعديل الملف الشخصي', type: 'link' },
        { id: 'phone', icon: 'phone', label: 'رقم الهاتف', value: user?.phone, type: 'link' },
        { id: 'security', icon: 'security', label: 'الأمان والخصوصية', type: 'link' },
      ],
    },
    {
      title: 'الإعدادات',
      items: [
        { id: 'notif', icon: 'notifications', label: 'الإشعارات', type: 'toggle', toggle: notifications },
        { id: 'location', icon: 'location-on', label: 'مشاركة الموقع', type: 'toggle', toggle: locationSharing },
        { id: 'lang', icon: 'language', label: 'اللغة', value: 'العربية', type: 'link' },
        { id: 'theme', icon: 'palette', label: isDark ? 'الوضع الليلي' : 'الوضع النهاري', type: 'theme' },
      ],
    },
    {
      title: 'المساعدة',
      items: [
        { id: 'support', icon: 'headset-mic', label: 'الدعم الفني', type: 'link' },
        { id: 'complaint', icon: 'report-problem', label: 'إرسال شكوى', type: 'link' },
        { id: 'faq', icon: 'help', label: 'الأسئلة الشائعة', type: 'link' },
        { id: 'terms', icon: 'description', label: 'الشروط والأحكام', type: 'link' },
      ],
    },
    {
      title: 'الإدارة',
      items: [
        { id: 'admin', icon: 'admin-panel-settings', label: 'لوحة التحكم الإدارية', type: 'link' },
      ],
    },
    {
      title: 'تسجيل الخروج',
      items: [
        { id: 'logout', icon: 'logout', label: 'تسجيل الخروج', type: 'danger' },
      ],
    },
  ];

  const handleItemPress = (item: SettingItem) => {
    if (item.type === 'theme') return; // handled by ThemeToggle widget
    if (item.type === 'toggle') {
      if (item.id === 'notif') setNotifications(!notifications);
      if (item.id === 'location') setLocationSharing(!locationSharing);
      return;
    }
    if (item.type === 'danger' && item.id === 'logout') {
      if (Platform.OS !== 'web') {
        Alert.alert('تسجيل الخروج', 'هل أنت متأكد من تسجيل الخروج؟', [
          { text: 'إلغاء', style: 'cancel' },
          { text: 'تسجيل الخروج', style: 'destructive', onPress: () => { logout(); router.replace('/onboarding'); } },
        ]);
      } else {
        logout();
        router.replace('/onboarding');
      }
    }
    if (item.id === 'admin') router.push('/admin/index');
    if (item.id === 'complaint') router.push('/complaints/new');
  };

  const renderItemRight = (item: SettingItem) => {
    if (item.type === 'theme') return <ThemeToggle />;
    if (item.type === 'toggle') {
      return (
        <Switch
          value={item.id === 'notif' ? notifications : locationSharing}
          onValueChange={() => handleItemPress(item)}
          trackColor={{ false: Colors.border, true: Colors.primaryFaded }}
          thumbColor={
            (item.id === 'notif' ? notifications : locationSharing)
              ? Colors.primary
              : Colors.textTertiary
          }
        />
      );
    }
    if (item.type === 'danger') {
      return <MaterialIcons name="chevron-left" size={18} color={Colors.error + '80'} />;
    }
    if (item.value) return <Text style={styles.settingValue}>{item.value}</Text>;
    return <MaterialIcons name="chevron-left" size={18} color={Colors.textTertiary} />;
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <ScrollView showsVerticalScrollIndicator={false}>

        {/* Header */}
        <LinearGradient
          colors={['#0D2B1E', Colors.background]}
          style={styles.profileHeader}
          start={{ x: 0, y: 0 }}
          end={{ x: 0, y: 1 }}
        >
          <View style={styles.avatarSection}>
            <View style={styles.avatarWrapper}>
              <Image
                source={{ uri: user?.avatar }}
                style={styles.avatar}
                contentFit="cover"
              />
              <TouchableOpacity style={styles.editAvatarButton}>
                <MaterialIcons name="camera-alt" size={14} color={Colors.textInverse} />
              </TouchableOpacity>
            </View>
            <View style={styles.profileInfo}>
              <View style={styles.nameRow}>
                {user?.isVerified ? (
                  <MaterialIcons name="verified" size={18} color={Colors.primary} />
                ) : null}
                <Text style={styles.profileName}>{user?.name}</Text>
              </View>
              <Text style={styles.profilePhone}>{user?.phone}</Text>
              <Text style={styles.profileJoined}>عضو منذ {user?.joinDate}</Text>
            </View>
          </View>

          {/* Stats */}
          <View style={styles.statsRow}>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{completedRides}</Text>
              <Text style={styles.statLabel}>رحلة</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <View style={styles.ratingRow}>
                <MaterialIcons name="star" size={14} color={Colors.gold} />
                <Text style={styles.statValue}>{avgRating.toFixed(1)}</Text>
              </View>
              <Text style={styles.statLabel}>تقييمي</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Text style={[styles.statValue, { color: Colors.primary }]}>
                {user?.walletBalance?.toFixed(0)} ج
              </Text>
              <Text style={styles.statLabel}>رصيدي</Text>
            </View>
          </View>
        </LinearGradient>

        {/* Quick Actions */}
        <View style={styles.quickActions}>
          <TouchableOpacity style={styles.quickAction} onPress={() => router.push('/ride/rating')}>
            <LinearGradient colors={[Colors.goldFaded, Colors.warningFaded]} style={styles.quickActionIcon}>
              <MaterialIcons name="star" size={20} color={Colors.gold} />
            </LinearGradient>
            <Text style={styles.quickActionLabel}>تقييماتي</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.quickAction}>
            <LinearGradient colors={[Colors.primaryFaded, Colors.successFaded]} style={styles.quickActionIcon}>
              <MaterialIcons name="card-giftcard" size={20} color={Colors.primary} />
            </LinearGradient>
            <Text style={styles.quickActionLabel}>العروض</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.quickAction}>
            <LinearGradient colors={[Colors.accentFaded, Colors.infoFaded]} style={styles.quickActionIcon}>
              <MaterialIcons name="people" size={20} color={Colors.accent} />
            </LinearGradient>
            <Text style={styles.quickActionLabel}>ادعُ صديق</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.quickAction} onPress={() => router.push('/complaints/new')}>
            <LinearGradient colors={[Colors.errorFaded, Colors.warningFaded]} style={styles.quickActionIcon}>
              <MaterialIcons name="report" size={20} color={Colors.error} />
            </LinearGradient>
            <Text style={styles.quickActionLabel}>شكوى</Text>
          </TouchableOpacity>
        </View>

        {/* Settings Groups */}
        {SETTINGS_GROUPS.map((group, gi) => (
          <View key={gi} style={styles.settingsGroup}>
            <Text style={styles.groupTitle}>{group.title}</Text>
            <View style={styles.groupItems}>
              {group.items.map((item, ii) => (
                <TouchableOpacity
                  key={item.id}
                  style={[
                    styles.settingItem,
                    ii < group.items.length - 1 && styles.settingItemBorder,
                    item.type === 'danger' && styles.settingItemDanger,
                  ]}
                  onPress={() => handleItemPress(item)}
                  activeOpacity={item.type === 'theme' ? 1 : 0.7}
                >
                  <View style={styles.settingItemLeft}>
                    {renderItemRight(item)}
                  </View>

                  <View style={styles.settingItemRight}>
                    <Text style={[
                      styles.settingLabel,
                      item.type === 'danger' && styles.settingLabelDanger,
                    ]}>
                      {item.label}
                    </Text>
                    <View style={[
                      styles.settingIconBg,
                      item.type === 'danger' && styles.settingIconBgDanger,
                      item.type === 'theme' && styles.settingIconBgTheme,
                    ]}>
                      <MaterialIcons
                        name={item.icon as any}
                        size={18}
                        color={
                          item.type === 'danger' ? Colors.error
                          : item.type === 'theme' ? (isDark ? '#818CF8' : '#F59E0B')
                          : Colors.primary
                        }
                      />
                    </View>
                  </View>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        ))}

        <Text style={styles.version}>تك توكي v1.0.0 — محاكاة تجريبية</Text>
        <View style={{ height: 20 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  profileHeader: {
    padding: Spacing.base,
    paddingBottom: Spacing.xl,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  avatarSection: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: Spacing.base,
    marginBottom: Spacing.xl,
  },
  avatarWrapper: { position: 'relative' },
  avatar: {
    width: 80, height: 80, borderRadius: 40,
    borderWidth: 3, borderColor: Colors.primary, ...Shadow.glow,
  },
  editAvatarButton: {
    position: 'absolute', bottom: 0, left: 0,
    width: 26, height: 26, borderRadius: 13, backgroundColor: Colors.primary,
    justifyContent: 'center', alignItems: 'center',
    borderWidth: 2, borderColor: Colors.background,
  },
  profileInfo: { flex: 1, alignItems: 'flex-end', gap: 4 },
  nameRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 5 },
  profileName: { fontSize: 20, fontWeight: Fonts.bold as any, color: Colors.text },
  profilePhone: { fontSize: 14, color: Colors.textSecondary, direction: 'ltr' as any },
  profileJoined: { fontSize: 12, color: Colors.textTertiary },
  statsRow: {
    flexDirection: 'row-reverse', backgroundColor: Colors.card, borderRadius: Radius.lg,
    padding: Spacing.md, borderWidth: 1, borderColor: Colors.border,
  },
  statItem: { flex: 1, alignItems: 'center', gap: 4 },
  statDivider: { width: 1, backgroundColor: Colors.border, marginVertical: 4 },
  statValue: { fontSize: 18, fontWeight: Fonts.bold as any, color: Colors.text },
  statLabel: { fontSize: 11, color: Colors.textSecondary },
  ratingRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 3 },
  quickActions: {
    flexDirection: 'row-reverse', paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.base, gap: Spacing.sm,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  quickAction: { flex: 1, alignItems: 'center', gap: 6 },
  quickActionIcon: {
    width: 48, height: 48, borderRadius: Radius.md,
    justifyContent: 'center', alignItems: 'center',
    borderWidth: 1, borderColor: Colors.border,
  },
  quickActionLabel: { fontSize: 11, color: Colors.textSecondary, textAlign: 'center' },
  settingsGroup: { paddingHorizontal: Spacing.base, marginTop: Spacing.base },
  groupTitle: {
    fontSize: 12, color: Colors.textTertiary, fontWeight: Fonts.semibold as any,
    textAlign: 'right', marginBottom: Spacing.sm, textTransform: 'uppercase',
  },
  groupItems: {
    backgroundColor: Colors.card, borderRadius: Radius.lg,
    borderWidth: 1, borderColor: Colors.border, overflow: 'hidden',
  },
  settingItem: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between',
    padding: Spacing.base,
  },
  settingItemBorder: { borderBottomWidth: 1, borderBottomColor: Colors.border },
  settingItemDanger: { backgroundColor: Colors.errorFaded },
  settingItemRight: { flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.md },
  settingItemLeft: {},
  settingIconBg: {
    width: 36, height: 36, borderRadius: Radius.sm,
    backgroundColor: Colors.primaryFaded, justifyContent: 'center', alignItems: 'center',
  },
  settingIconBgDanger: { backgroundColor: Colors.errorFaded },
  settingIconBgTheme: { backgroundColor: 'rgba(129,140,248,0.12)' },
  settingLabel: { fontSize: 15, color: Colors.text, fontWeight: Fonts.medium as any },
  settingLabelDanger: { color: Colors.error },
  settingValue: { fontSize: 13, color: Colors.textSecondary },
  version: { textAlign: 'center', color: Colors.textTertiary, fontSize: 12, marginTop: Spacing.lg },
});
