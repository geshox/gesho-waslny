-- =====================================================
-- وصّلني — Supabase Database Schema
-- Run this in your Supabase SQL Editor
-- =====================================================

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS postgis; -- for geo queries (optional)

-- =====================================================
-- USERS table
-- =====================================================
CREATE TABLE IF NOT EXISTS public.users (
  id          UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  phone       TEXT UNIQUE NOT NULL,
  full_name   TEXT,
  avatar_url  TEXT,
  rating      NUMERIC(3,2) DEFAULT 5.0,
  total_rides INTEGER DEFAULT 0,
  wallet_balance NUMERIC(10,2) DEFAULT 0.0,
  role        TEXT DEFAULT 'passenger' CHECK (role IN ('passenger','driver','admin')),
  is_verified BOOLEAN DEFAULT FALSE,
  is_active   BOOLEAN DEFAULT TRUE,
  push_token  TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- DRIVERS table
-- =====================================================
CREATE TABLE IF NOT EXISTS public.drivers (
  id                UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id           UUID REFERENCES public.users(id) ON DELETE CASCADE UNIQUE NOT NULL,
  national_id       TEXT NOT NULL,
  license_number    TEXT NOT NULL,
  vehicle_type      TEXT CHECK (vehicle_type IN ('car','tuk','moto','microbus')) NOT NULL,
  vehicle_model     TEXT NOT NULL,
  vehicle_plate     TEXT NOT NULL,
  vehicle_color     TEXT NOT NULL,
  vehicle_year      INTEGER,
  is_online         BOOLEAN DEFAULT FALSE,
  is_approved       BOOLEAN DEFAULT FALSE,
  approval_status   TEXT DEFAULT 'pending' CHECK (approval_status IN ('pending','approved','rejected')),
  rejection_reason  TEXT,
  current_lat       DOUBLE PRECISION,
  current_lng       DOUBLE PRECISION,
  total_earnings    NUMERIC(12,2) DEFAULT 0.0,
  created_at        TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- RIDES table
-- =====================================================
CREATE TABLE IF NOT EXISTS public.rides (
  id                UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  passenger_id      UUID REFERENCES public.users(id) NOT NULL,
  driver_id         UUID REFERENCES public.drivers(id),
  from_address      TEXT NOT NULL,
  to_address        TEXT NOT NULL,
  from_lat          DOUBLE PRECISION NOT NULL,
  from_lng          DOUBLE PRECISION NOT NULL,
  to_lat            DOUBLE PRECISION NOT NULL,
  to_lng            DOUBLE PRECISION NOT NULL,
  status            TEXT DEFAULT 'searching'
                    CHECK (status IN ('searching','accepted','arriving','in_progress','completed','cancelled')),
  vehicle_type      TEXT CHECK (vehicle_type IN ('car','tuk','moto','microbus')) NOT NULL,
  zone              TEXT DEFAULT 'city' CHECK (zone IN ('city','village','intercity')),
  distance_km       NUMERIC(8,2) DEFAULT 0,
  duration_minutes  INTEGER DEFAULT 0,
  price             NUMERIC(10,2) NOT NULL,
  payment_method    TEXT DEFAULT 'cash',
  passenger_rating  SMALLINT CHECK (passenger_rating BETWEEN 1 AND 5),
  driver_rating     SMALLINT CHECK (driver_rating BETWEEN 1 AND 5),
  passenger_review  TEXT,
  driver_review     TEXT,
  started_at        TIMESTAMPTZ,
  completed_at      TIMESTAMPTZ,
  created_at        TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- COMPLAINTS table
-- =====================================================
CREATE TABLE IF NOT EXISTS public.complaints (
  id           UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  reporter_id  UUID REFERENCES public.users(id) NOT NULL,
  ride_id      UUID REFERENCES public.rides(id),
  subject      TEXT NOT NULL,
  description  TEXT NOT NULL,
  status       TEXT DEFAULT 'pending' CHECK (status IN ('pending','reviewing','resolved','dismissed')),
  admin_note   TEXT,
  created_at   TIMESTAMPTZ DEFAULT NOW(),
  resolved_at  TIMESTAMPTZ
);

-- =====================================================
-- ROW LEVEL SECURITY (RLS)
-- =====================================================
ALTER TABLE public.users     ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.drivers   ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rides     ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.complaints ENABLE ROW LEVEL SECURITY;

-- USERS policies
CREATE POLICY "Users can read own profile"
  ON public.users FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON public.users FOR UPDATE
  USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON public.users FOR INSERT
  WITH CHECK (auth.uid() = id);

-- Allow admin full access
CREATE POLICY "Admins have full access to users"
  ON public.users FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- DRIVERS policies
CREATE POLICY "Drivers can read own record"
  ON public.drivers FOR SELECT
  USING (user_id = auth.uid());

CREATE POLICY "Drivers can update own record"
  ON public.drivers FOR UPDATE
  USING (user_id = auth.uid());

CREATE POLICY "Anyone can register as driver"
  ON public.drivers FOR INSERT
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Passengers can view online drivers"
  ON public.drivers FOR SELECT
  USING (is_online = true AND is_approved = true);

-- RIDES policies
CREATE POLICY "Passengers can create rides"
  ON public.rides FOR INSERT
  WITH CHECK (passenger_id = auth.uid());

-- Drivers can see available (searching) rides of their vehicle type
CREATE POLICY "Drivers can view searching rides"
  ON public.rides FOR SELECT
  USING (
    status = 'searching'
    OR passenger_id = auth.uid()
    OR driver_id IN (
      SELECT id FROM public.drivers WHERE user_id = auth.uid()
    )
  );

-- Fallback: users can view own rides
CREATE POLICY "Users can view own rides"
  ON public.rides FOR SELECT
  USING (
    passenger_id = auth.uid()
    OR driver_id IN (
      SELECT id FROM public.drivers WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Drivers can update assigned rides"
  ON public.rides FOR UPDATE
  USING (
    driver_id IN (SELECT id FROM public.drivers WHERE user_id = auth.uid())
    OR passenger_id = auth.uid()
  );

-- COMPLAINTS policies
CREATE POLICY "Users can create complaints"
  ON public.complaints FOR INSERT
  WITH CHECK (reporter_id = auth.uid());

CREATE POLICY "Users can read own complaints"
  ON public.complaints FOR SELECT
  USING (reporter_id = auth.uid());

-- =====================================================
-- WALLET TRANSACTIONS table
-- =====================================================
CREATE TABLE IF NOT EXISTS public.wallet_transactions (
  id             UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id        UUID REFERENCES public.users(id) ON DELETE CASCADE NOT NULL,
  ride_id        UUID REFERENCES public.rides(id),
  type           TEXT CHECK (type IN ('recharge','ride_payment','refund','transfer')) NOT NULL,
  amount         NUMERIC(10,2) NOT NULL,
  balance_after  NUMERIC(10,2) NOT NULL,
  description    TEXT NOT NULL,
  payment_method TEXT,
  status         TEXT DEFAULT 'completed' CHECK (status IN ('pending','completed','failed')),
  created_at     TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.wallet_transactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own transactions"
  ON public.wallet_transactions FOR SELECT
  USING (user_id = auth.uid());

CREATE POLICY "System can insert transactions"
  ON public.wallet_transactions FOR INSERT
  WITH CHECK (user_id = auth.uid());

CREATE INDEX IF NOT EXISTS idx_wallet_tx_user ON public.wallet_transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_wallet_tx_type ON public.wallet_transactions(type);

-- =====================================================
-- DRIVER DOCUMENTS — extend drivers table
-- =====================================================
ALTER TABLE public.drivers
  ADD COLUMN IF NOT EXISTS face_photo_url     TEXT,
  ADD COLUMN IF NOT EXISTS national_id_url    TEXT,
  ADD COLUMN IF NOT EXISTS license_url        TEXT,
  ADD COLUMN IF NOT EXISTS vehicle_photo_url  TEXT;

-- Supabase Storage bucket for driver documents
-- Run in Supabase Dashboard: Storage > Create bucket "driver-documents" (public)

-- =====================================================
-- REALTIME — enable for live updates
-- =====================================================
ALTER PUBLICATION supabase_realtime ADD TABLE public.rides;
ALTER PUBLICATION supabase_realtime ADD TABLE public.drivers;
ALTER PUBLICATION supabase_realtime ADD TABLE public.users;

-- =====================================================
-- ONLINE DRIVERS VIEW — safe public driver info
-- View bypasses RLS on `users` and exposes only public
-- fields (no phone / wallet / email).
-- =====================================================
CREATE OR REPLACE VIEW public.online_drivers AS
SELECT
  d.id,
  d.user_id,
  d.vehicle_type,
  d.vehicle_model,
  d.vehicle_plate,
  d.vehicle_color,
  d.current_lat,
  d.current_lng,
  u.full_name,
  u.avatar_url,
  u.rating,
  u.total_rides
FROM public.drivers d
JOIN public.users u ON u.id = d.user_id
WHERE d.is_online = true
  AND d.is_approved = true;

ALTER VIEW public.online_drivers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view online drivers"
  ON public.online_drivers FOR SELECT
  USING (true);

-- =====================================================
-- INDEXES for performance
-- =====================================================
CREATE INDEX IF NOT EXISTS idx_rides_passenger ON public.rides(passenger_id);
CREATE INDEX IF NOT EXISTS idx_rides_driver ON public.rides(driver_id);
CREATE INDEX IF NOT EXISTS idx_rides_status ON public.rides(status);
CREATE INDEX IF NOT EXISTS idx_rides_vehicle_type ON public.rides(vehicle_type);
CREATE INDEX IF NOT EXISTS idx_drivers_user ON public.drivers(user_id);
CREATE INDEX IF NOT EXISTS idx_drivers_online ON public.drivers(is_online, is_approved);

-- =====================================================
-- RIDE COMPLETION TRIGGER — driver earnings + passenger
-- total_rides are updated atomically by the DB when a
-- ride flips to 'completed' (race-safe, runs once).
-- =====================================================
CREATE OR REPLACE FUNCTION public.on_ride_completed()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.status = 'completed' AND OLD.status IS DISTINCT FROM 'completed' THEN
    IF NEW.driver_id IS NOT NULL THEN
      UPDATE public.drivers
      SET total_earnings = total_earnings + NEW.price
      WHERE id = NEW.driver_id;
    END IF;
    UPDATE public.users
    SET total_rides = total_rides + 1
    WHERE id = NEW.passenger_id;
    NEW.completed_at = COALESCE(NEW.completed_at, NOW());
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trg_ride_completed ON public.rides;
CREATE TRIGGER trg_ride_completed
  BEFORE UPDATE ON public.rides
  FOR EACH ROW EXECUTE FUNCTION public.on_ride_completed();

-- =====================================================
-- ATOMIC WALLET RPCs — balance update + transaction row
-- happen server-side in one statement (no read-then-write
-- race from the client).
-- =====================================================
CREATE OR REPLACE FUNCTION public.recharge_wallet(
  p_user_id UUID,
  p_amount NUMERIC,
  p_payment_method TEXT
)
RETURNS NUMERIC AS $$
DECLARE
  v_new_balance NUMERIC;
BEGIN
  UPDATE public.users
  SET wallet_balance = wallet_balance + p_amount
  WHERE id = p_user_id
  RETURNING wallet_balance INTO v_new_balance;

  INSERT INTO public.wallet_transactions
    (user_id, type, amount, balance_after, description, payment_method, status)
  VALUES
    (p_user_id, 'recharge', p_amount, v_new_balance,
     'شحن رصيد عبر ' || COALESCE(p_payment_method, ''), COALESCE(p_payment_method, 'unknown'), 'completed');

  RETURN v_new_balance;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.pay_ride_from_wallet(
  p_user_id UUID,
  p_ride_id UUID,
  p_amount NUMERIC,
  p_destination TEXT
)
RETURNS TEXT AS $$
DECLARE
  v_balance NUMERIC;
  v_new_balance NUMERIC;
BEGIN
  SELECT wallet_balance INTO v_balance FROM public.users
  WHERE id = p_user_id FOR UPDATE;

  IF v_balance IS NULL THEN
    RETURN 'USER_NOT_FOUND';
  END IF;
  IF v_balance < p_amount THEN
    RETURN 'INSUFFICIENT_FUNDS';
  END IF;

  UPDATE public.users
  SET wallet_balance = wallet_balance - p_amount
  WHERE id = p_user_id
  RETURNING wallet_balance INTO v_new_balance;

  INSERT INTO public.wallet_transactions
    (user_id, ride_id, type, amount, balance_after, description, payment_method, status)
  VALUES
    (p_user_id, p_ride_id, 'ride_payment', -p_amount, v_new_balance,
     'دفع رحلة إلى ' || COALESCE(p_destination, ''), 'wallet', 'completed');

  RETURN 'OK';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
