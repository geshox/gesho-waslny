// Powered by OnSpace.AI
import React, { createContext, useState, useCallback, ReactNode } from 'react';

export type ThemeMode = 'dark' | 'light';

// ──────────────────────────────────────────────
// Colour Palettes
// ──────────────────────────────────────────────

const DARK_COLORS = {
  // Backgrounds — space-inspired deep navy
  background: '#060912',
  surface: '#0C1220',
  card: '#111827',
  cardElevated: '#182033',
  overlay: 'rgba(6, 9, 18, 0.94)',

  // Brand — emerald green
  primary: '#10D876',
  primaryDark: '#0AB85F',
  primaryLight: '#34EE95',
  primaryFaded: 'rgba(16, 216, 118, 0.12)',

  // Accents
  accent: '#6366F1',          // indigo — cosmic feel
  accentFaded: 'rgba(99, 102, 241, 0.14)',
  gold: '#F59E0B',
  goldFaded: 'rgba(245, 158, 11, 0.12)',

  // Text
  text: '#E2E8F0',
  textSecondary: '#8B9AB0',
  textTertiary: '#3D4F6A',
  textInverse: '#060912',

  // Borders
  border: '#182033',
  borderLight: '#22304A',

  // Status
  success: '#22C55E',
  successFaded: 'rgba(34, 197, 94, 0.12)',
  warning: '#F59E0B',
  warningFaded: 'rgba(245, 158, 11, 0.12)',
  error: '#EF4444',
  errorFaded: 'rgba(239, 68, 68, 0.12)',
  info: '#6366F1',
  infoFaded: 'rgba(99, 102, 241, 0.12)',

  // Map
  mapRoad: '#131F38',
  mapBackground: '#0A1223',
  mapWater: '#08152B',

  // Vehicle types
  car: '#10D876',
  tuk: '#F59E0B',
  moto: '#6366F1',
  microbus: '#8B5CF6',

  // Space-theme glow accents
  glow1: 'rgba(16, 216, 118, 0.08)',
  glow2: 'rgba(99, 102, 241, 0.08)',
  starField: '#1A2742',
  nebula: 'rgba(99, 102, 241, 0.06)',
};

const LIGHT_COLORS = {
  // Backgrounds — clean warm whites
  background: '#F8FAFC',
  surface: '#FFFFFF',
  card: '#FFFFFF',
  cardElevated: '#F1F5F9',
  overlay: 'rgba(248, 250, 252, 0.95)',

  // Brand — same emerald
  primary: '#059669',
  primaryDark: '#047857',
  primaryLight: '#10B981',
  primaryFaded: 'rgba(5, 150, 105, 0.10)',

  // Accents
  accent: '#4F46E5',
  accentFaded: 'rgba(79, 70, 229, 0.10)',
  gold: '#D97706',
  goldFaded: 'rgba(217, 119, 6, 0.10)',

  // Text
  text: '#0F172A',
  textSecondary: '#475569',
  textTertiary: '#94A3B8',
  textInverse: '#FFFFFF',

  // Borders
  border: '#E2E8F0',
  borderLight: '#F1F5F9',

  // Status
  success: '#16A34A',
  successFaded: 'rgba(22, 163, 74, 0.10)',
  warning: '#D97706',
  warningFaded: 'rgba(217, 119, 6, 0.10)',
  error: '#DC2626',
  errorFaded: 'rgba(220, 38, 38, 0.10)',
  info: '#4F46E5',
  infoFaded: 'rgba(79, 70, 229, 0.10)',

  // Map
  mapRoad: '#CBD5E1',
  mapBackground: '#E2E8F0',
  mapWater: '#BAE6FD',

  // Vehicle types
  car: '#059669',
  tuk: '#D97706',
  moto: '#4F46E5',
  microbus: '#7C3AED',

  // Space-theme (unused in light but kept for type parity)
  glow1: 'transparent',
  glow2: 'transparent',
  starField: '#F1F5F9',
  nebula: 'transparent',
};

export type AppColors = typeof DARK_COLORS;

export interface ThemeContextType {
  mode: ThemeMode;
  colors: AppColors;
  isDark: boolean;
  toggleTheme: () => void;
  setTheme: (mode: ThemeMode) => void;
}

export const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [mode, setMode] = useState<ThemeMode>('dark');

  const isDark = mode === 'dark';
  const colors = isDark ? DARK_COLORS : LIGHT_COLORS;

  const toggleTheme = useCallback(() => {
    setMode(prev => (prev === 'dark' ? 'light' : 'dark'));
  }, []);

  const setTheme = useCallback((m: ThemeMode) => {
    setMode(m);
  }, []);

  return (
    <ThemeContext.Provider value={{ mode, colors, isDark, toggleTheme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}
