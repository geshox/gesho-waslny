// Powered by OnSpace.AI
import React, { createContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import {
  createRide,
  updateRide,
  getPassengerRides,
  subscribeToRide,
  rateRide,
} from '@/services/rideService';
import {
  notifyRideAccepted,
  notifyDriverArrived,
  notifyRideStarted,
  notifyRideCompleted,
} from '@/services/notificationService';
import { getOnlineDrivers, mapOnlineDriver } from '@/services/driverService';
import { deductRidePayment } from '@/services/walletService';
import { useAuth } from '@/hooks/useAuth';

export type RideStatus =
  | 'idle'
  | 'searching'
  | 'driver_assigned'
  | 'driver_arriving'
  | 'in_progress'
  | 'completed'
  | 'cancelled';

export interface ActiveRide {
  id?: string;
  driver: any;
  from: string;
  to: string;
  status: RideStatus;
  startTime?: Date;
  estimatedArrival: number;
  price: number;
  paymentMethod: string;
  distance?: number;
  fromLat?: number;
  fromLng?: number;
  toLat?: number;
  toLng?: number;
}

export interface RideHistoryItem {
  id: string;
  driverName: string;
  driverAvatar: string;
  vehicleType: string;
  fromLocation: string;
  toLocation: string;
  date: string;
  time: string;
  price: number;
  status: 'completed' | 'cancelled' | 'pending';
  rating?: number;
  distance: number;
  duration: number;
}

interface RideContextType {
  activeRide: ActiveRide | null;
  rideHistory: RideHistoryItem[];
  rideStatus: RideStatus;
  isLoadingHistory: boolean;
  requestRide: (
    driver: any,
    from: string,
    to: string,
    paymentMethod: string,
    passengerId?: string
  ) => Promise<void>;
  cancelRide: () => void;
  completeRide: () => void;
  rateCompletedRide: (rideId: string, rating: number, review: string) => Promise<void>;
  addRideToHistory: (ride: RideHistoryItem) => void;
  loadRideHistory: (passengerId: string) => Promise<void>;
}

export const RideContext = createContext<RideContextType | undefined>(undefined);

export function RideProvider({ children }: { children: ReactNode }) {
  const { updateBalance } = useAuth();
  const [activeRide, setActiveRide] = useState<ActiveRide | null>(null);
  const [rideStatus, setRideStatus] = useState<RideStatus>('idle');
  const [rideHistory, setRideHistory] = useState<RideHistoryItem[]>([]);
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);
  const [activeSubscription, setActiveSubscription] = useState<any>(null);

  const loadRideHistory = useCallback(async (passengerId: string) => {
    if (!isSupabaseConfigured) return;
    setIsLoadingHistory(true);
    const rides = await getPassengerRides(passengerId);
    const mapped: RideHistoryItem[] = rides.map((r) => ({
      id: r.id,
      driverName: r.driver?.user?.full_name ?? 'سائق',
      driverAvatar:
        r.driver?.user?.avatar_url ??
        'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop&crop=face',
      vehicleType: r.vehicle_type,
      fromLocation: r.from_address,
      toLocation: r.to_address,
      date: new Date(r.created_at).toLocaleDateString('ar-EG'),
      time: new Date(r.created_at).toLocaleTimeString('ar-EG', {
        hour: '2-digit',
        minute: '2-digit',
      }),
      price: r.price,
      status:
        r.status === 'completed'
          ? 'completed'
          : r.status === 'cancelled'
          ? 'cancelled'
          : 'pending',
      rating: r.passenger_rating ?? undefined,
      distance: r.distance_km,
      duration: r.duration_minutes,
    }));
    setRideHistory(mapped);
    setIsLoadingHistory(false);
  }, []);

  const requestRide = async (
    driver: any,
    from: string,
    to: string,
    paymentMethod: string,
    passengerId?: string
  ) => {
    setRideStatus('searching');

    let rideId: string | undefined;

    // Real flow — persist the ride and wait for an actual driver to accept
    if (passengerId && isSupabaseConfigured) {
      const { ride, error } = await createRide({
        passenger_id: passengerId,
        from_address: from,
        to_address: to,
        from_lat: driver.lat ?? 30.0626,
        from_lng: driver.lng ?? 31.2497,
        to_lat: driver.lat ? driver.lat + 0.05 : 30.1,
        to_lng: driver.lng ? driver.lng + 0.05 : 31.3,
        vehicle_type: driver.vehicleType,
        zone: 'city',
        distance_km: driver.distance ?? 5,
        duration_minutes: driver.eta ?? 10,
        price: driver.price ?? 30,
        payment_method: paymentMethod,
      });
      if (!error && ride) {
        rideId = ride.id;
        // Tracks the driver actually assigned to the ride (may differ from
        // the one the passenger tapped if another driver accepts first)
        let rideDriver = driver;
        // Subscribe to real-time updates from the driver
        let sub: any = null;
        sub = subscribeToRide(ride.id, async (updated) => {
          if (updated.status === 'accepted') {
            if (updated.driver_id && updated.driver_id !== rideDriver.id) {
              const online = await getOnlineDrivers();
              const row = online.find(d => d.id === updated.driver_id);
              if (row) {
                rideDriver = mapOnlineDriver(row, {
                  latitude: updated.from_lat,
                  longitude: updated.from_lng,
                });
              }
            }
            setActiveRide(prev => (prev ? { ...prev, id: rideId, driver: rideDriver } : prev));
            setRideStatus('driver_assigned');
            await notifyRideAccepted(rideDriver.name, rideDriver.eta);
          } else if (updated.status === 'arriving') {
            setRideStatus('driver_arriving');
            await notifyDriverArrived(rideDriver.name);
          } else if (updated.status === 'in_progress') {
            setRideStatus('in_progress');
            await notifyRideStarted(to);
          } else if (updated.status === 'completed') {
            sub?.unsubscribe();
            setActiveSubscription(null);
            setRideStatus('completed');
            await notifyRideCompleted(updated.price ?? rideDriver.price);
            // Wallet-paid rides deduct on completion
            if (updated.payment_method === 'wallet') {
              const price = updated.price ?? rideDriver.price;
              const { error: walletError } = await deductRidePayment(
                updated.passenger_id,
                updated.id,
                price,
                updated.to_address
              );
              if (!walletError) updateBalance(-price);
            }
            setTimeout(() => {
              setActiveRide(null);
              setRideStatus('idle');
            }, 500);
          } else if (updated.status === 'cancelled') {
            sub?.unsubscribe();
            setActiveSubscription(null);
            setActiveRide(null);
            setRideStatus('idle');
          }
        });
        setActiveSubscription(sub);

        setActiveRide({
          id: rideId,
          driver,
          from,
          to,
          status: 'driver_assigned',
          estimatedArrival: driver.eta,
          price: driver.price,
          paymentMethod,
          distance: driver.distance,
          fromLat: ride.from_lat,
          fromLng: ride.from_lng,
          toLat: ride.to_lat,
          toLng: ride.to_lng,
        });
        return;
      }
    }

    // Demo flow (no Supabase) — simulate ride progression
    setActiveRide({
      id: rideId,
      driver,
      from,
      to,
      status: 'driver_assigned',
      estimatedArrival: driver.eta,
      price: driver.price,
      paymentMethod,
      distance: driver.distance,
    });
    setRideStatus('driver_assigned');
    await notifyRideAccepted(driver.name, driver.eta);

    setTimeout(async () => {
      setRideStatus('driver_arriving');
      await notifyDriverArrived(driver.name);
    }, 4000);

    setTimeout(async () => {
      setRideStatus('in_progress');
      await notifyRideStarted(to);
      if (rideId) await updateRide(rideId, { status: 'in_progress', started_at: new Date().toISOString() });
    }, 8000);
  };

  const cancelRide = async () => {
    if (activeRide?.id && isSupabaseConfigured) {
      await updateRide(activeRide.id, { status: 'cancelled' });
    }
    activeSubscription?.unsubscribe();
    setActiveSubscription(null);
    setActiveRide(null);
    setRideStatus('idle');
  };

  const completeRide = async () => {
    setRideStatus('completed');
    if (activeRide?.id && isSupabaseConfigured) {
      await updateRide(activeRide.id, {
        status: 'completed',
        completed_at: new Date().toISOString(),
      });
    }
    await notifyRideCompleted(activeRide?.price ?? 0);
    activeSubscription?.unsubscribe();
    setActiveSubscription(null);
    setTimeout(() => {
      setActiveRide(null);
      setRideStatus('idle');
    }, 500);
  };

  const rateCompletedRide = async (rideId: string, rating: number, review: string) => {
    if (!isSupabaseConfigured) return;
    await rateRide(rideId, rating, review, 'passenger');
  };

  const addRideToHistory = (ride: RideHistoryItem) => {
    setRideHistory((prev) => [ride, ...prev]);
  };

  return (
    <RideContext.Provider
      value={{
        activeRide,
        rideHistory,
        rideStatus,
        isLoadingHistory,
        requestRide,
        cancelRide,
        completeRide,
        rateCompletedRide,
        addRideToHistory,
        loadRideHistory,
      }}
    >
      {children}
    </RideContext.Provider>
  );
}
