// Powered by OnSpace.AI
import React, { createContext, useState, useEffect, ReactNode } from 'react';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import { getDriverByUserId, getDriverStats, DriverStats } from '@/services/driverService';
import {
  startDriverLocationTracking,
  stopDriverLocationTracking,
  getCurrentLocation,
  DriverLocation,
} from '@/services/locationService';
import { Database } from '@/lib/supabase';

type DriverRow = Database['public']['Tables']['drivers']['Row'];

export interface IncomingRideRequest {
  id: string;
  passenger_id: string;
  from_address: string;
  to_address: string;
  price: number;
  distance_km: number;
  duration_minutes: number;
  vehicle_type: string;
  zone: string;
  created_at: string;
}

interface DriverContextType {
  driverProfile: DriverRow | null;
  isOnline: boolean;
  incomingRequests: IncomingRideRequest[];
  stats: DriverStats | null;
  isLoading: boolean;
  currentLocation: DriverLocation | null;
  toggleOnline: () => Promise<void>;
  loadDriver: (userId: string) => Promise<void>;
  dismissRequest: (rideId: string) => void;
  refreshStats: () => Promise<void>;
}

export const DriverContext = createContext<DriverContextType | undefined>(undefined);

const DEFAULT_STATS: DriverStats = {
  todayEarnings: 0,
  todayRides: 0,
  weekEarnings: 0,
  weekRides: 0,
  avgRating: 5.0,
  totalRides: 0,
  totalEarnings: 0,
  hoursOnline: 0,
};

export function DriverProvider({ children }: { children: ReactNode }) {
  const [driverProfile, setDriverProfile] = useState<DriverRow | null>(null);
  const [isOnline, setIsOnline] = useState(false);
  const [incomingRequests, setIncomingRequests] = useState<IncomingRideRequest[]>([]);
  const [stats, setStats] = useState<DriverStats | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [currentLocation, setCurrentLocation] = useState<DriverLocation | null>(null);

  const loadDriver = async (userId: string) => {
    setIsLoading(true);
    const driver = await getDriverByUserId(userId);
    if (driver) {
      setDriverProfile(driver);
      setIsOnline(driver.is_online);
      const driverStats = await getDriverStats(driver.id);
      setStats(driverStats);

      // Get initial location
      const loc = await getCurrentLocation();
      if (loc) setCurrentLocation(loc);
    }
    setIsLoading(false);
  };

  // ── Location tracking: start when online, stop when offline ──────────────
  useEffect(() => {
    if (!driverProfile) return;

    if (isOnline) {
      startDriverLocationTracking(driverProfile.id, (loc) => {
        setCurrentLocation(loc);
      });
    } else {
      stopDriverLocationTracking();
    }

    return () => {
      stopDriverLocationTracking();
    };
  }, [isOnline, driverProfile?.id]);

  const toggleOnline = async () => {
    if (!driverProfile) return;
    const newStatus = !isOnline;
    setIsOnline(newStatus);

    // Get current GPS before going online
    let lat: number | undefined;
    let lng: number | undefined;
    if (newStatus) {
      const loc = await getCurrentLocation();
      if (loc) {
        lat = loc.lat;
        lng = loc.lng;
        setCurrentLocation(loc);
      }
    }

    const update: any = { is_online: newStatus };
    if (lat !== undefined) update.current_lat = lat;
    if (lng !== undefined) update.current_lng = lng;

    await supabase.from('drivers').update(update).eq('id', driverProfile.id);
  };

  const dismissRequest = (rideId: string) => {
    setIncomingRequests(prev => prev.filter(r => r.id !== rideId));
  };

  const refreshStats = async () => {
    if (!driverProfile) return;
    const driverStats = await getDriverStats(driverProfile.id);
    setStats(driverStats);
  };

  // ── Subscribe to new ride requests when driver is online ──────────────────
  useEffect(() => {
    if (!driverProfile || !isOnline) return;

    const channel = supabase
      .channel('incoming_rides')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'rides',
          filter: `vehicle_type=eq.${driverProfile.vehicle_type}`,
        },
        (payload) => {
          const ride = payload.new as IncomingRideRequest;
          setIncomingRequests(prev => [ride, ...prev].slice(0, 10));
        }
      )
      .subscribe();

    return () => { channel.unsubscribe(); };
  }, [driverProfile?.id, driverProfile?.vehicle_type, isOnline]);

  return (
    <DriverContext.Provider value={{
      driverProfile,
      isOnline,
      incomingRequests,
      stats,
      isLoading,
      currentLocation,
      toggleOnline,
      loadDriver,
      dismissRequest,
      refreshStats,
    }}>
      {children}
    </DriverContext.Provider>
  );
}
