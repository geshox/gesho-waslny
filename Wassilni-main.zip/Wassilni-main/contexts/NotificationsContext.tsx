// Powered by OnSpace.AI
import React, { createContext, useState, useEffect, useCallback, ReactNode } from 'react';
import {
  registerForPushNotifications,
  savePushToken,
} from '@/services/notificationService';
import * as Notifications from 'expo-notifications';

export interface AppNotification {
  id: string;
  title: string;
  body: string;
  time: string;
  icon: string;
  type: string;
  isRead: boolean;
}

interface NotificationsContextType {
  notifications: AppNotification[];
  unreadCount: number;
  addNotification: (n: Omit<AppNotification, 'id' | 'time' | 'isRead'>) => void;
  markAllRead: () => void;
  markRead: (id: string) => void;
  clearAll: () => void;
}

export const NotificationsContext = createContext<NotificationsContextType | undefined>(undefined);

const ICON_MAP: Record<string, string> = {
  ride_accepted: '🚗',
  driver_arrived: '📍',
  ride_started: '▶️',
  ride_completed: '🏁',
  payment_success: '💳',
  new_ride_request: '🛺',
  complaint_update: '📋',
  default: '🔔',
};

export function NotificationsProvider({ children }: { children: ReactNode }) {
  const [notifications, setNotifications] = useState<AppNotification[]>([
    {
      id: 'n001',
      title: 'تم قبول رحلتك',
      body: 'السائق محمود حسن في طريقه إليك',
      time: 'منذ 5 دقائق',
      icon: '🚗',
      type: 'ride_accepted',
      isRead: false,
    },
    {
      id: 'n002',
      title: 'السائق وصل',
      body: 'السائق ينتظرك أمام الموقع المحدد',
      time: 'منذ 12 دقيقة',
      icon: '📍',
      type: 'driver_arrived',
      isRead: false,
    },
    {
      id: 'n003',
      title: 'تم الدفع بنجاح',
      body: 'تم خصم 45 ج.م من محفظتك',
      time: 'أمس',
      icon: '💳',
      type: 'payment_success',
      isRead: true,
    },
  ]);

  // Listen to incoming notifications while app is foregrounded
  useEffect(() => {
    const sub = Notifications.addNotificationReceivedListener((notification) => {
      const { title, body, data } = notification.request.content;
      const type = (data?.type as string) ?? 'default';
      addNotification({
        title: title ?? 'إشعار',
        body: body ?? '',
        icon: ICON_MAP[type] ?? ICON_MAP.default,
        type,
      });
    });

    return () => sub.remove();
  }, []);

  const addNotification = useCallback(
    (n: Omit<AppNotification, 'id' | 'time' | 'isRead'>) => {
      setNotifications((prev) => [
        {
          ...n,
          id: Date.now().toString(),
          time: 'الآن',
          isRead: false,
        },
        ...prev,
      ]);
    },
    []
  );

  const markRead = useCallback((id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isRead: true } : n))
    );
  }, []);

  const markAllRead = useCallback(() => {
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
  }, []);

  const clearAll = useCallback(() => {
    setNotifications([]);
    Notifications.dismissAllNotificationsAsync();
    Notifications.setBadgeCountAsync(0);
  }, []);

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  return (
    <NotificationsContext.Provider
      value={{ notifications, unreadCount, addNotification, markAllRead, markRead, clearAll }}
    >
      {children}
    </NotificationsContext.Provider>
  );
}
