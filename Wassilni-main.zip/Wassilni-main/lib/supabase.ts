// Powered by OnSpace.AI
import { createClient } from '@supabase/supabase-js';
import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Web-safe storage: use localStorage on web to avoid "window is not defined" SSR crash
const webStorage = {
  getItem: async (key: string) => {
    if (typeof localStorage === 'undefined') return null;
    return localStorage.getItem(key);
  },
  setItem: async (key: string, value: string) => {
    if (typeof localStorage === 'undefined') return;
    localStorage.setItem(key, value);
  },
  removeItem: async (key: string) => {
    if (typeof localStorage === 'undefined') return;
    localStorage.removeItem(key);
  },
};

const storage = Platform.OS === 'web' ? webStorage : AsyncStorage;

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL ?? 'https://placeholder.supabase.co';
const supabaseAnonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ?? 'placeholder-anon-key';

export const isSupabaseConfigured =
  !!process.env.EXPO_PUBLIC_SUPABASE_URL &&
  !!process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY &&
  process.env.EXPO_PUBLIC_SUPABASE_URL !== 'https://placeholder.supabase.co';

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    storage: storage as any,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

export type Database = {
  public: {
    Tables: {
      users: {
        Row: {
          id: string;
          phone: string;
          full_name: string | null;
          avatar_url: string | null;
          rating: number;
          total_rides: number;
          wallet_balance: number;
          role: 'passenger' | 'driver' | 'admin';
          is_verified: boolean;
          is_active: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          phone: string;
          full_name?: string | null;
          avatar_url?: string | null;
          rating?: number;
          total_rides?: number;
          wallet_balance?: number;
          role?: 'passenger' | 'driver' | 'admin';
          is_verified?: boolean;
          is_active?: boolean;
        };
        Update: {
          full_name?: string | null;
          avatar_url?: string | null;
          wallet_balance?: number;
          is_verified?: boolean;
          is_active?: boolean;
        };
      };
      drivers: {
        Row: {
          id: string;
          user_id: string;
          national_id: string;
          license_number: string;
          vehicle_type: 'car' | 'tuk' | 'moto' | 'microbus';
          vehicle_model: string;
          vehicle_plate: string;
          vehicle_color: string;
          vehicle_year: number;
          is_online: boolean;
          is_approved: boolean;
          approval_status: 'pending' | 'approved' | 'rejected';
          current_lat: number | null;
          current_lng: number | null;
          total_earnings: number;
          created_at: string;
        };
        Insert: {
          user_id: string;
          national_id: string;
          license_number: string;
          vehicle_type: 'car' | 'tuk' | 'moto' | 'microbus';
          vehicle_model: string;
          vehicle_plate: string;
          vehicle_color: string;
          vehicle_year: number;
        };
        Update: {
          is_online?: boolean;
          current_lat?: number | null;
          current_lng?: number | null;
        };
      };
      rides: {
        Row: {
          id: string;
          passenger_id: string;
          driver_id: string | null;
          from_address: string;
          to_address: string;
          from_lat: number;
          from_lng: number;
          to_lat: number;
          to_lng: number;
          status: 'searching' | 'accepted' | 'arriving' | 'in_progress' | 'completed' | 'cancelled';
          vehicle_type: 'car' | 'tuk' | 'moto' | 'microbus';
          zone: 'city' | 'village' | 'intercity';
          distance_km: number;
          duration_minutes: number;
          price: number;
          payment_method: string;
          passenger_rating: number | null;
          driver_rating: number | null;
          passenger_review: string | null;
          driver_review: string | null;
          started_at: string | null;
          completed_at: string | null;
          created_at: string;
        };
        Insert: {
          passenger_id: string;
          from_address: string;
          to_address: string;
          from_lat: number;
          from_lng: number;
          to_lat: number;
          to_lng: number;
          vehicle_type: 'car' | 'tuk' | 'moto' | 'microbus';
          zone: 'city' | 'village' | 'intercity';
          distance_km: number;
          duration_minutes: number;
          price: number;
          payment_method: string;
        };
        Update: {
          driver_id?: string | null;
          status?: 'searching' | 'accepted' | 'arriving' | 'in_progress' | 'completed' | 'cancelled';
          passenger_rating?: number | null;
          driver_rating?: number | null;
          passenger_review?: string | null;
          driver_review?: string | null;
          started_at?: string | null;
          completed_at?: string | null;
        };
      };
    };
  };
};
