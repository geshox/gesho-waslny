// Powered by OnSpace.AI
import { useContext } from 'react';
import { DriverContext } from '@/contexts/DriverContext';

export function useDriver() {
  const context = useContext(DriverContext);
  if (!context) throw new Error('useDriver must be used within DriverProvider');
  return context;
}

export type { IncomingRideRequest } from '@/contexts/DriverContext';
