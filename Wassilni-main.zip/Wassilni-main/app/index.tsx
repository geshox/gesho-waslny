// Powered by OnSpace.AI
import React, { useEffect } from 'react';
import { View, ActivityIndicator, StyleSheet } from 'react-native';
import { useRouter } from 'expo-router';
import { useAuth } from '@/hooks/useAuth';
import { Colors } from '@/constants/theme';

export default function Index() {
  const router = useRouter();
  const { isAuthenticated, isLoading, user } = useAuth();

  useEffect(() => {
    if (isLoading) return;
    if (!isAuthenticated) {
      router.replace('/onboarding');
    } else if (user?.role === 'driver') {
      router.replace('/(driver)');
    } else {
      router.replace('/(tabs)');
    }
  }, [isAuthenticated, isLoading, user?.role]);

  return (
    <View style={styles.container}>
      <ActivityIndicator size="large" color={Colors.primary} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#070B14', justifyContent: 'center', alignItems: 'center' },
});
