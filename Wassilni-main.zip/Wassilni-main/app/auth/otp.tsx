// Powered by OnSpace.AI
import React, { useState, useRef, useEffect } from 'react';
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity,
  KeyboardAvoidingView, Platform, ActivityIndicator, Animated,
} from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Spacing, Radius, Fonts, Shadow } from '@/constants/theme';
import { useAuth } from '@/hooks/useAuth';
import { isSupabaseConfigured } from '@/lib/supabase';

export default function OTP() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { phone } = useLocalSearchParams<{ phone: string }>();
  const { verifyOTP, isLoading, login, authError, clearAuthError } = useAuth();
  const [code, setCode] = useState(['', '', '', '', '', '']);
  const [error, setError] = useState('');
  const [countdown, setCountdown] = useState(60);
  const inputRefs = useRef<(TextInput | null)[]>([]);
  const shakeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const timer = setInterval(() => setCountdown(prev => (prev > 0 ? prev - 1 : 0)), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (authError) setError(authError);
  }, [authError]);

  const handleCodeChange = (text: string, index: number) => {
    const newCode = [...code];
    newCode[index] = text;
    setCode(newCode);
    setError('');
    clearAuthError();

    if (text && index < 5) inputRefs.current[index + 1]?.focus();
    if (newCode.every(c => c !== '')) handleVerify(newCode.join(''));
  };

  const handleKeyPress = (key: string, index: number) => {
    if (key === 'Backspace' && !code[index] && index > 0) inputRefs.current[index - 1]?.focus();
  };

  const shake = () => {
    Animated.sequence([
      Animated.timing(shakeAnim, { toValue: 10, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -10, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 10, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 0, duration: 60, useNativeDriver: true }),
    ]).start();
  };

  const handleVerify = async (otp: string) => {
    const success = await verifyOTP(otp);
    if (success) {
      router.replace('/(tabs)');
    } else {
      shake();
      setCode(['', '', '', '', '', '']);
      inputRefs.current[0]?.focus();
    }
  };

  const resendOTP = async () => {
    setCountdown(60);
    setCode(['', '', '', '', '', '']);
    setError('');
    clearAuthError();
    await login(phone ?? '');
    inputRefs.current[0]?.focus();
  };

  const maskedPhone = phone ? phone.slice(0, -4) + '****' : '****';

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: Colors.background }}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <View style={[styles.container, { paddingTop: insets.top + 16, paddingBottom: insets.bottom + 20 }]}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <MaterialIcons name="arrow-forward" size={24} color={Colors.text} />
        </TouchableOpacity>

        <View style={styles.content}>
          <View style={styles.iconContainer}>
            <LinearGradient colors={[Colors.primary + '20', Colors.primaryDark + '20']} style={styles.iconBg}>
              <MaterialIcons name="sms" size={36} color={Colors.primary} />
            </LinearGradient>
          </View>

          <Text style={styles.title}>التحقق من الهاتف</Text>
          <Text style={styles.subtitle}>
            أُرسل رمز التحقق المكوّن من 6 أرقام إلى{'\n'}
            <Text style={styles.phoneText}>{maskedPhone}</Text>
          </Text>

          {/* 6-digit OTP inputs */}
          <Animated.View style={[styles.otpContainer, { transform: [{ translateX: shakeAnim }] }]}>
            {code.map((digit, index) => (
              <TextInput
                key={index}
                ref={ref => { inputRefs.current[index] = ref; }}
                style={[
                  styles.otpInput,
                  digit ? styles.otpInputFilled : null,
                  error ? styles.otpInputError : null,
                ]}
                value={digit}
                onChangeText={(text) => handleCodeChange(text.slice(-1), index)}
                onKeyPress={({ nativeEvent }) => handleKeyPress(nativeEvent.key, index)}
                keyboardType="number-pad"
                maxLength={1}
                textAlign="center"
                autoFocus={index === 0}
                selectTextOnFocus
              />
            ))}
          </Animated.View>

          {error ? (
            <View style={styles.errorRow}>
              <MaterialIcons name="error-outline" size={14} color={Colors.error} />
              <Text style={styles.errorText}>{error}</Text>
            </View>
          ) : null}

          <TouchableOpacity
            style={[styles.verifyButton, (isLoading || code.some(c => !c)) && styles.verifyButtonDisabled]}
            onPress={() => handleVerify(code.join(''))}
            disabled={isLoading || code.some(c => !c)}
            activeOpacity={0.85}
          >
            <LinearGradient
              colors={[Colors.primary, Colors.primaryDark]}
              style={styles.verifyGradient}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
            >
              {isLoading ? (
                <ActivityIndicator color={Colors.textInverse} />
              ) : (
                <Text style={styles.verifyText}>تحقق الآن</Text>
              )}
            </LinearGradient>
          </TouchableOpacity>

          <View style={styles.resendContainer}>
            {countdown > 0 ? (
              <Text style={styles.countdownText}>
                إعادة الإرسال خلال{' '}
                <Text style={styles.countdownNumber}>{countdown}</Text>
                {' '}ثانية
              </Text>
            ) : (
              <TouchableOpacity onPress={resendOTP}>
                <Text style={styles.resendText}>إعادة إرسال رمز التحقق</Text>
              </TouchableOpacity>
            )}
          </View>

          <View style={styles.infoBox}>
            <MaterialIcons name="info-outline" size={14} color={Colors.accent} />
            <Text style={styles.infoText}>
              {isSupabaseConfigured
                ? 'تحقق من رسائل SMS على الرقم المُدخل'
                : 'وضع تجريبي — أدخل أي 6 أرقام للمتابعة'}
            </Text>
          </View>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background, paddingHorizontal: Spacing.xl },
  backButton: { width: 44, height: 44, justifyContent: 'center', alignItems: 'flex-start', alignSelf: 'flex-end' },
  content: { flex: 1, alignItems: 'center', justifyContent: 'center', marginTop: -40 },
  iconContainer: { marginBottom: Spacing.xl },
  iconBg: { width: 88, height: 88, borderRadius: Radius.xl, justifyContent: 'center', alignItems: 'center', ...Shadow.glow },
  title: { fontSize: 26, fontWeight: Fonts.bold as any, color: Colors.text, marginBottom: Spacing.md, textAlign: 'center' },
  subtitle: { fontSize: 15, color: Colors.textSecondary, textAlign: 'center', lineHeight: 24, marginBottom: Spacing.xl },
  phoneText: { color: Colors.primary, fontWeight: Fonts.semibold as any },
  otpContainer: { flexDirection: 'row-reverse', gap: Spacing.sm, marginBottom: Spacing.md },
  otpInput: {
    width: 46, height: 56, borderRadius: Radius.md, borderWidth: 2, borderColor: Colors.border,
    backgroundColor: Colors.card, color: Colors.text, fontSize: 22, fontWeight: Fonts.bold as any, textAlign: 'center',
  },
  otpInputFilled: { borderColor: Colors.primary, backgroundColor: Colors.primaryFaded },
  otpInputError: { borderColor: Colors.error },
  errorRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 4, marginBottom: Spacing.lg },
  errorText: { color: Colors.error, fontSize: 13 },
  verifyButton: { width: '100%', borderRadius: Radius.md, overflow: 'hidden', marginTop: Spacing.lg, ...Shadow.glow },
  verifyButtonDisabled: { opacity: 0.5 },
  verifyGradient: { paddingVertical: 16, alignItems: 'center' },
  verifyText: { color: Colors.textInverse, fontSize: 16, fontWeight: Fonts.bold as any },
  resendContainer: { marginTop: Spacing.lg, alignItems: 'center' },
  countdownText: { color: Colors.textSecondary, fontSize: 14 },
  countdownNumber: { color: Colors.primary, fontWeight: Fonts.semibold as any },
  resendText: { color: Colors.primary, fontSize: 14, fontWeight: Fonts.semibold as any },
  infoBox: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: 6,
    backgroundColor: Colors.accentFaded, borderRadius: Radius.md, padding: Spacing.md,
    marginTop: Spacing.lg, borderWidth: 1, borderColor: Colors.accent + '30',
  },
  infoText: { flex: 1, color: Colors.accent, fontSize: 12, lineHeight: 18, textAlign: 'right' },
});
