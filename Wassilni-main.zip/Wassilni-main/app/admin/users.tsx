// Powered by OnSpace.AI
import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, TextInput,
  Modal, Alert, Platform, ActivityIndicator, RefreshControl, ScrollView,
} from 'react-native';
import { Image } from 'expo-image';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Spacing, Radius, Fonts, Shadow } from '@/constants/theme';
import {
  getAllPassengers,
  getAllDrivers,
  toggleUserStatus,
  updateDriverApproval,
  getAdminStats,
  AdminUser,
  AdminDriver,
} from '@/services/adminService';

type TabType = 'passengers' | 'drivers';
type DriverFilter = 'all' | 'pending' | 'approved' | 'rejected';

const APPROVAL_COLORS: Record<string, string> = {
  approved: Colors.success,
  pending:  Colors.warning,
  rejected: Colors.error,
};
const APPROVAL_LABELS: Record<string, string> = {
  approved: 'معتمد',
  pending:  'قيد المراجعة',
  rejected: 'مرفوض',
};
const VEHICLE_ICONS: Record<string, string> = {
  car: '🚗', tuk: '🛺', moto: '🏍️', microbus: '🚐',
};

export default function UsersManagement() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [tab, setTab] = useState<TabType>('passengers');
  const [search, setSearch] = useState('');
  const [driverFilter, setDriverFilter] = useState<DriverFilter>('all');
  const [passengers, setPassengers] = useState<AdminUser[]>([]);
  const [drivers, setDrivers] = useState<AdminDriver[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [selectedDriver, setSelectedDriver] = useState<AdminDriver | null>(null);
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  const loadData = useCallback(async () => {
    const [p, d, s] = await Promise.all([
      getAllPassengers(),
      getAllDrivers(),
      getAdminStats(),
    ]);
    setPassengers(p);
    setDrivers(d);
    setStats(s);
  }, []);

  useEffect(() => {
    loadData().finally(() => setIsLoading(false));
  }, []);

  const onRefresh = async () => {
    setIsRefreshing(true);
    await loadData();
    setIsRefreshing(false);
  };

  const handleToggleUser = async (userId: string, currentStatus: boolean) => {
    const newStatus = !currentStatus;
    const action = newStatus ? 'تفعيل' : 'تعليق';
    if (Platform.OS !== 'web') {
      Alert.alert(
        `تأكيد ${action} الحساب`,
        `هل تريد ${action} هذا الحساب؟`,
        [
          { text: 'إلغاء', style: 'cancel' },
          {
            text: action,
            style: newStatus ? 'default' : 'destructive',
            onPress: async () => {
              setActionLoading(userId);
              const { error } = await toggleUserStatus(userId, newStatus);
              if (!error) {
                setPassengers(prev =>
                  prev.map(p => p.id === userId ? { ...p, is_active: newStatus } : p)
                );
                setDrivers(prev =>
                  prev.map(d => d.id === userId ? { ...d, is_active: newStatus } : d)
                );
              }
              setActionLoading(null);
            },
          },
        ]
      );
    } else {
      setActionLoading(userId);
      const { error } = await toggleUserStatus(userId, newStatus);
      if (!error) {
        setPassengers(prev =>
          prev.map(p => p.id === userId ? { ...p, is_active: newStatus } : p)
        );
      }
      setActionLoading(null);
    }
  };

  const handleDriverApproval = async (
    driverId: string,
    userId: string,
    status: 'approved' | 'rejected'
  ) => {
    const label = status === 'approved' ? 'قبول' : 'رفض';
    setActionLoading(driverId);
    const { error } = await updateDriverApproval(driverId, status, userId);
    if (!error) {
      setDrivers(prev =>
        prev.map(d =>
          d.driver_id === driverId
            ? { ...d, approval_status: status, is_verified: status === 'approved' }
            : d
        )
      );
      setSelectedDriver(prev =>
        prev && prev.driver_id === driverId
          ? { ...prev, approval_status: status }
          : prev
      );
    }
    setActionLoading(null);
    if (Platform.OS !== 'web') Alert.alert('تم', `تم ${label} السائق بنجاح`);
  };

  const filteredPassengers = passengers.filter(p =>
    !search || (p.full_name ?? '').includes(search) || p.phone.includes(search)
  );

  const filteredDrivers = drivers.filter(d => {
    const matchSearch = !search || (d.full_name ?? '').includes(search) || d.phone.includes(search);
    const matchFilter = driverFilter === 'all' || d.approval_status === driverFilter;
    return matchSearch && matchFilter;
  });

  const renderPassenger = ({ item }: { item: AdminUser }) => (
    <View style={styles.userCard}>
      <View style={styles.userCardActions}>
        {actionLoading === item.id ? (
          <ActivityIndicator size="small" color={Colors.primary} />
        ) : (
          <TouchableOpacity
            style={[styles.actionBtn, item.is_active ? styles.actionDanger : styles.actionSuccess]}
            onPress={() => handleToggleUser(item.id, item.is_active)}
          >
            <MaterialIcons
              name={item.is_active ? 'block' : 'check-circle'}
              size={14}
              color={item.is_active ? Colors.error : Colors.success}
            />
            <Text style={{ fontSize: 11, color: item.is_active ? Colors.error : Colors.success }}>
              {item.is_active ? 'تعليق' : 'تفعيل'}
            </Text>
          </TouchableOpacity>
        )}
        <View style={[styles.statusDot, { backgroundColor: item.is_active ? Colors.success : Colors.error }]} />
      </View>

      <View style={styles.userInfo}>
        <Image source={{ uri: item.avatar_url ?? '' }} style={styles.avatar} contentFit="cover" />
        <View style={styles.userDetails}>
          <View style={styles.nameRow}>
            {!item.is_verified ? (
              <MaterialIcons name="warning" size={12} color={Colors.warning} />
            ) : null}
            <Text style={styles.userName}>{item.full_name ?? 'غير محدد'}</Text>
          </View>
          <Text style={styles.userPhone}>{item.phone}</Text>
          <View style={styles.userMeta}>
            <Text style={styles.metaText}>💰 {item.wallet_balance.toFixed(0)} ج</Text>
            <Text style={styles.metaSep}>•</Text>
            <Text style={styles.metaText}>{item.total_rides} رحلة</Text>
            <Text style={styles.metaSep}>•</Text>
            <MaterialIcons name="star" size={11} color={Colors.gold} />
            <Text style={styles.metaText}>{item.rating.toFixed(1)}</Text>
          </View>
        </View>
      </View>
    </View>
  );

  const renderDriver = ({ item }: { item: AdminDriver }) => {
    const approvalColor = APPROVAL_COLORS[item.approval_status] ?? Colors.textTertiary;
    return (
      <TouchableOpacity
        style={styles.userCard}
        onPress={() => setSelectedDriver(item)}
        activeOpacity={0.85}
      >
        <View style={styles.userCardActions}>
          <TouchableOpacity
            style={[styles.actionBtn, item.is_active ? styles.actionDanger : styles.actionSuccess]}
            onPress={(e) => {
              e.stopPropagation?.();
              handleToggleUser(item.id, item.is_active);
            }}
          >
            <MaterialIcons
              name={item.is_active ? 'block' : 'check-circle'}
              size={14}
              color={item.is_active ? Colors.error : Colors.success}
            />
            <Text style={{ fontSize: 11, color: item.is_active ? Colors.error : Colors.success }}>
              {item.is_active ? 'تعليق' : 'تفعيل'}
            </Text>
          </TouchableOpacity>
          <View style={[styles.approvalBadge, { backgroundColor: approvalColor + '18' }]}>
            <Text style={[styles.approvalText, { color: approvalColor }]}>
              {APPROVAL_LABELS[item.approval_status]}
            </Text>
          </View>
        </View>

        <View style={styles.userInfo}>
          <View style={styles.driverAvatarWrap}>
            <Image source={{ uri: item.avatar_url ?? '' }} style={styles.avatar} contentFit="cover" />
            {item.is_online ? <View style={styles.onlineDot} /> : null}
          </View>
          <View style={styles.userDetails}>
            <Text style={styles.userName}>{item.full_name ?? 'غير محدد'}</Text>
            <Text style={styles.vehicleText}>
              {VEHICLE_ICONS[item.vehicle_type]} {item.vehicle_model}
            </Text>
            <View style={styles.userMeta}>
              <Text style={styles.metaText}>💰 {item.total_earnings.toFixed(0)} ج</Text>
              <Text style={styles.metaSep}>•</Text>
              <Text style={styles.metaText}>{item.total_rides} رحلة</Text>
              {item.rating > 0 ? (
                <>
                  <Text style={styles.metaSep}>•</Text>
                  <MaterialIcons name="star" size={11} color={Colors.gold} />
                  <Text style={styles.metaText}>{item.rating.toFixed(1)}</Text>
                </>
              ) : null}
            </View>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  if (isLoading) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center', paddingTop: insets.top }]}>
        <ActivityIndicator size="large" color={Colors.primary} />
      </View>
    );
  }

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
          <MaterialIcons name="arrow-forward" size={22} color={Colors.text} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>إدارة المستخدمين</Text>
        <View style={{ width: 40 }} />
      </View>

      {/* Stats row */}
      {stats ? (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.statsScroll}>
          <View style={styles.statsRow}>
            {[
              { label: 'الركاب', value: stats.totalUsers, icon: 'people', color: Colors.primary },
              { label: 'السائقون', value: stats.totalDrivers, icon: 'drive-eta', color: Colors.accent },
              { label: 'قيد المراجعة', value: stats.pendingDrivers, icon: 'pending', color: Colors.warning },
              { label: 'متصلون الآن', value: stats.activeDrivers, icon: 'wifi', color: Colors.success },
              { label: 'إجمالي الرحلات', value: stats.totalRides, icon: 'directions-car', color: Colors.gold },
            ].map((s, i) => (
              <View key={i} style={styles.statCard}>
                <MaterialIcons name={s.icon as any} size={16} color={s.color} />
                <Text style={[styles.statVal, { color: s.color }]}>{s.value}</Text>
                <Text style={styles.statLabel}>{s.label}</Text>
              </View>
            ))}
          </View>
        </ScrollView>
      ) : null}

      {/* Tabs */}
      <View style={styles.tabsRow}>
        {([
          { key: 'passengers', label: `الركاب (${passengers.length})` },
          { key: 'drivers', label: `السائقون (${drivers.length})` },
        ] as const).map(t => (
          <TouchableOpacity
            key={t.key}
            style={[styles.tabBtn, tab === t.key && styles.tabBtnActive]}
            onPress={() => setTab(t.key)}
          >
            <Text style={[styles.tabBtnText, tab === t.key && styles.tabBtnTextActive]}>
              {t.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Search */}
      <View style={styles.searchRow}>
        <MaterialIcons name="search" size={18} color={Colors.textTertiary} />
        <TextInput
          style={styles.searchInput}
          placeholder="بحث بالاسم أو رقم الهاتف..."
          placeholderTextColor={Colors.textTertiary}
          value={search}
          onChangeText={setSearch}
          textAlign="right"
        />
        {search ? (
          <TouchableOpacity onPress={() => setSearch('')}>
            <MaterialIcons name="close" size={18} color={Colors.textTertiary} />
          </TouchableOpacity>
        ) : null}
      </View>

      {/* Driver status filter */}
      {tab === 'drivers' ? (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filterScroll}>
          <View style={styles.filterRow}>
            {([
              { key: 'all',      label: `الكل (${drivers.length})` },
              { key: 'pending',  label: `قيد المراجعة (${drivers.filter(d => d.approval_status === 'pending').length})` },
              { key: 'approved', label: `معتمدون (${drivers.filter(d => d.approval_status === 'approved').length})` },
              { key: 'rejected', label: `مرفوضون (${drivers.filter(d => d.approval_status === 'rejected').length})` },
            ] as const).map(f => (
              <TouchableOpacity
                key={f.key}
                style={[styles.filterChip, driverFilter === f.key && styles.filterChipActive]}
                onPress={() => setDriverFilter(f.key)}
              >
                <Text style={[styles.filterChipText, driverFilter === f.key && styles.filterChipTextActive]}>
                  {f.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>
      ) : null}

      {/* List */}
      {tab === 'passengers' ? (
        <FlatList
          data={filteredPassengers}
          renderItem={renderPassenger}
          keyExtractor={i => i.id}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          refreshControl={<RefreshControl refreshing={isRefreshing} onRefresh={onRefresh} tintColor={Colors.primary} />}
          ListEmptyComponent={
            <View style={styles.emptyState}>
              <MaterialIcons name="people-outline" size={44} color={Colors.textTertiary} />
              <Text style={styles.emptyText}>لا توجد نتائج</Text>
            </View>
          }
        />
      ) : (
        <FlatList
          data={filteredDrivers}
          renderItem={renderDriver}
          keyExtractor={i => i.driver_id}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          refreshControl={<RefreshControl refreshing={isRefreshing} onRefresh={onRefresh} tintColor={Colors.primary} />}
          ListEmptyComponent={
            <View style={styles.emptyState}>
              <MaterialIcons name="drive-eta" size={44} color={Colors.textTertiary} />
              <Text style={styles.emptyText}>لا توجد نتائج</Text>
            </View>
          }
        />
      )}

      {/* Driver Details Modal */}
      <Modal
        visible={!!selectedDriver}
        transparent
        animationType="slide"
        onRequestClose={() => setSelectedDriver(null)}
      >
        <View style={styles.modalOverlay}>
          <View style={[styles.driverModal, { paddingBottom: insets.bottom + 20 }]}>
            <View style={styles.modalHandle} />
            <View style={styles.driverModalHeader}>
              <TouchableOpacity onPress={() => setSelectedDriver(null)}>
                <MaterialIcons name="close" size={22} color={Colors.textSecondary} />
              </TouchableOpacity>
              <Text style={styles.driverModalTitle}>تفاصيل السائق</Text>
              <View style={{ width: 22 }} />
            </View>

            {selectedDriver ? (
              <ScrollView showsVerticalScrollIndicator={false}>
                {/* Avatar & name */}
                <View style={styles.driverProfile}>
                  <View style={styles.driverAvatarWrap2}>
                    <Image
                      source={{ uri: selectedDriver.avatar_url ?? '' }}
                      style={styles.driverModalAvatar}
                      contentFit="cover"
                    />
                    <View style={[
                      styles.approvalDot,
                      { backgroundColor: APPROVAL_COLORS[selectedDriver.approval_status] }
                    ]} />
                  </View>
                  <Text style={styles.driverModalName}>{selectedDriver.full_name ?? 'غير محدد'}</Text>
                  <Text style={styles.driverModalPhone}>{selectedDriver.phone}</Text>
                  <View style={[
                    styles.approvalBadgeLg,
                    { backgroundColor: APPROVAL_COLORS[selectedDriver.approval_status] + '18' }
                  ]}>
                    <Text style={[
                      styles.approvalBadgeLgText,
                      { color: APPROVAL_COLORS[selectedDriver.approval_status] }
                    ]}>
                      {APPROVAL_LABELS[selectedDriver.approval_status]}
                    </Text>
                  </View>
                </View>

                {/* Vehicle & stats */}
                <View style={styles.driverInfoGrid}>
                  {[
                    { label: 'نوع المركبة', value: `${VEHICLE_ICONS[selectedDriver.vehicle_type]} ${selectedDriver.vehicle_type === 'car' ? 'سيارة' : selectedDriver.vehicle_type === 'tuk' ? 'توكتوك' : selectedDriver.vehicle_type === 'moto' ? 'موتوسيكل' : 'ميكروباص'}` },
                    { label: 'الموديل', value: selectedDriver.vehicle_model },
                    { label: 'رقم اللوحة', value: selectedDriver.vehicle_plate },
                    { label: 'اللون', value: selectedDriver.vehicle_color },
                    { label: 'إجمالي الرحلات', value: `${selectedDriver.total_rides} رحلة` },
                    { label: 'إجمالي الأرباح', value: `${selectedDriver.total_earnings.toFixed(0)} ج.م` },
                    { label: 'التقييم', value: selectedDriver.rating > 0 ? `⭐ ${selectedDriver.rating.toFixed(1)}` : 'لا يوجد بعد' },
                    { label: 'الموقع الجغرافي', value: selectedDriver.current_lat ? `${selectedDriver.current_lat.toFixed(4)}, ${selectedDriver.current_lng?.toFixed(4)}` : 'غير متاح' },
                  ].map((row, i) => (
                    <View key={i} style={styles.infoRow}>
                      <Text style={styles.infoVal}>{row.value}</Text>
                      <Text style={styles.infoLabel}>{row.label}</Text>
                    </View>
                  ))}
                </View>

                {/* Documents */}
                <Text style={styles.docsTitle}>المستندات المرفوعة</Text>
                <View style={styles.docsList}>
                  {[
                    { label: 'صورة الوجه', url: selectedDriver.face_photo_url, icon: '🤳' },
                    { label: 'بطاقة الهوية', url: selectedDriver.national_id_url, icon: '🪪' },
                    { label: 'رخصة القيادة', url: selectedDriver.license_url, icon: '📋' },
                  ].map((doc, i) => (
                    <View key={i} style={styles.docRow}>
                      <View style={[
                        styles.docStatus,
                        { backgroundColor: doc.url ? Colors.successFaded : Colors.errorFaded }
                      ]}>
                        <MaterialIcons
                          name={doc.url ? 'check-circle' : 'cancel'}
                          size={14}
                          color={doc.url ? Colors.success : Colors.error}
                        />
                        <Text style={{ fontSize: 11, color: doc.url ? Colors.success : Colors.error }}>
                          {doc.url ? 'مرفوع' : 'غير مرفوع'}
                        </Text>
                      </View>
                      <View style={styles.docRowLeft}>
                        <Text style={styles.docIcon}>{doc.icon}</Text>
                        <Text style={styles.docLabel}>{doc.label}</Text>
                      </View>
                    </View>
                  ))}
                </View>

                {/* Approval actions */}
                {selectedDriver.approval_status === 'pending' ? (
                  <View style={styles.approvalActions}>
                    <TouchableOpacity
                      style={[styles.approveBtn, { backgroundColor: Colors.errorFaded, borderColor: Colors.error + '40' }]}
                      onPress={() => handleDriverApproval(selectedDriver.driver_id, selectedDriver.id, 'rejected')}
                      disabled={!!actionLoading}
                    >
                      {actionLoading === selectedDriver.driver_id ? (
                        <ActivityIndicator size="small" color={Colors.error} />
                      ) : (
                        <>
                          <MaterialIcons name="close" size={18} color={Colors.error} />
                          <Text style={[styles.approveBtnText, { color: Colors.error }]}>رفض</Text>
                        </>
                      )}
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={[styles.approveBtn, { backgroundColor: Colors.successFaded, borderColor: Colors.success + '40', flex: 2 }]}
                      onPress={() => handleDriverApproval(selectedDriver.driver_id, selectedDriver.id, 'approved')}
                      disabled={!!actionLoading}
                    >
                      {actionLoading === selectedDriver.driver_id ? (
                        <ActivityIndicator size="small" color={Colors.success} />
                      ) : (
                        <>
                          <MaterialIcons name="check-circle" size={18} color={Colors.success} />
                          <Text style={[styles.approveBtnText, { color: Colors.success }]}>قبول السائق ✅</Text>
                        </>
                      )}
                    </TouchableOpacity>
                  </View>
                ) : selectedDriver.approval_status === 'approved' ? (
                  <View style={styles.approvalActions}>
                    <TouchableOpacity
                      style={[styles.approveBtn, { flex: 1, backgroundColor: Colors.errorFaded, borderColor: Colors.error + '40' }]}
                      onPress={() => handleDriverApproval(selectedDriver.driver_id, selectedDriver.id, 'rejected')}
                      disabled={!!actionLoading}
                    >
                      <MaterialIcons name="block" size={18} color={Colors.error} />
                      <Text style={[styles.approveBtnText, { color: Colors.error }]}>إلغاء الاعتماد</Text>
                    </TouchableOpacity>
                  </View>
                ) : (
                  <View style={styles.approvalActions}>
                    <TouchableOpacity
                      style={[styles.approveBtn, { flex: 1, backgroundColor: Colors.successFaded, borderColor: Colors.success + '40' }]}
                      onPress={() => handleDriverApproval(selectedDriver.driver_id, selectedDriver.id, 'approved')}
                      disabled={!!actionLoading}
                    >
                      <MaterialIcons name="check-circle" size={18} color={Colors.success} />
                      <Text style={[styles.approveBtnText, { color: Colors.success }]}>إعادة الاعتماد</Text>
                    </TouchableOpacity>
                  </View>
                )}
                <View style={{ height: 16 }} />
              </ScrollView>
            ) : null}
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.base, paddingVertical: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  backBtn: {
    width: 40, height: 40, justifyContent: 'center', alignItems: 'center',
    backgroundColor: Colors.card, borderRadius: 20, borderWidth: 1, borderColor: Colors.border,
  },
  headerTitle: { fontSize: 18, fontWeight: Fonts.bold as any, color: Colors.text },
  statsScroll: { borderBottomWidth: 1, borderBottomColor: Colors.border },
  statsRow: { flexDirection: 'row-reverse', paddingHorizontal: Spacing.base, paddingVertical: Spacing.sm, gap: Spacing.sm },
  statCard: {
    backgroundColor: Colors.card, borderRadius: Radius.md, padding: Spacing.sm,
    alignItems: 'center', gap: 3, borderWidth: 1, borderColor: Colors.border, minWidth: 80,
  },
  statVal: { fontSize: 16, fontWeight: Fonts.bold as any },
  statLabel: { fontSize: 10, color: Colors.textTertiary, textAlign: 'center' },
  tabsRow: { flexDirection: 'row-reverse', padding: Spacing.base, gap: Spacing.sm },
  tabBtn: {
    flex: 1, paddingVertical: 10, alignItems: 'center', borderRadius: Radius.md,
    backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border,
  },
  tabBtnActive: { backgroundColor: Colors.primaryFaded, borderColor: Colors.primary },
  tabBtnText: { fontSize: 13, color: Colors.textSecondary, fontWeight: Fonts.medium as any },
  tabBtnTextActive: { color: Colors.primary, fontWeight: Fonts.semibold as any },
  searchRow: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.sm,
    marginHorizontal: Spacing.base, marginBottom: Spacing.sm,
    backgroundColor: Colors.card, borderRadius: Radius.md,
    paddingHorizontal: Spacing.md, height: 46,
    borderWidth: 1, borderColor: Colors.border,
  },
  searchInput: { flex: 1, color: Colors.text, fontSize: 14 },
  filterScroll: { marginBottom: Spacing.sm },
  filterRow: { flexDirection: 'row-reverse', paddingHorizontal: Spacing.base, gap: Spacing.sm, paddingVertical: 4 },
  filterChip: {
    paddingHorizontal: 12, paddingVertical: 6, borderRadius: Radius.full,
    backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border,
  },
  filterChipActive: { backgroundColor: Colors.primaryFaded, borderColor: Colors.primary },
  filterChipText: { fontSize: 12, color: Colors.textSecondary },
  filterChipTextActive: { color: Colors.primary, fontWeight: Fonts.semibold as any },
  listContent: { padding: Spacing.base, gap: Spacing.sm, paddingBottom: 40 },
  userCard: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: Colors.card, borderRadius: Radius.lg, padding: Spacing.base,
    borderWidth: 1, borderColor: Colors.border, ...Shadow.sm,
  },
  userInfo: { flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.md, flex: 1 },
  avatar: { width: 48, height: 48, borderRadius: 24, borderWidth: 2, borderColor: Colors.border },
  driverAvatarWrap: { position: 'relative' },
  onlineDot: {
    position: 'absolute', bottom: 0, right: 0,
    width: 12, height: 12, borderRadius: 6,
    backgroundColor: Colors.success, borderWidth: 2, borderColor: Colors.card,
  },
  userDetails: { flex: 1, alignItems: 'flex-end', gap: 3 },
  nameRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 4 },
  userName: { fontSize: 15, fontWeight: Fonts.semibold as any, color: Colors.text },
  userPhone: { fontSize: 13, color: Colors.textSecondary },
  vehicleText: { fontSize: 12, color: Colors.textSecondary },
  userMeta: { flexDirection: 'row-reverse', alignItems: 'center', gap: 5 },
  metaText: { fontSize: 11, color: Colors.textTertiary },
  metaSep: { color: Colors.textTertiary, fontSize: 11 },
  userCardActions: { alignItems: 'flex-end', gap: Spacing.sm, minWidth: 72 },
  statusDot: { width: 8, height: 8, borderRadius: 4 },
  actionBtn: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: 3,
    paddingHorizontal: 8, paddingVertical: 5, borderRadius: Radius.sm,
    backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border,
  },
  actionDanger: { borderColor: Colors.error + '40', backgroundColor: Colors.errorFaded },
  actionSuccess: { borderColor: Colors.success + '40', backgroundColor: Colors.successFaded },
  approvalBadge: { borderRadius: Radius.full, paddingHorizontal: 7, paddingVertical: 3 },
  approvalText: { fontSize: 10, fontWeight: Fonts.semibold as any },
  emptyState: { alignItems: 'center', paddingVertical: Spacing.xxl, gap: Spacing.md },
  emptyText: { fontSize: 14, color: Colors.textTertiary },
  // Driver Modal
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'flex-end' },
  driverModal: {
    backgroundColor: Colors.surface, borderTopLeftRadius: Radius.xxl,
    borderTopRightRadius: Radius.xxl, maxHeight: '90%',
    borderTopWidth: 1, borderTopColor: Colors.border, padding: Spacing.base,
  },
  modalHandle: {
    width: 40, height: 4, backgroundColor: Colors.border,
    borderRadius: 2, alignSelf: 'center', marginBottom: Spacing.base,
  },
  driverModalHeader: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between',
    marginBottom: Spacing.lg,
  },
  driverModalTitle: { fontSize: 18, fontWeight: Fonts.bold as any, color: Colors.text },
  driverProfile: { alignItems: 'center', gap: Spacing.sm, marginBottom: Spacing.lg },
  driverAvatarWrap2: { position: 'relative' },
  driverModalAvatar: {
    width: 80, height: 80, borderRadius: 40,
    borderWidth: 2.5, borderColor: Colors.primary,
  },
  approvalDot: {
    position: 'absolute', bottom: 2, right: 2,
    width: 16, height: 16, borderRadius: 8,
    borderWidth: 2, borderColor: Colors.surface,
  },
  driverModalName: { fontSize: 18, fontWeight: Fonts.bold as any, color: Colors.text },
  driverModalPhone: { fontSize: 14, color: Colors.textSecondary },
  approvalBadgeLg: { borderRadius: Radius.full, paddingHorizontal: 12, paddingVertical: 5, marginTop: 4 },
  approvalBadgeLgText: { fontSize: 13, fontWeight: Fonts.semibold as any },
  driverInfoGrid: {
    backgroundColor: Colors.card, borderRadius: Radius.lg,
    borderWidth: 1, borderColor: Colors.border, marginBottom: Spacing.lg, overflow: 'hidden',
  },
  infoRow: {
    flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.md, paddingVertical: 10,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  infoLabel: { fontSize: 13, color: Colors.textSecondary },
  infoVal: { fontSize: 13, fontWeight: Fonts.semibold as any, color: Colors.text },
  docsTitle: {
    fontSize: 15, fontWeight: Fonts.semibold as any, color: Colors.textSecondary,
    textAlign: 'right', marginBottom: Spacing.sm,
  },
  docsList: {
    backgroundColor: Colors.card, borderRadius: Radius.lg,
    borderWidth: 1, borderColor: Colors.border, overflow: 'hidden', marginBottom: Spacing.lg,
  },
  docRow: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.md, paddingVertical: 10,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  docRowLeft: { flexDirection: 'row-reverse', alignItems: 'center', gap: 8 },
  docIcon: { fontSize: 18 },
  docLabel: { fontSize: 14, color: Colors.text },
  docStatus: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: 4,
    paddingHorizontal: 8, paddingVertical: 4, borderRadius: Radius.full,
  },
  approvalActions: {
    flexDirection: 'row-reverse', gap: Spacing.sm, marginBottom: Spacing.md,
  },
  approveBtn: {
    flex: 1, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center',
    gap: 6, paddingVertical: 13, borderRadius: Radius.md, borderWidth: 1,
  },
  approveBtnText: { fontSize: 14, fontWeight: Fonts.semibold as any },
});
