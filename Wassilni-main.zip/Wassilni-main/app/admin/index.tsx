// Powered by OnSpace.AI
import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import { Image } from 'expo-image';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Spacing, Radius, Fonts, Shadow } from '@/constants/theme';
import { MOCK_DRIVERS, MOCK_RIDES } from '@/constants/mockData';

const ADMIN_STATS = [
  { label: 'رحلات اليوم', value: '142', change: '+12%', icon: 'directions-car', color: Colors.primary },
  { label: 'مستخدمون نشطون', value: '1,284', change: '+5%', icon: 'people', color: Colors.accent },
  { label: 'إيرادات اليوم', value: '3,850 ج', change: '+18%', icon: 'attach-money', color: Colors.gold },
  { label: 'شكاوى معلقة', value: '7', change: '-3', icon: 'report-problem', color: Colors.error },
];

const PENDING_DRIVERS = [
  {
    id: 'pd1',
    name: 'يوسف محمد',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop&crop=face',
    vehicle: 'سيارة — تويوتا 2023',
    submitDate: '2 يونيو 2025',
    docsCount: 3,
  },
  {
    id: 'pd2',
    name: 'إبراهيم سالم',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
    vehicle: 'توكتوك كهربائي',
    submitDate: '1 يونيو 2025',
    docsCount: 3,
  },
  {
    id: 'pd3',
    name: 'أحمد فاروق',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&h=150&fit=crop&crop=face',
    vehicle: 'موتوسيكل — هوندا',
    submitDate: '31 مايو 2025',
    docsCount: 2,
  },
];

const RECENT_COMPLAINTS = [
  { id: 'c1', user: 'منى سعيد', driver: 'محمود حسن', type: 'سلوك السائق', status: 'pending', date: '2 يونيو' },
  { id: 'c2', user: 'علي أحمد', driver: 'كريم عبدالله', type: 'مشكلة في السعر', status: 'reviewing', date: '1 يونيو' },
  { id: 'c3', user: 'هنا محمد', driver: 'سامي إبراهيم', type: 'مسار خاطئ', status: 'resolved', date: '31 مايو' },
];

const COMPLAINT_STATUS: Record<string, { label: string; color: string; bg: string }> = {
  pending: { label: 'معلقة', color: Colors.warning, bg: Colors.warningFaded },
  reviewing: { label: 'قيد المراجعة', color: Colors.accent, bg: Colors.accentFaded },
  resolved: { label: 'محلولة', color: Colors.success, bg: Colors.successFaded },
};

const MENU_ITEMS = [
  { id: 'users', label: 'إدارة المستخدمين', icon: 'people', color: Colors.accent, route: '/admin/users' },
  { id: 'complaints', label: 'إدارة الشكاوى', icon: 'report-problem', color: Colors.error, route: '/admin/complaints' },
  { id: 'pricing', label: 'إدارة التسعير', icon: 'price-change', color: Colors.gold, route: '/admin/pricing' },
  { id: 'reports', label: 'التقارير', icon: 'bar-chart', color: Colors.primary, route: '/admin/users' },
];

export default function AdminDashboard() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [activeSection, setActiveSection] = useState<'overview' | 'drivers' | 'complaints'>('overview');

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      <LinearGradient
        colors={['#0D2B1E', Colors.background]}
        style={styles.header}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
      >
        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
          <MaterialIcons name="arrow-forward" size={22} color={Colors.text} />
        </TouchableOpacity>
        <View style={styles.headerCenter}>
          <Text style={styles.headerTitle}>لوحة تحكم تك توكي</Text>
          <View style={styles.liveBadge}>
            <View style={styles.liveDot} />
            <Text style={styles.liveText}>مباشر</Text>
          </View>
        </View>
        <TouchableOpacity style={styles.settingsBtn}>
          <MaterialIcons name="settings" size={22} color={Colors.textSecondary} />
        </TouchableOpacity>
      </LinearGradient>

      {/* Section Tabs */}
      <View style={styles.tabsRow}>
        {[
          { key: 'overview', label: 'نظرة عامة' },
          { key: 'drivers', label: 'سائقون معلقون' },
          { key: 'complaints', label: 'الشكاوى' },
        ].map(tab => (
          <TouchableOpacity
            key={tab.key}
            style={[styles.tab, activeSection === tab.key && styles.tabActive]}
            onPress={() => setActiveSection(tab.key as any)}
          >
            <Text style={[styles.tabText, activeSection === tab.key && styles.tabTextActive]}>
              {tab.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {activeSection === 'overview' ? (
          <View style={styles.section}>
            {/* Stats Grid */}
            <View style={styles.statsGrid}>
              {ADMIN_STATS.map((stat, i) => (
                <View key={i} style={styles.statCard}>
                  <LinearGradient
                    colors={[stat.color + '20', Colors.card]}
                    style={styles.statGradient}
                  >
                    <View style={styles.statCardHeader}>
                      <View style={[styles.statChangeBadge, {
                        backgroundColor: stat.change.startsWith('+') ? Colors.successFaded : Colors.errorFaded
                      }]}>
                        <Text style={[styles.statChange, {
                          color: stat.change.startsWith('+') ? Colors.success : Colors.error
                        }]}>
                          {stat.change}
                        </Text>
                      </View>
                      <View style={[styles.statIconBg, { backgroundColor: stat.color + '20' }]}>
                        <MaterialIcons name={stat.icon as any} size={20} color={stat.color} />
                      </View>
                    </View>
                    <Text style={styles.statValue}>{stat.value}</Text>
                    <Text style={styles.statLabel}>{stat.label}</Text>
                  </LinearGradient>
                </View>
              ))}
            </View>

            {/* Quick Menu */}
            <Text style={styles.sectionTitle}>إدارة النظام</Text>
            <View style={styles.menuGrid}>
              {MENU_ITEMS.map(item => (
                <TouchableOpacity
                  key={item.id}
                  style={styles.menuCard}
                  onPress={() => router.push(item.route as any)}
                  activeOpacity={0.8}
                >
                  <View style={[styles.menuIconBg, { backgroundColor: item.color + '20' }]}>
                    <MaterialIcons name={item.icon as any} size={26} color={item.color} />
                  </View>
                  <Text style={styles.menuLabel}>{item.label}</Text>
                  <MaterialIcons name="chevron-left" size={16} color={Colors.textTertiary} />
                </TouchableOpacity>
              ))}
            </View>

            {/* Recent Activity */}
            <Text style={styles.sectionTitle}>آخر الرحلات</Text>
            <View style={styles.activityList}>
              {MOCK_RIDES.slice(0, 4).map(ride => (
                <View key={ride.id} style={styles.activityItem}>
                  <Text style={styles.activityPrice}>{ride.price} ج</Text>
                  <View style={styles.activityInfo}>
                    <Text style={styles.activityName} numberOfLines={1}>{ride.driverName}</Text>
                    <Text style={styles.activityRoute} numberOfLines={1}>
                      {ride.fromLocation.split('،')[0]} ← {ride.toLocation.split('،')[0]}
                    </Text>
                  </View>
                  <View style={[styles.activityStatus, {
                    backgroundColor: ride.status === 'completed' ? Colors.successFaded : Colors.errorFaded
                  }]}>
                    <Text style={{
                      fontSize: 11,
                      color: ride.status === 'completed' ? Colors.success : Colors.error,
                      fontWeight: Fonts.medium as any,
                    }}>
                      {ride.status === 'completed' ? 'مكتملة' : 'ملغية'}
                    </Text>
                  </View>
                </View>
              ))}
            </View>
          </View>
        ) : activeSection === 'drivers' ? (
          <View style={styles.section}>
            <View style={styles.pendingHeader}>
              <View style={styles.pendingBadge}>
                <Text style={styles.pendingBadgeText}>{PENDING_DRIVERS.length} طلب</Text>
              </View>
              <Text style={styles.sectionTitle}>سائقون بانتظار الموافقة</Text>
            </View>
            {PENDING_DRIVERS.map(driver => (
              <View key={driver.id} style={styles.driverReviewCard}>
                <View style={styles.driverReviewHeader}>
                  <Text style={styles.driverReviewDate}>تقدّم في {driver.submitDate}</Text>
                  <View style={styles.driverReviewInfo}>
                    <Image source={{ uri: driver.avatar }} style={styles.driverReviewAvatar} contentFit="cover" />
                    <View style={styles.driverReviewDetails}>
                      <Text style={styles.driverReviewName}>{driver.name}</Text>
                      <Text style={styles.driverReviewVehicle}>{driver.vehicle}</Text>
                      <View style={styles.docsRow}>
                        <MaterialIcons name="attach-file" size={13} color={Colors.textTertiary} />
                        <Text style={styles.docsText}>{driver.docsCount} مستندات مرفوعة</Text>
                      </View>
                    </View>
                  </View>
                </View>
                <View style={styles.driverReviewActions}>
                  <TouchableOpacity style={styles.rejectBtn}>
                    <MaterialIcons name="close" size={16} color={Colors.error} />
                    <Text style={styles.rejectBtnText}>رفض</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={styles.reviewDocsBtn}>
                    <MaterialIcons name="folder-open" size={16} color={Colors.accent} />
                    <Text style={styles.reviewDocsBtnText}>مراجعة المستندات</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={styles.approveBtn}>
                    <LinearGradient colors={[Colors.primary, Colors.primaryDark]} style={styles.approveBtnGradient}>
                      <MaterialIcons name="check" size={16} color={Colors.textInverse} />
                      <Text style={styles.approveBtnText}>موافقة</Text>
                    </LinearGradient>
                  </TouchableOpacity>
                </View>
              </View>
            ))}
          </View>
        ) : (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>الشكاوى الأخيرة</Text>
            {RECENT_COMPLAINTS.map(c => {
              const s = COMPLAINT_STATUS[c.status];
              return (
                <TouchableOpacity
                  key={c.id}
                  style={styles.complaintCard}
                  onPress={() => router.push('/admin/complaints')}
                  activeOpacity={0.85}
                >
                  <View style={styles.complaintCardLeft}>
                    <MaterialIcons name="chevron-left" size={20} color={Colors.textTertiary} />
                    <View style={[styles.complaintStatusBadge, { backgroundColor: s.bg }]}>
                      <Text style={[styles.complaintStatusText, { color: s.color }]}>{s.label}</Text>
                    </View>
                  </View>
                  <View style={styles.complaintCardRight}>
                    <View style={styles.complaintRow}>
                      <MaterialIcons name="report-problem" size={14} color={Colors.warning} />
                      <Text style={styles.complaintType}>{c.type}</Text>
                    </View>
                    <Text style={styles.complaintParties}>
                      {c.user} <Text style={{ color: Colors.textTertiary }}>ضد</Text> {c.driver}
                    </Text>
                    <Text style={styles.complaintDate}>{c.date}</Text>
                  </View>
                </TouchableOpacity>
              );
            })}
          </View>
        )}
        <View style={{ height: insets.bottom + 32 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
    paddingBottom: Spacing.lg,
  },
  backBtn: {
    width: 40, height: 40,
    justifyContent: 'center', alignItems: 'center',
    backgroundColor: Colors.card, borderRadius: 20,
    borderWidth: 1, borderColor: Colors.border,
  },
  settingsBtn: {
    width: 40, height: 40,
    justifyContent: 'center', alignItems: 'center',
  },
  headerCenter: { alignItems: 'center', gap: 4 },
  headerTitle: {
    fontSize: 17, fontWeight: Fonts.bold as any, color: Colors.text,
  },
  liveBadge: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: 5,
    backgroundColor: Colors.successFaded,
    paddingHorizontal: 10, paddingVertical: 3,
    borderRadius: Radius.full,
    borderWidth: 1, borderColor: Colors.success + '40',
  },
  liveDot: {
    width: 6, height: 6, borderRadius: 3, backgroundColor: Colors.success,
  },
  liveText: { fontSize: 11, color: Colors.success, fontWeight: Fonts.semibold as any },
  tabsRow: {
    flexDirection: 'row-reverse',
    borderBottomWidth: 1, borderBottomColor: Colors.border,
    paddingHorizontal: Spacing.base,
    gap: Spacing.base,
  },
  tab: {
    paddingVertical: 12, borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  tabActive: { borderBottomColor: Colors.primary },
  tabText: { fontSize: 14, color: Colors.textTertiary, fontWeight: Fonts.medium as any },
  tabTextActive: { color: Colors.primary, fontWeight: Fonts.semibold as any },
  section: { padding: Spacing.base, gap: Spacing.base },
  sectionTitle: {
    fontSize: 17, fontWeight: Fonts.bold as any, color: Colors.text,
    textAlign: 'right', marginTop: Spacing.sm,
  },
  statsGrid: {
    flexDirection: 'row-reverse', flexWrap: 'wrap', gap: Spacing.sm,
  },
  statCard: {
    width: '48%', borderRadius: Radius.lg, overflow: 'hidden',
    borderWidth: 1, borderColor: Colors.border,
  },
  statGradient: { padding: Spacing.base, gap: Spacing.xs },
  statCardHeader: {
    flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center',
    marginBottom: Spacing.sm,
  },
  statIconBg: {
    width: 40, height: 40, borderRadius: 12,
    justifyContent: 'center', alignItems: 'center',
  },
  statChangeBadge: {
    paddingHorizontal: 8, paddingVertical: 3, borderRadius: Radius.full,
  },
  statChange: { fontSize: 12, fontWeight: Fonts.semibold as any },
  statValue: {
    fontSize: 22, fontWeight: Fonts.extrabold as any, color: Colors.text, textAlign: 'right',
  },
  statLabel: { fontSize: 12, color: Colors.textSecondary, textAlign: 'right' },
  menuGrid: { gap: Spacing.sm },
  menuCard: {
    flexDirection: 'row-reverse', alignItems: 'center',
    backgroundColor: Colors.card, borderRadius: Radius.lg,
    padding: Spacing.base, gap: Spacing.md,
    borderWidth: 1, borderColor: Colors.border,
    ...Shadow.sm,
  },
  menuIconBg: {
    width: 48, height: 48, borderRadius: 14,
    justifyContent: 'center', alignItems: 'center',
  },
  menuLabel: {
    flex: 1, fontSize: 15, fontWeight: Fonts.semibold as any, color: Colors.text, textAlign: 'right',
  },
  activityList: { gap: Spacing.sm },
  activityItem: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.md,
    backgroundColor: Colors.card, borderRadius: Radius.md, padding: Spacing.md,
    borderWidth: 1, borderColor: Colors.border,
  },
  activityInfo: { flex: 1, alignItems: 'flex-end', gap: 3 },
  activityName: { fontSize: 14, fontWeight: Fonts.semibold as any, color: Colors.text },
  activityRoute: { fontSize: 12, color: Colors.textSecondary },
  activityPrice: { fontSize: 15, fontWeight: Fonts.bold as any, color: Colors.primary },
  activityStatus: {
    paddingHorizontal: 8, paddingVertical: 4, borderRadius: Radius.full,
  },
  pendingHeader: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.sm,
  },
  pendingBadge: {
    backgroundColor: Colors.warningFaded, borderRadius: Radius.full,
    paddingHorizontal: 10, paddingVertical: 4,
    borderWidth: 1, borderColor: Colors.warning + '40',
  },
  pendingBadgeText: { fontSize: 12, color: Colors.warning, fontWeight: Fonts.semibold as any },
  driverReviewCard: {
    backgroundColor: Colors.card, borderRadius: Radius.lg,
    padding: Spacing.base, borderWidth: 1, borderColor: Colors.border,
    gap: Spacing.md, ...Shadow.sm,
  },
  driverReviewHeader: { gap: Spacing.sm },
  driverReviewInfo: { flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.md },
  driverReviewAvatar: {
    width: 52, height: 52, borderRadius: 26,
    borderWidth: 2, borderColor: Colors.primary + '50',
  },
  driverReviewDetails: { flex: 1, alignItems: 'flex-end', gap: 3 },
  driverReviewName: { fontSize: 16, fontWeight: Fonts.bold as any, color: Colors.text },
  driverReviewVehicle: { fontSize: 13, color: Colors.textSecondary },
  driverReviewDate: { fontSize: 11, color: Colors.textTertiary, textAlign: 'left' },
  docsRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 4 },
  docsText: { fontSize: 12, color: Colors.textTertiary },
  driverReviewActions: { flexDirection: 'row-reverse', gap: Spacing.sm },
  rejectBtn: {
    flex: 1, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center',
    gap: 5, paddingVertical: 10, borderRadius: Radius.md,
    backgroundColor: Colors.errorFaded, borderWidth: 1, borderColor: Colors.error + '40',
  },
  rejectBtnText: { fontSize: 13, color: Colors.error, fontWeight: Fonts.medium as any },
  reviewDocsBtn: {
    flex: 1.5, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center',
    gap: 5, paddingVertical: 10, borderRadius: Radius.md,
    backgroundColor: Colors.accentFaded, borderWidth: 1, borderColor: Colors.accent + '40',
  },
  reviewDocsBtnText: { fontSize: 13, color: Colors.accent, fontWeight: Fonts.medium as any },
  approveBtn: { flex: 1, borderRadius: Radius.md, overflow: 'hidden', ...Shadow.glow },
  approveBtnGradient: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center',
    gap: 5, paddingVertical: 10,
  },
  approveBtnText: { fontSize: 13, color: Colors.textInverse, fontWeight: Fonts.bold as any },
  complaintCard: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: Colors.card, borderRadius: Radius.lg, padding: Spacing.base,
    borderWidth: 1, borderColor: Colors.border, ...Shadow.sm,
  },
  complaintCardRight: { flex: 1, alignItems: 'flex-end', gap: 4 },
  complaintCardLeft: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  complaintRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 5 },
  complaintType: { fontSize: 14, fontWeight: Fonts.semibold as any, color: Colors.text },
  complaintParties: { fontSize: 13, color: Colors.textSecondary },
  complaintDate: { fontSize: 11, color: Colors.textTertiary },
  complaintStatusBadge: {
    paddingHorizontal: 10, paddingVertical: 4, borderRadius: Radius.full,
  },
  complaintStatusText: { fontSize: 12, fontWeight: Fonts.semibold as any },
});
