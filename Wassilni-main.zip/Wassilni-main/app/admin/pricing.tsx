// Powered by OnSpace.AI
import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput,
  Switch, Alert, Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Spacing, Radius, Fonts, Shadow } from '@/constants/theme';
import {
  DEFAULT_PRICING_CONFIG,
  PricingConfig,
  VehicleType,
  ZoneType,
  CURRENCY_CONFIGS,
  CurrencyCode,
  calculateFare,
  formatBreakdown,
} from '@/services/pricingEngine';

const VEHICLE_META: Record<VehicleType, { label: string; icon: string; color: string }> = {
  car:      { label: 'سيارة',       icon: '🚗', color: Colors.car },
  tuk:      { label: 'توكتوك',      icon: '🛺', color: Colors.tuk },
  moto:     { label: 'موتوسيكل',   icon: '🏍️', color: Colors.moto },
  microbus: { label: 'ميكروباص',   icon: '🚐', color: Colors.microbus },
};

const ZONE_LABELS: Record<ZoneType, string> = {
  city:      'داخل المدينة',
  village:   'القرى والريف',
  intercity: 'بين المدن',
};

type Tab = 'vehicles' | 'zones' | 'peak' | 'simulate';

export default function PricingManagement() {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const [config, setConfig] = useState<PricingConfig>({ ...DEFAULT_PRICING_CONFIG });
  const [activeTab, setActiveTab] = useState<Tab>('vehicles');
  const [editingVehicle, setEditingVehicle] = useState<VehicleType | null>(null);

  // Simulation inputs
  const [simVehicle, setSimVehicle]     = useState<VehicleType>('car');
  const [simZone, setSimZone]           = useState<ZoneType>('city');
  const [simDistance, setSimDistance]   = useState('10');
  const [simDuration, setSimDuration]   = useState('20');
  const [simResult, setSimResult]       = useState<ReturnType<typeof calculateFare> | null>(null);

  const handleSave = () => {
    setEditingVehicle(null);
    if (Platform.OS !== 'web') Alert.alert('تم الحفظ', 'تم حفظ إعدادات التسعير بنجاح');
  };

  const updateVehicleField = useCallback(
    (vehicle: VehicleType, field: string, value: string) => {
      setConfig(prev => ({
        ...prev,
        vehicleRules: {
          ...prev.vehicleRules,
          [vehicle]: {
            ...prev.vehicleRules[vehicle],
            [field]: parseFloat(value) || 0,
          },
        },
      }));
    },
    []
  );

  const updateZoneMultiplier = (zone: ZoneType, value: string) => {
    setConfig(prev => ({
      ...prev,
      zoneMultipliers: prev.zoneMultipliers.map(z =>
        z.zone === zone ? { ...z, multiplier: parseFloat(value) || 1 } : z
      ),
    }));
  };

  const updatePeakMultiplier = (index: number, value: string) => {
    setConfig(prev => {
      const updated = [...prev.peakHours];
      updated[index] = { ...updated[index], multiplier: parseFloat(value) || 1 };
      return { ...prev, peakHours: updated };
    });
  };

  const runSimulation = () => {
    const result = calculateFare({
      vehicleType: simVehicle,
      distanceKm: parseFloat(simDistance) || 0,
      durationMinutes: parseFloat(simDuration) || 0,
      zone: simZone,
    }, config);
    setSimResult(result);
  };

  const currencies = Object.keys(CURRENCY_CONFIGS) as CurrencyCode[];

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
          <MaterialIcons name="arrow-forward" size={22} color={Colors.text} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>إدارة التسعير الديناميكي</Text>
        <TouchableOpacity style={styles.saveBtn} onPress={handleSave}>
          <Text style={styles.saveBtnText}>حفظ</Text>
        </TouchableOpacity>
      </View>

      {/* Currency + Surge top row */}
      <View style={styles.topControls}>
        {/* Currency selector */}
        <View style={styles.currencyRow}>
          <Text style={styles.controlLabel}>العملة</Text>
          <View style={styles.currencyBtns}>
            {currencies.map(c => (
              <TouchableOpacity
                key={c}
                style={[styles.currencyBtn, config.currency === c && styles.currencyBtnActive]}
                onPress={() => setConfig(prev => ({ ...prev, currency: c }))}
              >
                <Text style={[styles.currencyBtnText, config.currency === c && styles.currencyBtnTextActive]}>
                  {CURRENCY_CONFIGS[c].symbol}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Surge toggle */}
        <View style={[styles.surgeRow, config.surgeActive && styles.surgeRowActive]}>
          <Switch
            value={config.surgeActive}
            onValueChange={v => setConfig(prev => ({ ...prev, surgeActive: v }))}
            trackColor={{ false: Colors.border, true: Colors.error + '60' }}
            thumbColor={config.surgeActive ? Colors.error : Colors.textTertiary}
          />
          <View style={styles.surgeInfo}>
            <Text style={[styles.surgeLabel, config.surgeActive && { color: Colors.error }]}>
              ⚡ تسعير الذروة
            </Text>
            {config.surgeActive ? (
              <TextInput
                style={styles.surgeInput}
                value={config.surgeMultiplier.toString()}
                onChangeText={v => setConfig(prev => ({ ...prev, surgeMultiplier: parseFloat(v) || 1 }))}
                keyboardType="decimal-pad"
              />
            ) : (
              <Text style={styles.surgeOff}>غير مفعّل</Text>
            )}
          </View>
        </View>
      </View>

      {/* Tabs */}
      <View style={styles.tabsRow}>
        {([
          { key: 'vehicles', label: 'المركبات', icon: 'directions-car' },
          { key: 'zones',    label: 'المناطق',  icon: 'map' },
          { key: 'peak',     label: 'الذروة',   icon: 'schedule' },
          { key: 'simulate', label: 'محاكاة',   icon: 'calculate' },
        ] as const).map(t => (
          <TouchableOpacity
            key={t.key}
            style={[styles.tab, activeTab === t.key && styles.tabActive]}
            onPress={() => setActiveTab(t.key)}
          >
            <MaterialIcons
              name={t.icon as any}
              size={14}
              color={activeTab === t.key ? Colors.primary : Colors.textTertiary}
            />
            <Text style={[styles.tabText, activeTab === t.key && styles.tabTextActive]}>
              {t.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>

        {/* ── VEHICLES TAB ── */}
        {activeTab === 'vehicles' ? (
          <View style={styles.section}>
            {(Object.keys(VEHICLE_META) as VehicleType[]).map(vt => {
              const meta   = VEHICLE_META[vt];
              const rule   = config.vehicleRules[vt];
              const isEdit = editingVehicle === vt;

              return (
                <View key={vt} style={[styles.vehicleCard, isEdit && { borderColor: meta.color + '60' }]}>
                  <View style={styles.vehicleCardHeader}>
                    <TouchableOpacity
                      style={[styles.editToggleBtn, { borderColor: meta.color + '40', backgroundColor: meta.color + '12' }]}
                      onPress={() => setEditingVehicle(isEdit ? null : vt)}
                    >
                      <Text style={[styles.editToggleBtnText, { color: meta.color }]}>
                        {isEdit ? '✓ حفظ' : 'تعديل'}
                      </Text>
                    </TouchableOpacity>
                    <View style={styles.vehicleCardTitle}>
                      <Text style={styles.vehicleLabel}>{meta.label}</Text>
                      <Text style={styles.vehicleIcon}>{meta.icon}</Text>
                    </View>
                  </View>

                  <View style={styles.fieldsGrid}>
                    {([
                      { label: 'الأجرة الأساسية', field: 'baseFare' },
                      { label: 'سعر/كم', field: 'perKmRate' },
                      { label: 'سعر/دقيقة', field: 'perMinuteRate' },
                      { label: 'الحد الأدنى', field: 'minimumFare' },
                      { label: 'حد المسافة (كم)', field: 'longDistanceThresholdKm' },
                      { label: 'سعر/كم بعيد', field: 'longDistancePerKmRate' },
                    ] as const).map(({ label, field }) => (
                      <View key={field} style={styles.fieldItem}>
                        {isEdit ? (
                          <TextInput
                            style={[styles.fieldInput, { borderColor: meta.color + '60' }]}
                            value={String(rule[field as keyof typeof rule])}
                            onChangeText={v => updateVehicleField(vt, field, v)}
                            keyboardType="decimal-pad"
                            textAlign="center"
                          />
                        ) : (
                          <Text style={[styles.fieldValue, { color: meta.color }]}>
                            {rule[field as keyof typeof rule]}
                          </Text>
                        )}
                        <Text style={styles.fieldLabel}>{label}</Text>
                      </View>
                    ))}
                  </View>
                </View>
              );
            })}
          </View>
        ) : null}

        {/* ── ZONES TAB ── */}
        {activeTab === 'zones' ? (
          <View style={styles.section}>
            <View style={styles.infoBox}>
              <MaterialIcons name="info" size={15} color={Colors.accent} />
              <Text style={styles.infoBoxText}>
                معاملات المنطقة تُضرب في الإجمالي — 1.0 = سعر عادي، 1.3 = أغلى 30%
              </Text>
            </View>
            <View style={styles.zonesCard}>
              {config.zoneMultipliers.map((z, i) => (
                <View key={z.zone} style={[styles.zoneRow, i < config.zoneMultipliers.length - 1 && styles.zoneRowBorder]}>
                  <View style={styles.zoneRight}>
                    <TextInput
                      style={styles.multiplierInput}
                      value={z.multiplier.toString()}
                      onChangeText={v => updateZoneMultiplier(z.zone as ZoneType, v)}
                      keyboardType="decimal-pad"
                      textAlign="center"
                    />
                    <Text style={styles.xSign}>×</Text>
                  </View>
                  <Text style={styles.zoneName}>{z.label}</Text>
                </View>
              ))}
            </View>

            {/* Night surcharge */}
            <Text style={styles.sectionSubTitle}>رسوم السهرات (10م – 6ص)</Text>
            <View style={styles.nightRow}>
              <TextInput
                style={styles.multiplierInput}
                value={config.nightSurchargeMultiplier.toString()}
                onChangeText={v => setConfig(prev => ({ ...prev, nightSurchargeMultiplier: parseFloat(v) || 1 }))}
                keyboardType="decimal-pad"
                textAlign="center"
              />
              <Text style={styles.xSign}>×</Text>
              <Text style={styles.zoneName}>مضاعف الليل</Text>
            </View>
          </View>
        ) : null}

        {/* ── PEAK HOURS TAB ── */}
        {activeTab === 'peak' ? (
          <View style={styles.section}>
            <View style={styles.infoBox}>
              <MaterialIcons name="schedule" size={15} color={Colors.warning} />
              <Text style={styles.infoBoxText}>
                أوقات الذروة: يُطبَّق أعلى المعاملَين (الذروة أو الليل) — لا يتراكمان.
              </Text>
            </View>
            {config.peakHours.map((p, i) => (
              <View key={i} style={styles.peakCard}>
                <View style={styles.peakCardHeader}>
                  <View style={[styles.peakBadge, { backgroundColor: Colors.warningFaded }]}>
                    <Text style={[styles.peakBadgeText, { color: Colors.warning }]}>
                      {p.startHour}:00 – {p.endHour}:00
                    </Text>
                  </View>
                  <Text style={styles.peakLabel}>{p.label}</Text>
                </View>
                <View style={styles.peakMultiplierRow}>
                  <Text style={styles.xSign}>×</Text>
                  <TextInput
                    style={[styles.multiplierInput, { borderColor: Colors.warning + '60', color: Colors.warning }]}
                    value={p.multiplier.toString()}
                    onChangeText={v => updatePeakMultiplier(i, v)}
                    keyboardType="decimal-pad"
                    textAlign="center"
                  />
                  <Text style={styles.peakDays}>
                    {p.days.map(d => ['أح', 'إث', 'ثل', 'أر', 'خم', 'جم', 'سب'][d]).join('، ')}
                  </Text>
                </View>
              </View>
            ))}
          </View>
        ) : null}

        {/* ── SIMULATION TAB ── */}
        {activeTab === 'simulate' ? (
          <View style={styles.section}>
            <Text style={styles.simTitle}>محاكاة حساب السعر</Text>
            <Text style={styles.simDesc}>اختبر خوارزمية التسعير بمدخلات مخصصة</Text>

            <View style={styles.simRow}>
              <Text style={styles.simFieldLabel}>نوع المركبة</Text>
              <View style={styles.simOptions}>
                {(Object.keys(VEHICLE_META) as VehicleType[]).map(vt => (
                  <TouchableOpacity
                    key={vt}
                    style={[styles.simOption, simVehicle === vt && { borderColor: VEHICLE_META[vt].color, backgroundColor: VEHICLE_META[vt].color + '15' }]}
                    onPress={() => setSimVehicle(vt)}
                  >
                    <Text style={{ fontSize: 18 }}>{VEHICLE_META[vt].icon}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            <View style={styles.simRow}>
              <Text style={styles.simFieldLabel}>المنطقة</Text>
              <View style={styles.simOptions}>
                {(Object.keys(ZONE_LABELS) as ZoneType[]).map(z => (
                  <TouchableOpacity
                    key={z}
                    style={[styles.simZoneBtn, simZone === z && styles.simZoneBtnActive]}
                    onPress={() => setSimZone(z)}
                  >
                    <Text style={[styles.simZoneBtnText, simZone === z && styles.simZoneBtnTextActive]}>
                      {ZONE_LABELS[z]}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            <View style={styles.simInputsRow}>
              <View style={styles.simInputGroup}>
                <Text style={styles.simFieldLabel}>المسافة (كم)</Text>
                <TextInput
                  style={styles.simInput}
                  value={simDistance}
                  onChangeText={setSimDistance}
                  keyboardType="decimal-pad"
                  textAlign="center"
                />
              </View>
              <View style={styles.simInputGroup}>
                <Text style={styles.simFieldLabel}>المدة (دقائق)</Text>
                <TextInput
                  style={styles.simInput}
                  value={simDuration}
                  onChangeText={setSimDuration}
                  keyboardType="decimal-pad"
                  textAlign="center"
                />
              </View>
            </View>

            <TouchableOpacity style={styles.runSimBtn} onPress={runSimulation}>
              <LinearGradient colors={[Colors.primary, Colors.primaryDark]} style={styles.runSimBtnGradient}>
                <MaterialIcons name="play-arrow" size={20} color={Colors.textInverse} />
                <Text style={styles.runSimBtnText}>تشغيل المحاكاة</Text>
              </LinearGradient>
            </TouchableOpacity>

            {simResult ? (
              <View style={styles.resultCard}>
                <Text style={styles.resultPrice}>{simResult.formattedPrice}</Text>
                <Text style={styles.resultPriceLabel}>السعر النهائي</Text>
                <View style={styles.resultDivider} />
                {formatBreakdown(simResult).map((line, i) => (
                  <View key={i} style={styles.resultLine}>
                    <MaterialIcons name="check-circle" size={13} color={Colors.primary} />
                    <Text style={styles.resultLineText}>{line}</Text>
                  </View>
                ))}
                {simResult.appliedPeakLabel ? (
                  <View style={styles.resultPeakBadge}>
                    <MaterialIcons name="bolt" size={13} color={Colors.warning} />
                    <Text style={styles.resultPeakText}>ساعة ذروة: {simResult.appliedPeakLabel}</Text>
                  </View>
                ) : null}
              </View>
            ) : null}
          </View>
        ) : null}

        <View style={{ height: insets.bottom + 24 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.base, paddingVertical: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  backBtn: {
    width: 40, height: 40, justifyContent: 'center', alignItems: 'center',
    backgroundColor: Colors.card, borderRadius: 20, borderWidth: 1, borderColor: Colors.border,
  },
  headerTitle: { fontSize: 16, fontWeight: Fonts.bold as any, color: Colors.text },
  saveBtn: {
    paddingHorizontal: 16, paddingVertical: 8, backgroundColor: Colors.primaryFaded,
    borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.primary + '50',
  },
  saveBtnText: { color: Colors.primary, fontWeight: Fonts.semibold as any, fontSize: 14 },
  topControls: {
    paddingHorizontal: Spacing.base, paddingVertical: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.border, gap: Spacing.sm,
  },
  currencyRow: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between' },
  controlLabel: { fontSize: 13, color: Colors.textSecondary, fontWeight: Fonts.medium as any },
  currencyBtns: { flexDirection: 'row', gap: Spacing.sm },
  currencyBtn: {
    paddingHorizontal: 12, paddingVertical: 6, borderRadius: Radius.sm,
    backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border,
  },
  currencyBtnActive: { borderColor: Colors.primary, backgroundColor: Colors.primaryFaded },
  currencyBtnText: { fontSize: 12, color: Colors.textSecondary, fontWeight: Fonts.medium as any },
  currencyBtnTextActive: { color: Colors.primary, fontWeight: Fonts.semibold as any },
  surgeRow: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.md,
    backgroundColor: Colors.card, borderRadius: Radius.md, padding: Spacing.md,
    borderWidth: 1, borderColor: Colors.border,
  },
  surgeRowActive: { borderColor: Colors.error + '50', backgroundColor: Colors.errorFaded },
  surgeInfo: { flex: 1, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between' },
  surgeLabel: { fontSize: 14, fontWeight: Fonts.semibold as any, color: Colors.text },
  surgeOff: { fontSize: 12, color: Colors.textTertiary },
  surgeInput: {
    width: 64, height: 36, backgroundColor: Colors.surface, borderRadius: Radius.sm,
    borderWidth: 1, borderColor: Colors.error + '60', color: Colors.error,
    fontSize: 16, fontWeight: Fonts.bold as any,
  },
  tabsRow: {
    flexDirection: 'row-reverse', borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  tab: {
    flex: 1, flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
    paddingVertical: 10, gap: 3, borderBottomWidth: 2, borderBottomColor: 'transparent',
  },
  tabActive: { borderBottomColor: Colors.primary },
  tabText: { fontSize: 11, color: Colors.textTertiary, fontWeight: Fonts.medium as any },
  tabTextActive: { color: Colors.primary, fontWeight: Fonts.semibold as any },
  content: { padding: Spacing.base },
  section: { gap: Spacing.md },
  sectionSubTitle: {
    fontSize: 14, fontWeight: Fonts.semibold as any, color: Colors.textSecondary,
    textAlign: 'right', marginTop: Spacing.sm,
  },
  infoBox: {
    flexDirection: 'row-reverse', alignItems: 'flex-start', gap: Spacing.sm,
    backgroundColor: Colors.accentFaded, borderRadius: Radius.md, padding: Spacing.md,
    borderWidth: 1, borderColor: Colors.accent + '30',
  },
  infoBoxText: { flex: 1, fontSize: 12, color: Colors.accent, lineHeight: 18, textAlign: 'right' },
  vehicleCard: {
    backgroundColor: Colors.card, borderRadius: Radius.lg, padding: Spacing.base,
    borderWidth: 1, borderColor: Colors.border, gap: Spacing.md, ...Shadow.sm,
  },
  vehicleCardHeader: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between',
  },
  vehicleCardTitle: { flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.sm },
  vehicleIcon: { fontSize: 24 },
  vehicleLabel: { fontSize: 16, fontWeight: Fonts.semibold as any, color: Colors.text },
  editToggleBtn: {
    paddingHorizontal: 14, paddingVertical: 6, borderRadius: Radius.sm, borderWidth: 1,
  },
  editToggleBtnText: { fontSize: 13, fontWeight: Fonts.medium as any },
  fieldsGrid: { flexDirection: 'row-reverse', flexWrap: 'wrap', gap: Spacing.sm },
  fieldItem: { width: '31%', alignItems: 'center', gap: 4 },
  fieldValue: {
    fontSize: 16, fontWeight: Fonts.bold as any,
    backgroundColor: Colors.surface, borderRadius: Radius.sm, paddingVertical: 8,
    minWidth: '100%', textAlign: 'center',
  },
  fieldInput: {
    height: 40, backgroundColor: Colors.surface, borderRadius: Radius.sm,
    borderWidth: 1.5, color: Colors.primary, fontSize: 16, fontWeight: Fonts.bold as any,
    width: '100%',
  },
  fieldLabel: { fontSize: 10, color: Colors.textTertiary, textAlign: 'center' },
  zonesCard: {
    backgroundColor: Colors.card, borderRadius: Radius.lg,
    borderWidth: 1, borderColor: Colors.border, overflow: 'hidden',
  },
  zoneRow: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between',
    padding: Spacing.base,
  },
  zoneRowBorder: { borderBottomWidth: 1, borderBottomColor: Colors.border },
  zoneName: { fontSize: 14, color: Colors.text, fontWeight: Fonts.medium as any },
  zoneRight: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  multiplierInput: {
    width: 64, height: 40, backgroundColor: Colors.surface, borderRadius: Radius.sm,
    borderWidth: 1, borderColor: Colors.border, color: Colors.accent,
    fontSize: 16, fontWeight: Fonts.bold as any,
  },
  xSign: { fontSize: 16, color: Colors.textTertiary, fontWeight: Fonts.bold as any },
  nightRow: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.md,
    backgroundColor: Colors.card, borderRadius: Radius.md, padding: Spacing.md,
    borderWidth: 1, borderColor: Colors.border,
  },
  peakCard: {
    backgroundColor: Colors.card, borderRadius: Radius.lg, padding: Spacing.base,
    borderWidth: 1, borderColor: Colors.warning + '30', gap: Spacing.sm,
  },
  peakCardHeader: { flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.sm },
  peakLabel: { fontSize: 15, fontWeight: Fonts.semibold as any, color: Colors.text },
  peakBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: Radius.full },
  peakBadgeText: { fontSize: 12, fontWeight: Fonts.medium as any },
  peakMultiplierRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.md },
  peakDays: { flex: 1, fontSize: 13, color: Colors.textSecondary, textAlign: 'left' },
  simTitle: { fontSize: 20, fontWeight: Fonts.bold as any, color: Colors.text, textAlign: 'right' },
  simDesc: { fontSize: 13, color: Colors.textSecondary, textAlign: 'right' },
  simRow: { gap: Spacing.sm },
  simFieldLabel: { fontSize: 13, color: Colors.textSecondary, textAlign: 'right', fontWeight: Fonts.medium as any },
  simOptions: { flexDirection: 'row-reverse', flexWrap: 'wrap', gap: Spacing.sm },
  simOption: {
    width: 52, height: 52, justifyContent: 'center', alignItems: 'center',
    borderRadius: Radius.md, borderWidth: 1.5, borderColor: Colors.border, backgroundColor: Colors.card,
  },
  simZoneBtn: {
    paddingHorizontal: 14, paddingVertical: 8, borderRadius: Radius.md,
    backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border,
  },
  simZoneBtnActive: { backgroundColor: Colors.primaryFaded, borderColor: Colors.primary },
  simZoneBtnText: { fontSize: 12, color: Colors.textSecondary, fontWeight: Fonts.medium as any },
  simZoneBtnTextActive: { color: Colors.primary, fontWeight: Fonts.semibold as any },
  simInputsRow: { flexDirection: 'row-reverse', gap: Spacing.md },
  simInputGroup: { flex: 1, gap: 6 },
  simInput: {
    height: 50, backgroundColor: Colors.card, borderRadius: Radius.md,
    borderWidth: 1, borderColor: Colors.border, color: Colors.text, fontSize: 16,
  },
  runSimBtn: { borderRadius: Radius.md, overflow: 'hidden', ...Shadow.glow },
  runSimBtnGradient: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center',
    gap: 8, paddingVertical: 14,
  },
  runSimBtnText: { color: Colors.textInverse, fontSize: 15, fontWeight: Fonts.bold as any },
  resultCard: {
    backgroundColor: Colors.card, borderRadius: Radius.xl, padding: Spacing.base,
    borderWidth: 1.5, borderColor: Colors.primary + '40', gap: Spacing.sm, alignItems: 'flex-end',
    ...Shadow.glow,
  },
  resultPrice: { fontSize: 36, fontWeight: Fonts.extrabold as any, color: Colors.primary, textAlign: 'right' },
  resultPriceLabel: { fontSize: 13, color: Colors.textTertiary, textAlign: 'right' },
  resultDivider: { width: '100%', height: 1, backgroundColor: Colors.border, marginVertical: 4 },
  resultLine: { flexDirection: 'row-reverse', alignItems: 'center', gap: 6 },
  resultLineText: { fontSize: 13, color: Colors.textSecondary },
  resultPeakBadge: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: 5,
    backgroundColor: Colors.warningFaded, borderRadius: Radius.full,
    paddingHorizontal: 10, paddingVertical: 5,
    borderWidth: 1, borderColor: Colors.warning + '30',
  },
  resultPeakText: { fontSize: 12, color: Colors.warning, fontWeight: Fonts.medium as any },
});
