// Powered by OnSpace.AI
import React, { useState } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, Modal, ScrollView,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Spacing, Radius, Fonts, Shadow } from '@/constants/theme';

type ComplaintStatus = 'pending' | 'reviewing' | 'resolved' | 'dismissed';

interface Complaint {
  id: string;
  passengerName: string;
  driverName: string;
  type: string;
  description: string;
  status: ComplaintStatus;
  date: string;
  severity: 'low' | 'medium' | 'high';
}

const COMPLAINTS: Complaint[] = [
  { id: 'c1', passengerName: 'منى سعيد', driverName: 'محمود حسن', type: 'سلوك السائق', description: 'السائق كان غير محترم أثناء الرحلة وتحدث بأسلوب غير لائق', status: 'pending', date: '2 يونيو 2025', severity: 'high' },
  { id: 'c2', passengerName: 'علي أحمد', driverName: 'كريم عبدالله', type: 'مشكلة في السعر', description: 'السعر الفعلي كان أعلى من التقدير المبدئي بنسبة كبيرة', status: 'reviewing', date: '1 يونيو 2025', severity: 'medium' },
  { id: 'c3', passengerName: 'هنا محمد', driverName: 'سامي إبراهيم', type: 'مسار خاطئ', description: 'السائق سلك مسارًا أطول عمدًا لزيادة المبلغ', status: 'resolved', date: '31 مايو 2025', severity: 'medium' },
  { id: 'c4', passengerName: 'ياسمين حسين', driverName: 'عمر خالد', type: 'مخاوف أمنية', description: 'الراكبة شعرت بعدم الأمان خلال الرحلة الليلية', status: 'pending', date: '30 مايو 2025', severity: 'high' },
  { id: 'c5', passengerName: 'خالد ماهر', driverName: 'طارق أحمد', type: 'حالة المركبة', description: 'المركبة كانت في حالة سيئة وغير آمنة للسفر', status: 'dismissed', date: '28 مايو 2025', severity: 'low' },
];

const STATUS_CONFIG: Record<ComplaintStatus, { label: string; color: string; bg: string }> = {
  pending: { label: 'معلقة', color: Colors.warning, bg: Colors.warningFaded },
  reviewing: { label: 'قيد المراجعة', color: Colors.accent, bg: Colors.accentFaded },
  resolved: { label: 'محلولة', color: Colors.success, bg: Colors.successFaded },
  dismissed: { label: 'مرفوضة', color: Colors.textTertiary, bg: Colors.card },
};

const SEVERITY_CONFIG = {
  low: { label: 'منخفض', color: Colors.textSecondary },
  medium: { label: 'متوسط', color: Colors.warning },
  high: { label: 'عالي', color: Colors.error },
};

export default function ComplaintsManagement() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [filter, setFilter] = useState<'all' | ComplaintStatus>('all');
  const [selected, setSelected] = useState<Complaint | null>(null);
  const [complaints, setComplaints] = useState(COMPLAINTS);

  const filtered = filter === 'all' ? complaints : complaints.filter(c => c.status === filter);

  const updateStatus = (id: string, status: ComplaintStatus) => {
    setComplaints(prev => prev.map(c => c.id === id ? { ...c, status } : c));
    setSelected(null);
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
          <MaterialIcons name="arrow-forward" size={22} color={Colors.text} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>إدارة الشكاوى</Text>
        <View style={styles.countBadge}>
          <Text style={styles.countText}>{complaints.filter(c => c.status === 'pending').length}</Text>
        </View>
      </View>

      {/* Filter Row */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filtersScroll}
        contentContainerStyle={styles.filtersContent}>
        {(['all', 'pending', 'reviewing', 'resolved', 'dismissed'] as const).map(f => (
          <TouchableOpacity
            key={f}
            style={[styles.filterChip, filter === f && styles.filterChipActive]}
            onPress={() => setFilter(f)}
          >
            <Text style={[styles.filterChipText, filter === f && styles.filterChipTextActive]}>
              {f === 'all' ? 'الكل' : STATUS_CONFIG[f].label}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <FlatList
        data={filtered}
        keyExtractor={i => i.id}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => {
          const s = STATUS_CONFIG[item.status];
          const sev = SEVERITY_CONFIG[item.severity];
          return (
            <TouchableOpacity
              style={styles.card}
              onPress={() => setSelected(item)}
              activeOpacity={0.85}
            >
              <View style={styles.cardHeader}>
                <View style={styles.cardHeaderLeft}>
                  <View style={[styles.severityDot, { backgroundColor: sev.color }]} />
                  <View style={[styles.statusBadge, { backgroundColor: s.bg }]}>
                    <Text style={[styles.statusText, { color: s.color }]}>{s.label}</Text>
                  </View>
                </View>
                <View style={styles.cardHeaderRight}>
                  <Text style={styles.cardType}>{item.type}</Text>
                  <Text style={styles.cardDate}>{item.date}</Text>
                </View>
              </View>
              <View style={styles.cardParties}>
                <View style={styles.partyItem}>
                  <MaterialIcons name="drive-eta" size={13} color={Colors.textTertiary} />
                  <Text style={styles.partyText}>{item.driverName}</Text>
                </View>
                <MaterialIcons name="arrow-forward" size={14} color={Colors.textTertiary} />
                <View style={styles.partyItem}>
                  <MaterialIcons name="person" size={13} color={Colors.textTertiary} />
                  <Text style={styles.partyText}>{item.passengerName}</Text>
                </View>
              </View>
              <Text style={styles.cardDesc} numberOfLines={2}>{item.description}</Text>
            </TouchableOpacity>
          );
        }}
      />

      {/* Detail Modal */}
      <Modal visible={!!selected} transparent animationType="slide" onRequestClose={() => setSelected(null)}>
        <View style={styles.modalOverlay}>
          <View style={[styles.modalSheet, { paddingBottom: insets.bottom + 20 }]}>
            <View style={styles.modalHandle} />
            {selected ? (
              <ScrollView showsVerticalScrollIndicator={false}>
                <Text style={styles.modalTitle}>{selected.type}</Text>
                <View style={styles.modalParties}>
                  <Text style={styles.modalParty}>السائق: {selected.driverName}</Text>
                  <Text style={[styles.modalParty, { color: Colors.textTertiary }]}>|</Text>
                  <Text style={styles.modalParty}>الراكب: {selected.passengerName}</Text>
                </View>
                <Text style={styles.modalDesc}>{selected.description}</Text>
                <Text style={styles.modalDate}>{selected.date}</Text>

                <View style={styles.modalSeverity}>
                  <Text style={[styles.severityLabel, { color: SEVERITY_CONFIG[selected.severity].color }]}>
                    خطورة {SEVERITY_CONFIG[selected.severity].label}
                  </Text>
                </View>

                <View style={styles.modalActions}>
                  <TouchableOpacity style={styles.modalActionDismiss} onPress={() => updateStatus(selected.id, 'dismissed')}>
                    <Text style={styles.modalActionDismissText}>رفض الشكوى</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={styles.modalActionReview} onPress={() => updateStatus(selected.id, 'reviewing')}>
                    <Text style={styles.modalActionReviewText}>بدء المراجعة</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={styles.modalActionResolve} onPress={() => updateStatus(selected.id, 'resolved')}>
                    <LinearGradient colors={[Colors.primary, Colors.primaryDark]} style={styles.modalActionGradient}>
                      <Text style={styles.modalActionResolveText}>حل الشكوى</Text>
                    </LinearGradient>
                  </TouchableOpacity>
                </View>
              </ScrollView>
            ) : null}
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.base, paddingVertical: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  backBtn: {
    width: 40, height: 40, justifyContent: 'center', alignItems: 'center',
    backgroundColor: Colors.card, borderRadius: 20, borderWidth: 1, borderColor: Colors.border,
  },
  headerTitle: { fontSize: 18, fontWeight: Fonts.bold as any, color: Colors.text },
  countBadge: {
    backgroundColor: Colors.error, borderRadius: 12, minWidth: 28, height: 28,
    justifyContent: 'center', alignItems: 'center', paddingHorizontal: 6,
  },
  countText: { color: Colors.text, fontSize: 13, fontWeight: Fonts.bold as any },
  filtersScroll: { maxHeight: 52, borderBottomWidth: 1, borderBottomColor: Colors.border },
  filtersContent: { paddingHorizontal: Spacing.base, alignItems: 'center', gap: Spacing.sm, height: 52 },
  filterChip: {
    paddingHorizontal: 14, paddingVertical: 7, borderRadius: Radius.full,
    borderWidth: 1, borderColor: Colors.border, backgroundColor: Colors.card,
  },
  filterChipActive: { backgroundColor: Colors.primaryFaded, borderColor: Colors.primary },
  filterChipText: { fontSize: 13, color: Colors.textSecondary, fontWeight: Fonts.medium as any },
  filterChipTextActive: { color: Colors.primary, fontWeight: Fonts.semibold as any },
  listContent: { padding: Spacing.base, gap: Spacing.md, paddingBottom: 40 },
  card: {
    backgroundColor: Colors.card, borderRadius: Radius.lg, padding: Spacing.base,
    borderWidth: 1, borderColor: Colors.border, gap: Spacing.sm, ...Shadow.sm,
  },
  cardHeader: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between' },
  cardHeaderRight: { alignItems: 'flex-end', gap: 3 },
  cardHeaderLeft: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  cardType: { fontSize: 15, fontWeight: Fonts.semibold as any, color: Colors.text },
  cardDate: { fontSize: 11, color: Colors.textTertiary },
  severityDot: { width: 10, height: 10, borderRadius: 5 },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 3, borderRadius: Radius.full },
  statusText: { fontSize: 12, fontWeight: Fonts.semibold as any },
  cardParties: { flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.sm },
  partyItem: { flexDirection: 'row-reverse', alignItems: 'center', gap: 4 },
  partyText: { fontSize: 13, color: Colors.textSecondary },
  cardDesc: { fontSize: 13, color: Colors.textTertiary, lineHeight: 20, textAlign: 'right' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'flex-end' },
  modalSheet: {
    backgroundColor: Colors.surface, borderTopLeftRadius: Radius.xxl, borderTopRightRadius: Radius.xxl,
    padding: Spacing.base, borderTopWidth: 1, borderTopColor: Colors.border, maxHeight: '70%',
  },
  modalHandle: {
    width: 40, height: 4, backgroundColor: Colors.border, borderRadius: 2,
    alignSelf: 'center', marginBottom: Spacing.base,
  },
  modalTitle: { fontSize: 20, fontWeight: Fonts.bold as any, color: Colors.text, textAlign: 'right', marginBottom: Spacing.sm },
  modalParties: { flexDirection: 'row-reverse', gap: Spacing.sm, marginBottom: Spacing.md },
  modalParty: { fontSize: 13, color: Colors.textSecondary },
  modalDesc: { fontSize: 14, color: Colors.text, lineHeight: 24, textAlign: 'right', marginBottom: Spacing.sm },
  modalDate: { fontSize: 12, color: Colors.textTertiary, textAlign: 'right', marginBottom: Spacing.md },
  modalSeverity: { marginBottom: Spacing.lg },
  severityLabel: { fontSize: 13, fontWeight: Fonts.semibold as any, textAlign: 'right' },
  modalActions: { gap: Spacing.sm },
  modalActionDismiss: {
    paddingVertical: 12, alignItems: 'center', borderRadius: Radius.md,
    backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border,
  },
  modalActionDismissText: { fontSize: 14, color: Colors.textSecondary, fontWeight: Fonts.medium as any },
  modalActionReview: {
    paddingVertical: 12, alignItems: 'center', borderRadius: Radius.md,
    backgroundColor: Colors.accentFaded, borderWidth: 1, borderColor: Colors.accent + '40',
  },
  modalActionReviewText: { fontSize: 14, color: Colors.accent, fontWeight: Fonts.semibold as any },
  modalActionResolve: { borderRadius: Radius.md, overflow: 'hidden', ...Shadow.glow },
  modalActionGradient: { paddingVertical: 14, alignItems: 'center' },
  modalActionResolveText: { fontSize: 15, color: Colors.textInverse, fontWeight: Fonts.bold as any },
});
