// Powered by OnSpace.AI
import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Animated,
  Keyboard,
} from 'react-native';
import { Image } from 'expo-image';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Spacing, Radius, Fonts, Shadow } from '@/constants/theme';
import { useRide } from '@/hooks/useRide';
import { isSupabaseConfigured, supabase } from '@/lib/supabase';

interface Message {
  id: string;
  text: string;
  sender: 'passenger' | 'driver';
  timestamp: Date;
  status: 'sent' | 'delivered' | 'read';
}

const QUICK_REPLIES = [
  { id: 'q1', text: 'في الطريق إليك 🚗', icon: 'directions-car' },
  { id: 'q2', text: 'وصلت 📍', icon: 'location-on' },
  { id: 'q3', text: 'أنتظرك أمام المدخل ⏳', icon: 'schedule' },
  { id: 'q4', text: 'متى ستصل تقريباً؟', icon: 'help-outline' },
  { id: 'q5', text: 'شكراً جزيلاً 🙏', icon: 'favorite' },
  { id: 'q6', text: 'هل تعرف الطريق؟', icon: 'map' },
];

const MOCK_INITIAL_MESSAGES: Message[] = [
  {
    id: 'm0',
    text: 'مرحباً، أنا في طريقي إليك الآن 🚗',
    sender: 'driver',
    timestamp: new Date(Date.now() - 4 * 60000),
    status: 'read',
  },
  {
    id: 'm1',
    text: 'حسناً، أنا أنتظرك عند المدخل الرئيسي',
    sender: 'passenger',
    timestamp: new Date(Date.now() - 3 * 60000),
    status: 'read',
  },
  {
    id: 'm2',
    text: 'هناك ازدحام بسيط، سأصل خلال 3 دقائق إن شاء الله',
    sender: 'driver',
    timestamp: new Date(Date.now() - 2 * 60000),
    status: 'read',
  },
];

function formatTime(date: Date): string {
  const h = date.getHours().toString().padStart(2, '0');
  const m = date.getMinutes().toString().padStart(2, '0');
  return `${h}:${m}`;
}

export default function ChatScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { activeRide } = useRide();
  const [messages, setMessages] = useState<Message[]>(MOCK_INITIAL_MESSAGES);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [showQuickReplies, setShowQuickReplies] = useState(true);
  const flatListRef = useRef<FlatList>(null);
  const inputRef = useRef<TextInput>(null);
  const typingAnim = useRef(new Animated.Value(0)).current;
  const dotAnims = [
    useRef(new Animated.Value(0)).current,
    useRef(new Animated.Value(0)).current,
    useRef(new Animated.Value(0)).current,
  ];

  const driver = activeRide?.driver;

  // Supabase Realtime subscription
  useEffect(() => {
    if (!isSupabaseConfigured || !activeRide?.id) return;

    const channel = supabase
      .channel(`ride_chat_${activeRide.id}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'ride_messages',
          filter: `ride_id=eq.${activeRide.id}`,
        },
        (payload: any) => {
          const newMsg = payload.new;
          if (newMsg.sender_role !== 'passenger') {
            setMessages(prev => [
              ...prev,
              {
                id: newMsg.id,
                text: newMsg.message,
                sender: 'driver',
                timestamp: new Date(newMsg.created_at),
                status: 'delivered',
              },
            ]);
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [activeRide?.id]);

  // Simulate driver typing indicator (demo)
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsTyping(true);
      startTypingAnimation();
      setTimeout(() => {
        setIsTyping(false);
        typingAnim.setValue(0);
        // Simulate driver reply
        const driverReplies = [
          'وصلت بعد دقيقتين 🚗',
          'حسناً، في طريقي إليك',
          'تفضّل، أنا في الخارج',
        ];
        const randomReply = driverReplies[Math.floor(Math.random() * driverReplies.length)];
        setMessages(prev => [
          ...prev,
          {
            id: `auto_${Date.now()}`,
            text: randomReply,
            sender: 'driver',
            timestamp: new Date(),
            status: 'delivered',
          },
        ]);
      }, 2500);
    }, 5000);
    return () => clearTimeout(timer);
  }, []);

  const startTypingAnimation = () => {
    dotAnims.forEach((anim, i) => {
      Animated.loop(
        Animated.sequence([
          Animated.delay(i * 200),
          Animated.timing(anim, { toValue: -6, duration: 300, useNativeDriver: true }),
          Animated.timing(anim, { toValue: 0, duration: 300, useNativeDriver: true }),
        ])
      ).start();
    });
  };

  const sendMessage = useCallback(async (text: string) => {
    const trimmed = text.trim();
    if (!trimmed) return;

    const newMsg: Message = {
      id: `msg_${Date.now()}`,
      text: trimmed,
      sender: 'passenger',
      timestamp: new Date(),
      status: 'sent',
    };

    setMessages(prev => [...prev, newMsg]);
    setInputText('');
    setShowQuickReplies(false);

    // Supabase insert
    if (isSupabaseConfigured && activeRide?.id) {
      await supabase.from('ride_messages').insert({
        ride_id: activeRide.id,
        message: trimmed,
        sender_role: 'passenger',
      } as any);
    }

    // Simulate delivery confirmation
    setTimeout(() => {
      setMessages(prev =>
        prev.map(m => m.id === newMsg.id ? { ...m, status: 'delivered' } : m)
      );
    }, 800);
    setTimeout(() => {
      setMessages(prev =>
        prev.map(m => m.id === newMsg.id ? { ...m, status: 'read' } : m)
      );
    }, 1800);
  }, [activeRide?.id]);

  const handleQuickReply = (text: string) => {
    sendMessage(text);
  };

  useEffect(() => {
    if (messages.length > 0) {
      setTimeout(() => {
        flatListRef.current?.scrollToEnd({ animated: true });
      }, 100);
    }
  }, [messages]);

  const renderMessage = ({ item }: { item: Message }) => {
    const isPassenger = item.sender === 'passenger';

    return (
      <View style={[styles.msgRow, isPassenger ? styles.msgRowRight : styles.msgRowLeft]}>
        {!isPassenger ? (
          <Image
            source={{ uri: driver?.avatar ?? 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=80&h=80&fit=crop&crop=face' }}
            style={styles.msgAvatar}
            contentFit="cover"
          />
        ) : null}

        <View style={styles.msgBubbleWrap}>
          <View style={[
            styles.msgBubble,
            isPassenger ? styles.msgBubblePassenger : styles.msgBubbleDriver,
          ]}>
            {isPassenger ? (
              <LinearGradient
                colors={[Colors.primary, Colors.primaryDark]}
                style={styles.msgBubbleGrad}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
              >
                <Text style={styles.msgTextPassenger}>{item.text}</Text>
              </LinearGradient>
            ) : (
              <Text style={styles.msgTextDriver}>{item.text}</Text>
            )}
          </View>
          <View style={[styles.msgMeta, isPassenger && styles.msgMetaRight]}>
            <Text style={styles.msgTime}>{formatTime(item.timestamp)}</Text>
            {isPassenger ? (
              <MaterialIcons
                name={
                  item.status === 'read' ? 'done-all'
                  : item.status === 'delivered' ? 'done-all'
                  : 'done'
                }
                size={12}
                color={item.status === 'read' ? Colors.primary : Colors.textTertiary}
              />
            ) : null}
          </View>
        </View>
      </View>
    );
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* ── Header ── */}
      <LinearGradient
        colors={['#0D2B1E', Colors.background]}
        style={styles.header}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
      >
        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
          <MaterialIcons name="arrow-forward" size={22} color={Colors.text} />
        </TouchableOpacity>

        <View style={styles.driverHeader}>
          <View style={styles.driverHeaderInfo}>
            <Text style={styles.driverHeaderName}>{driver?.name ?? 'السائق'}</Text>
            <View style={styles.onlineRow}>
              <View style={styles.onlineDot} />
              <Text style={styles.onlineText}>متصل · في الطريق إليك</Text>
            </View>
          </View>
          <View style={styles.driverAvatarWrap}>
            <Image
              source={{ uri: driver?.avatar ?? 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=80&h=80&fit=crop&crop=face' }}
              style={styles.driverHeaderAvatar}
              contentFit="cover"
            />
            <View style={styles.onlineDotLarge} />
          </View>
        </View>

        <TouchableOpacity style={styles.callBtn}>
          <MaterialIcons name="phone" size={20} color={Colors.primary} />
        </TouchableOpacity>
      </LinearGradient>

      {/* ── Trip info bar ── */}
      <View style={styles.tripBar}>
        <View style={styles.tripBarItem}>
          <MaterialIcons name="directions-car" size={13} color={Colors.textTertiary} />
          <Text style={styles.tripBarText}>{driver?.vehiclePlate ?? '—'}</Text>
        </View>
        <View style={styles.tripBarDivider} />
        <View style={styles.tripBarItem}>
          <MaterialIcons name="access-time" size={13} color={Colors.textTertiary} />
          <Text style={styles.tripBarText}>{driver?.eta ?? '—'} دقيقة</Text>
        </View>
        <View style={styles.tripBarDivider} />
        <View style={styles.tripBarItem}>
          <MaterialIcons name="star" size={13} color={Colors.gold} />
          <Text style={styles.tripBarText}>{driver?.rating ?? '—'}</Text>
        </View>
        <View style={styles.tripBarDivider} />
        <TouchableOpacity
          style={styles.tripBarAction}
          onPress={() => router.back()}
        >
          <MaterialIcons name="map" size={13} color={Colors.primary} />
          <Text style={[styles.tripBarText, { color: Colors.primary }]}>الخريطة</Text>
        </TouchableOpacity>
      </View>

      {/* ── Messages ── */}
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
      >
        <FlatList
          ref={flatListRef}
          data={messages}
          renderItem={renderMessage}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.messagesList}
          showsVerticalScrollIndicator={false}
          onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: false })}
          ListHeaderComponent={
            <View style={styles.chatHeader}>
              <View style={styles.chatHeaderLine} />
              <Text style={styles.chatHeaderText}>محادثة الرحلة</Text>
              <View style={styles.chatHeaderLine} />
            </View>
          }
          ListFooterComponent={
            isTyping ? (
              <View style={styles.typingRow}>
                <Image
                  source={{ uri: driver?.avatar ?? 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=80&h=80&fit=crop&crop=face' }}
                  style={styles.msgAvatar}
                  contentFit="cover"
                />
                <View style={styles.typingBubble}>
                  {dotAnims.map((anim, i) => (
                    <Animated.View
                      key={i}
                      style={[styles.typingDot, { transform: [{ translateY: anim }] }]}
                    />
                  ))}
                </View>
              </View>
            ) : null
          }
        />

        {/* ── Quick Replies ── */}
        {showQuickReplies ? (
          <View style={styles.quickRepliesSection}>
            <Text style={styles.quickRepliesTitle}>ردود سريعة</Text>
            <View style={styles.quickRepliesGrid}>
              {QUICK_REPLIES.map(qr => (
                <TouchableOpacity
                  key={qr.id}
                  style={styles.quickReplyChip}
                  onPress={() => handleQuickReply(qr.text)}
                  activeOpacity={0.75}
                >
                  <MaterialIcons name={qr.icon as any} size={12} color={Colors.primary} />
                  <Text style={styles.quickReplyText}>{qr.text}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        ) : null}

        {/* ── Input Bar ── */}
        <View style={[styles.inputBar, { paddingBottom: insets.bottom + 8 }]}>
          <TouchableOpacity
            style={styles.sendBtn}
            onPress={() => sendMessage(inputText)}
            disabled={!inputText.trim()}
            activeOpacity={0.85}
          >
            <LinearGradient
              colors={inputText.trim() ? [Colors.primary, Colors.primaryDark] : [Colors.border, Colors.border]}
              style={styles.sendBtnGrad}
            >
              <MaterialIcons
                name="send"
                size={18}
                color={inputText.trim() ? Colors.textInverse : Colors.textTertiary}
                style={{ transform: [{ scaleX: -1 }] }}
              />
            </LinearGradient>
          </TouchableOpacity>

          <TextInput
            ref={inputRef}
            style={styles.textInput}
            value={inputText}
            onChangeText={setInputText}
            placeholder="اكتب رسالة..."
            placeholderTextColor={Colors.textTertiary}
            textAlign="right"
            multiline
            maxLength={300}
            onFocus={() => setShowQuickReplies(false)}
            returnKeyType="send"
            onSubmitEditing={() => sendMessage(inputText)}
          />

          <TouchableOpacity
            style={styles.quickRepliesToggle}
            onPress={() => {
              setShowQuickReplies(prev => !prev);
              Keyboard.dismiss();
            }}
          >
            <MaterialIcons
              name={showQuickReplies ? 'keyboard' : 'chat-bubble-outline'}
              size={20}
              color={Colors.textSecondary}
            />
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },

  // Header
  header: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  backBtn: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: Colors.card, justifyContent: 'center', alignItems: 'center',
    borderWidth: 1, borderColor: Colors.border,
  },
  driverHeader: { flex: 1, flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.sm, paddingHorizontal: Spacing.sm },
  driverHeaderInfo: { flex: 1, alignItems: 'flex-end', gap: 3 },
  driverHeaderName: { fontSize: 16, fontWeight: Fonts.bold as any, color: Colors.text },
  onlineRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 5 },
  onlineDot: { width: 7, height: 7, borderRadius: 3.5, backgroundColor: Colors.success },
  onlineText: { fontSize: 12, color: Colors.success },
  driverAvatarWrap: { position: 'relative' },
  driverHeaderAvatar: { width: 44, height: 44, borderRadius: 22, borderWidth: 2, borderColor: Colors.primary },
  onlineDotLarge: {
    position: 'absolute', bottom: 0, left: 0,
    width: 13, height: 13, borderRadius: 6.5,
    backgroundColor: Colors.success, borderWidth: 2, borderColor: Colors.background,
  },
  callBtn: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: Colors.primaryFaded, justifyContent: 'center', alignItems: 'center',
    borderWidth: 1, borderColor: Colors.primary + '40',
  },

  // Trip bar
  tripBar: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-around',
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.base,
    backgroundColor: Colors.card,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  tripBarItem: { flexDirection: 'row-reverse', alignItems: 'center', gap: 4 },
  tripBarText: { fontSize: 12, color: Colors.textSecondary },
  tripBarDivider: { width: 1, height: 16, backgroundColor: Colors.border },
  tripBarAction: { flexDirection: 'row-reverse', alignItems: 'center', gap: 4 },

  // Messages
  messagesList: {
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.base,
    gap: Spacing.sm,
  },

  chatHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: Spacing.md,
    paddingHorizontal: Spacing.base,
  },
  chatHeaderLine: { flex: 1, height: 1, backgroundColor: Colors.border },
  chatHeaderText: { fontSize: 11, color: Colors.textTertiary },

  msgRow: {
    flexDirection: 'row-reverse',
    alignItems: 'flex-end',
    gap: Spacing.sm,
    marginBottom: Spacing.sm,
  },
  msgRowRight: { justifyContent: 'flex-start' },
  msgRowLeft: { justifyContent: 'flex-end' },
  msgAvatar: { width: 32, height: 32, borderRadius: 16, borderWidth: 1, borderColor: Colors.border },

  msgBubbleWrap: { maxWidth: '75%', gap: 3 },
  msgBubble: { borderRadius: Radius.lg, overflow: 'hidden' },
  msgBubblePassenger: { borderBottomRightRadius: 4 },
  msgBubbleDriver: {
    borderBottomLeftRadius: 4,
    backgroundColor: Colors.card,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  msgBubbleGrad: { paddingHorizontal: 14, paddingVertical: 10 },
  msgTextPassenger: { fontSize: 14, color: Colors.textInverse, lineHeight: 20 },
  msgTextDriver: { fontSize: 14, color: Colors.text, lineHeight: 20, paddingHorizontal: 14, paddingVertical: 10 },

  msgMeta: { flexDirection: 'row-reverse', alignItems: 'center', gap: 3 },
  msgMetaRight: { justifyContent: 'flex-start' },
  msgTime: { fontSize: 10, color: Colors.textTertiary },

  // Typing indicator
  typingRow: { flexDirection: 'row-reverse', alignItems: 'flex-end', gap: Spacing.sm, marginBottom: Spacing.sm },
  typingBubble: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: Colors.card,
    borderRadius: Radius.lg,
    borderBottomLeftRadius: 4,
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  typingDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: Colors.textTertiary },

  // Quick replies
  quickRepliesSection: {
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.sm,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    backgroundColor: Colors.surface,
    gap: Spacing.sm,
  },
  quickRepliesTitle: { fontSize: 11, color: Colors.textTertiary, textAlign: 'right' },
  quickRepliesGrid: { flexDirection: 'row-reverse', flexWrap: 'wrap', gap: 6 },
  quickReplyChip: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: Radius.full,
    backgroundColor: Colors.primaryFaded,
    borderWidth: 1,
    borderColor: Colors.primary + '30',
  },
  quickReplyText: { fontSize: 12, color: Colors.primary, fontWeight: Fonts.medium as any },

  // Input bar
  inputBar: {
    flexDirection: 'row-reverse',
    alignItems: 'flex-end',
    paddingHorizontal: Spacing.base,
    paddingTop: Spacing.sm,
    gap: Spacing.sm,
    backgroundColor: Colors.surface,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  quickRepliesToggle: {
    width: 40, height: 44, justifyContent: 'center', alignItems: 'center',
  },
  textInput: {
    flex: 1,
    backgroundColor: Colors.card,
    borderRadius: Radius.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    paddingHorizontal: 14,
    paddingTop: Platform.OS === 'ios' ? 12 : 10,
    paddingBottom: Platform.OS === 'ios' ? 12 : 10,
    color: Colors.text,
    fontSize: 14,
    maxHeight: 100,
    minHeight: 44,
  },
  sendBtn: { width: 44, height: 44, borderRadius: 22, overflow: 'hidden', ...Shadow.sm },
  sendBtnGrad: { flex: 1, justifyContent: 'center', alignItems: 'center' },
});
