// Powered by OnSpace.AI
import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Animated,
  ActivityIndicator,
  Platform,
} from 'react-native';
import { Image } from 'expo-image';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Spacing, Radius, Fonts, Shadow } from '@/constants/theme';
import { useRide } from '@/hooks/useRide';
import { MOCK_DRIVERS } from '@/constants/mockData';
import { isSupabaseConfigured, supabase } from '@/lib/supabase';

const TAGS_BY_RATING: Record<number, { text: string; icon: string }[]> = {
  5: [
    { text: 'سائق محترف', icon: '⭐' },
    { text: 'قيادة ممتازة', icon: '🏆' },
    { text: 'مؤدب ولطيف', icon: '😊' },
    { text: 'مركبة نظيفة', icon: '✨' },
    { text: 'وصل في الوقت', icon: '⏰' },
    { text: 'سعر مناسب', icon: '💰' },
    { text: 'مسار سريع', icon: '🚀' },
  ],
  4: [
    { text: 'رحلة جيدة', icon: '👍' },
    { text: 'قيادة آمنة', icon: '🛡️' },
    { text: 'كان منضبطاً', icon: '✅' },
    { text: 'مركبة مقبولة', icon: '🚗' },
    { text: 'وصل بوقت معقول', icon: '⏱️' },
  ],
  3: [
    { text: 'رحلة عادية', icon: '😐' },
    { text: 'بعض التأخير', icon: '⏳' },
    { text: 'القيادة مقبولة', icon: '🔄' },
  ],
  2: [
    { text: 'تأخر في الوصول', icon: '⌛' },
    { text: 'قيادة متهورة', icon: '⚠️' },
    { text: 'المركبة قذرة', icon: '🚫' },
    { text: 'سلوك غير لائق', icon: '😤' },
  ],
  1: [
    { text: 'سلوك مسيء', icon: '❌' },
    { text: 'رفض الذهاب للعنوان', icon: '🚷' },
    { text: 'مسار خاطئ', icon: '⛔' },
    { text: 'قيادة خطيرة', icon: '🚨' },
    { text: 'المركبة تالفة', icon: '💥' },
  ],
};

const RATING_INFO: Record<number, { label: string; color: string; emoji: string }> = {
  1: { label: 'سيئ جداً',   color: '#EF4444', emoji: '😞' },
  2: { label: 'سيئ',        color: '#F97316', emoji: '😕' },
  3: { label: 'مقبول',      color: Colors.warning, emoji: '😐' },
  4: { label: 'جيد',        color: Colors.primary, emoji: '😊' },
  5: { label: 'ممتاز',      color: Colors.success, emoji: '🤩' },
};

export default function RatingScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { activeRide } = useRide();
  const [rating, setRating] = useState(0);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [comment, setComment] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [tipAmount, setTipAmount] = useState<number | null>(null);

  const driver = activeRide?.driver ?? MOCK_DRIVERS[0];
  const rideInfo = activeRide;

  // Star animations
  const starAnims = useRef([0, 1, 2, 3, 4].map(() => new Animated.Value(1))).current;
  const successScale = useRef(new Animated.Value(0.5)).current;
  const successOpacity = useRef(new Animated.Value(0)).current;
  const contentOpacity = useRef(new Animated.Value(0)).current;
  const contentSlide = useRef(new Animated.Value(30)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(contentOpacity, { toValue: 1, duration: 500, useNativeDriver: true }),
      Animated.timing(contentSlide, { toValue: 0, duration: 450, useNativeDriver: true }),
    ]).start();
  }, []);

  const animateStar = (index: number) => {
    Animated.sequence([
      Animated.timing(starAnims[index], { toValue: 1.4, duration: 130, useNativeDriver: true }),
      Animated.spring(starAnims[index], { toValue: 1, tension: 200, friction: 5, useNativeDriver: true }),
    ]).start();
  };

  const handleStarPress = (star: number) => {
    const prev = rating;
    setRating(star);
    setSelectedTags([]);

    // Ripple through stars
    for (let i = 0; i <= star - 1; i++) {
      setTimeout(() => animateStar(i), i * 60);
    }
    // Un-animate stars above new rating if lower
    if (star < prev) {
      for (let i = star; i < prev; i++) {
        setTimeout(() => {
          Animated.timing(starAnims[i], { toValue: 0.85, duration: 100, useNativeDriver: true }).start(() => {
            Animated.timing(starAnims[i], { toValue: 1, duration: 100, useNativeDriver: true }).start();
          });
        }, i * 40);
      }
    }
  };

  const toggleTag = (tag: string) => {
    setSelectedTags(prev =>
      prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag]
    );
  };

  const handleSubmit = async () => {
    if (!rating) return;
    setIsSubmitting(true);

    if (isSupabaseConfigured && rideInfo?.id) {
      await supabase.from('ride_ratings').insert({
        ride_id: rideInfo.id,
        driver_id: driver?.id ?? null,
        rating,
        tags: selectedTags,
        comment: comment.trim() || null,
        tip_amount: tipAmount,
      } as any);
    } else {
      await new Promise(r => setTimeout(r, 1200));
    }

    setIsSubmitting(false);
    setSubmitted(true);

    // Entrance animation for success
    Animated.parallel([
      Animated.spring(successScale, { toValue: 1, tension: 60, friction: 7, useNativeDriver: true }),
      Animated.timing(successOpacity, { toValue: 1, duration: 400, useNativeDriver: true }),
    ]).start();

    setTimeout(() => router.replace('/(tabs)'), 3000);
  };

  if (submitted) {
    const info = RATING_INFO[rating];
    return (
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <LinearGradient
          colors={[info.color + '18', Colors.background, Colors.background]}
          style={styles.successBg}
        >
          <Animated.View
            style={[
              styles.successContent,
              { opacity: successOpacity, transform: [{ scale: successScale }] },
            ]}
          >
            {/* Glow ring */}
            <View style={[styles.successGlowRing, { borderColor: info.color + '30' }]}>
              <View style={[styles.successInnerRing, { borderColor: info.color + '60' }]}>
                <LinearGradient
                  colors={[info.color + '30', info.color + '10']}
                  style={styles.successIconBg}
                >
                  <Text style={styles.successEmoji}>{info.emoji}</Text>
                </LinearGradient>
              </View>
            </View>

            <Text style={[styles.successTitle, { color: info.color }]}>
              {rating === 5 ? 'تقييم رائع!' : rating >= 3 ? 'شكراً على تقييمك' : 'نأسف لتجربتك'}
            </Text>
            <Text style={styles.successSub}>
              {rating === 5
                ? 'تقييمك يشجّع السائق على تقديم أفضل خدمة'
                : rating >= 3
                ? 'سنعمل على تحسين تجربتك في الرحلات القادمة'
                : 'سنراجع هذه الرحلة وسنتخذ الإجراء المناسب'}
            </Text>

            {/* Stars display */}
            <View style={styles.successStarsRow}>
              {[1, 2, 3, 4, 5].map(s => (
                <MaterialIcons
                  key={s}
                  name="star"
                  size={32}
                  color={s <= rating ? Colors.gold : Colors.border}
                />
              ))}
            </View>

            {selectedTags.length > 0 ? (
              <View style={styles.successTagsRow}>
                {selectedTags.slice(0, 3).map(tag => (
                  <View key={tag} style={[styles.successTag, { backgroundColor: info.color + '15', borderColor: info.color + '30' }]}>
                    <Text style={[styles.successTagText, { color: info.color }]}>{tag}</Text>
                  </View>
                ))}
              </View>
            ) : null}

            <Text style={styles.successRedirect}>جارٍ العودة للرئيسية...</Text>
          </Animated.View>
        </LinearGradient>
      </View>
    );
  }

  const currentTags = rating > 0 ? (TAGS_BY_RATING[rating] ?? []) : [];
  const ratingInfo = rating > 0 ? RATING_INFO[rating] : null;

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.replace('/(tabs)')}>
          <Text style={styles.skipText}>تخطّي</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>تقييم الرحلة</Text>
        <View style={{ width: 50 }} />
      </View>

      <Animated.ScrollView
        showsVerticalScrollIndicator={false}
        style={{ opacity: contentOpacity, transform: [{ translateY: contentSlide }] }}
        contentContainerStyle={styles.scrollContent}
      >
        {/* Driver card */}
        <LinearGradient
          colors={['#0D2B1E', Colors.card]}
          style={styles.driverCard}
          start={{ x: 0, y: 0 }}
          end={{ x: 0, y: 1 }}
        >
          <View style={styles.driverAvatarWrap}>
            <Image
              source={{ uri: driver?.avatar }}
              style={styles.driverAvatar}
              contentFit="cover"
            />
            <View style={[styles.driverVerifiedBadge]}>
              <MaterialIcons name="verified" size={14} color={Colors.primary} />
            </View>
          </View>

          <View style={styles.driverInfo}>
            <Text style={styles.driverName}>{driver?.name}</Text>
            <View style={styles.driverRatingRow}>
              <MaterialIcons name="star" size={13} color={Colors.gold} />
              <Text style={styles.driverCurrentRating}>{driver?.rating} تقييم عام</Text>
            </View>
          </View>

          {/* Trip summary chips */}
          <View style={styles.tripSummaryRow}>
            <View style={styles.tripSummaryChip}>
              <MaterialIcons name="straighten" size={12} color={Colors.textTertiary} />
              <Text style={styles.tripSummaryText}>{rideInfo?.distance?.toFixed(1) ?? '22.4'} كم</Text>
            </View>
            <View style={styles.tripSummaryDot} />
            <View style={styles.tripSummaryChip}>
              <MaterialIcons name="access-time" size={12} color={Colors.textTertiary} />
              <Text style={styles.tripSummaryText}>35 دقيقة</Text>
            </View>
            <View style={styles.tripSummaryDot} />
            <View style={styles.tripSummaryChip}>
              <MaterialIcons name="attach-money" size={12} color={Colors.primary} />
              <Text style={[styles.tripSummaryText, { color: Colors.primary }]}>
                {rideInfo?.price ?? 85} ج.م
              </Text>
            </View>
          </View>
        </LinearGradient>

        {/* Stars section */}
        <View style={styles.starsSection}>
          <Text style={styles.starsQuestion}>كيف كانت رحلتك؟</Text>

          <View style={styles.starsRow}>
            {[1, 2, 3, 4, 5].map(star => {
              const isFilled = star <= rating;
              const info = RATING_INFO[star];
              return (
                <Animated.View key={star} style={{ transform: [{ scale: starAnims[star - 1] }] }}>
                  <TouchableOpacity
                    onPress={() => handleStarPress(star)}
                    activeOpacity={0.8}
                    style={styles.starBtn}
                  >
                    <MaterialIcons
                      name={isFilled ? 'star' : 'star-border'}
                      size={48}
                      color={isFilled ? Colors.gold : Colors.border}
                    />
                  </TouchableOpacity>
                </Animated.View>
              );
            })}
          </View>

          {ratingInfo ? (
            <View style={[styles.ratingLabelBadge, { backgroundColor: ratingInfo.color + '18', borderColor: ratingInfo.color + '40' }]}>
              <Text style={styles.ratingLabelEmoji}>{ratingInfo.emoji}</Text>
              <Text style={[styles.ratingLabelText, { color: ratingInfo.color }]}>
                {ratingInfo.label}
              </Text>
            </View>
          ) : (
            <Text style={styles.starsHint}>اضغط على النجوم للتقييم</Text>
          )}
        </View>

        {/* Tags */}
        {currentTags.length > 0 ? (
          <View style={styles.tagsSection}>
            <Text style={styles.tagsSectionTitle}>
              {rating >= 4 ? 'ما الذي أعجبك؟' : rating === 3 ? 'ما الذي يمكن تحسينه؟' : 'ما المشكلة التي واجهتها؟'}
              <Text style={styles.tagsSectionOptional}> (اختياري)</Text>
            </Text>
            <View style={styles.tagsWrap}>
              {currentTags.map(tag => {
                const isSelected = selectedTags.includes(tag.text);
                const info = RATING_INFO[rating];
                return (
                  <TouchableOpacity
                    key={tag.text}
                    style={[
                      styles.tagChip,
                      isSelected && {
                        backgroundColor: info.color + '18',
                        borderColor: info.color + '60',
                      },
                    ]}
                    onPress={() => toggleTag(tag.text)}
                    activeOpacity={0.8}
                  >
                    <Text style={styles.tagEmoji}>{tag.icon}</Text>
                    <Text style={[
                      styles.tagText,
                      isSelected && { color: info?.color, fontWeight: Fonts.semibold as any },
                    ]}>
                      {tag.text}
                    </Text>
                    {isSelected ? (
                      <MaterialIcons name="check" size={12} color={info?.color} />
                    ) : null}
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>
        ) : null}

        {/* Tip Section (only for 4-5 stars) */}
        {rating >= 4 ? (
          <View style={styles.tipSection}>
            <Text style={styles.tipTitle}>إضافة إكرامية 🎁</Text>
            <Text style={styles.tipSubtitle}>تشجيع السائق على الاستمرار في التميز</Text>
            <View style={styles.tipOptions}>
              {[5, 10, 15, 20].map(amount => (
                <TouchableOpacity
                  key={amount}
                  style={[styles.tipOption, tipAmount === amount && styles.tipOptionSelected]}
                  onPress={() => setTipAmount(tipAmount === amount ? null : amount)}
                >
                  {tipAmount === amount ? (
                    <LinearGradient colors={[Colors.gold, Colors.primary]} style={styles.tipOptionGrad}>
                      <Text style={styles.tipOptionTextSelected}>{amount} ج</Text>
                    </LinearGradient>
                  ) : (
                    <Text style={styles.tipOptionText}>{amount} ج</Text>
                  )}
                </TouchableOpacity>
              ))}
              <TouchableOpacity
                style={[styles.tipOption, tipAmount === null && styles.tipOptionNone]}
                onPress={() => setTipAmount(null)}
              >
                <Text style={styles.tipOptionText}>لا</Text>
              </TouchableOpacity>
            </View>
          </View>
        ) : null}

        {/* Comment */}
        <View style={styles.commentSection}>
          <Text style={styles.commentLabel}>
            تعليق إضافي
            <Text style={styles.tagsSectionOptional}> (اختياري)</Text>
          </Text>
          <TextInput
            style={styles.commentInput}
            value={comment}
            onChangeText={setComment}
            placeholder="شاركنا رأيك في هذه الرحلة..."
            placeholderTextColor={Colors.textTertiary}
            multiline
            numberOfLines={3}
            textAlign="right"
            textAlignVertical="top"
            maxLength={300}
          />
          {comment.length > 0 ? (
            <Text style={styles.commentCount}>{comment.length}/300</Text>
          ) : null}
        </View>

        {/* Submit */}
        <TouchableOpacity
          style={[styles.submitBtn, (!rating || isSubmitting) && styles.submitBtnDisabled]}
          onPress={handleSubmit}
          disabled={!rating || isSubmitting}
          activeOpacity={0.88}
        >
          <LinearGradient
            colors={rating ? [Colors.primary, Colors.primaryDark] : [Colors.border, Colors.border]}
            style={styles.submitBtnGrad}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
          >
            {isSubmitting ? (
              <ActivityIndicator color={Colors.textInverse} />
            ) : (
              <>
                <MaterialIcons
                  name="send"
                  size={18}
                  color={rating ? Colors.textInverse : Colors.textTertiary}
                />
                <Text style={[styles.submitBtnText, !rating && { color: Colors.textTertiary }]}>
                  إرسال التقييم{tipAmount ? ` مع إكرامية ${tipAmount} ج` : ''}
                </Text>
              </>
            )}
          </LinearGradient>
        </TouchableOpacity>

        {/* Report link */}
        <TouchableOpacity
          style={styles.reportLink}
          onPress={() => router.push('/complaints/new')}
        >
          <MaterialIcons name="report-problem" size={14} color={Colors.error} />
          <Text style={styles.reportLinkText}>الإبلاغ عن مشكلة في الرحلة</Text>
        </TouchableOpacity>
      </Animated.ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },

  // Header
  header: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  headerTitle: { fontSize: 18, fontWeight: Fonts.bold as any, color: Colors.text },
  skipText: { color: Colors.textSecondary, fontSize: 14, fontWeight: Fonts.medium as any },

  scrollContent: { padding: Spacing.base, gap: Spacing.xl, paddingBottom: 60 },

  // Driver card
  driverCard: {
    borderRadius: Radius.xl,
    padding: Spacing.xl,
    alignItems: 'center',
    gap: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.primary + '30',
    ...Shadow.sm,
  },
  driverAvatarWrap: { position: 'relative' },
  driverAvatar: {
    width: 80, height: 80, borderRadius: 40,
    borderWidth: 3, borderColor: Colors.primary,
    ...Shadow.glow,
  },
  driverVerifiedBadge: {
    position: 'absolute', bottom: 0, right: 0,
    width: 24, height: 24, borderRadius: 12,
    backgroundColor: Colors.background, justifyContent: 'center', alignItems: 'center',
    borderWidth: 1, borderColor: Colors.primary + '40',
  },
  driverInfo: { alignItems: 'center', gap: 4 },
  driverName: { fontSize: 20, fontWeight: Fonts.bold as any, color: Colors.text },
  driverRatingRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 4 },
  driverCurrentRating: { fontSize: 13, color: Colors.textSecondary },
  tripSummaryRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: Spacing.sm,
    backgroundColor: Colors.background,
    borderRadius: Radius.full,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  tripSummaryChip: { flexDirection: 'row-reverse', alignItems: 'center', gap: 3 },
  tripSummaryText: { fontSize: 12, color: Colors.textSecondary },
  tripSummaryDot: { width: 4, height: 4, borderRadius: 2, backgroundColor: Colors.border },

  // Stars
  starsSection: { alignItems: 'center', gap: Spacing.md },
  starsQuestion: { fontSize: 18, fontWeight: Fonts.semibold as any, color: Colors.text },
  starsRow: { flexDirection: 'row-reverse', gap: 8 },
  starBtn: { padding: 4 },
  ratingLabelBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 16,
    paddingVertical: 7,
    borderRadius: Radius.full,
    borderWidth: 1,
  },
  ratingLabelEmoji: { fontSize: 18 },
  ratingLabelText: { fontSize: 16, fontWeight: Fonts.semibold as any },
  starsHint: { fontSize: 14, color: Colors.textTertiary },

  // Tags
  tagsSection: { gap: Spacing.md },
  tagsSectionTitle: { fontSize: 15, fontWeight: Fonts.semibold as any, color: Colors.text, textAlign: 'right' },
  tagsSectionOptional: { fontSize: 13, color: Colors.textTertiary, fontWeight: Fonts.regular as any },
  tagsWrap: { flexDirection: 'row-reverse', flexWrap: 'wrap', gap: 8 },
  tagChip: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 13,
    paddingVertical: 8,
    borderRadius: Radius.full,
    borderWidth: 1,
    borderColor: Colors.border,
    backgroundColor: Colors.card,
  },
  tagEmoji: { fontSize: 14 },
  tagText: { fontSize: 13, color: Colors.textSecondary },

  // Tip
  tipSection: {
    backgroundColor: Colors.card,
    borderRadius: Radius.xl,
    padding: Spacing.base,
    gap: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.goldFaded ? Colors.gold + '30' : Colors.border,
  },
  tipTitle: { fontSize: 16, fontWeight: Fonts.semibold as any, color: Colors.text, textAlign: 'right' },
  tipSubtitle: { fontSize: 13, color: Colors.textSecondary, textAlign: 'right', marginTop: -8 },
  tipOptions: { flexDirection: 'row-reverse', gap: Spacing.sm },
  tipOption: {
    flex: 1, height: 44, borderRadius: Radius.md,
    justifyContent: 'center', alignItems: 'center',
    borderWidth: 1, borderColor: Colors.border, backgroundColor: Colors.surface,
    overflow: 'hidden',
  },
  tipOptionSelected: { borderColor: Colors.gold + '60' },
  tipOptionNone: { borderColor: Colors.border },
  tipOptionGrad: { flex: 1, width: '100%', justifyContent: 'center', alignItems: 'center' },
  tipOptionText: { fontSize: 13, color: Colors.textSecondary, fontWeight: Fonts.medium as any },
  tipOptionTextSelected: { fontSize: 13, color: Colors.background, fontWeight: Fonts.bold as any },

  // Comment
  commentSection: { gap: Spacing.sm },
  commentLabel: { fontSize: 15, fontWeight: Fonts.semibold as any, color: Colors.text, textAlign: 'right' },
  commentInput: {
    backgroundColor: Colors.card,
    borderRadius: Radius.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: Spacing.md,
    color: Colors.text,
    fontSize: 14,
    minHeight: 90,
    lineHeight: 22,
  },
  commentCount: { fontSize: 11, color: Colors.textTertiary, textAlign: 'left' },

  // Submit
  submitBtn: { borderRadius: Radius.lg, overflow: 'hidden', ...Shadow.glow },
  submitBtnDisabled: { opacity: 0.5 },
  submitBtnGrad: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center',
    gap: 8, paddingVertical: 16,
  },
  submitBtnText: { color: Colors.textInverse, fontSize: 16, fontWeight: Fonts.bold as any },

  // Report
  reportLink: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center',
    gap: 6, paddingVertical: 8,
  },
  reportLinkText: { color: Colors.error, fontSize: 13 },

  // Success
  successBg: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  successContent: { alignItems: 'center', padding: Spacing.xl, gap: Spacing.lg },
  successGlowRing: {
    width: 160, height: 160, borderRadius: 80,
    borderWidth: 2, justifyContent: 'center', alignItems: 'center',
  },
  successInnerRing: {
    width: 130, height: 130, borderRadius: 65,
    borderWidth: 2, justifyContent: 'center', alignItems: 'center',
  },
  successIconBg: {
    width: 100, height: 100, borderRadius: 50,
    justifyContent: 'center', alignItems: 'center',
  },
  successEmoji: { fontSize: 48 },
  successTitle: { fontSize: 28, fontWeight: Fonts.bold as any, textAlign: 'center' },
  successSub: { fontSize: 15, color: Colors.textSecondary, textAlign: 'center', lineHeight: 24 },
  successStarsRow: { flexDirection: 'row-reverse', gap: 6 },
  successTagsRow: { flexDirection: 'row-reverse', flexWrap: 'wrap', gap: 6, justifyContent: 'center' },
  successTag: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: Radius.full, borderWidth: 1 },
  successTagText: { fontSize: 12, fontWeight: Fonts.medium as any },
  successRedirect: { fontSize: 13, color: Colors.textTertiary, marginTop: Spacing.sm },
});
