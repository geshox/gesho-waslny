// Powered by OnSpace.AI
import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput,
  Modal, RefreshControl, Platform, Alert, FlatList,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Spacing, Radius, Fonts, Shadow } from '@/constants/theme';
import { useAuth } from '@/hooks/useAuth';
import { PAYMENT_METHODS } from '@/constants/mockData';
import {
  getTransactions,
  rechargeWallet,
  WalletTransaction,
  subscribeToWallet,
} from '@/services/walletService';
import { notifyPaymentSuccess } from '@/services/notificationService';
import { isSupabaseConfigured } from '@/lib/supabase';

const QUICK_AMOUNTS = [50, 100, 200, 500];

const TX_ICONS: Record<string, { icon: string; color: string }> = {
  recharge:     { icon: 'add-circle',           color: Colors.success },
  ride_payment: { icon: 'directions-car',        color: Colors.error },
  refund:       { icon: 'replay',                color: Colors.accent },
  transfer:     { icon: 'swap-horiz',            color: Colors.warning },
};

const TX_LABELS: Record<string, string> = {
  recharge:     'شحن رصيد',
  ride_payment: 'دفع رحلة',
  refund:       'استرداد',
  transfer:     'تحويل',
};

const PAYMENT_METHOD_NAMES: Record<string, string> = {
  instapay: 'InstaPay',
  vodafone: 'Vodafone Cash',
  wallet:   'المحفظة',
  cash:     'كاش',
  card:     'بطاقة',
};

export default function WalletScreen() {
  const insets = useSafeAreaInsets();
  const { user, updateBalance } = useAuth();
  const [balance, setBalance] = useState(user?.walletBalance ?? 0);
  const [transactions, setTransactions] = useState<WalletTransaction[]>([]);
  const [showRecharge, setShowRecharge] = useState(false);
  const [showAllTx, setShowAllTx] = useState(false);
  const [rechargeAmount, setRechargeAmount] = useState('');
  const [selectedPayment, setSelectedPayment] = useState('instapay');
  const [isLoading, setIsLoading] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [filter, setFilter] = useState<'all' | 'recharge' | 'ride_payment' | 'refund'>('all');

  const loadData = useCallback(async () => {
    if (!user?.id) return;
    const txs = await getTransactions(user.id);
    setTransactions(txs);
    setBalance(user.walletBalance ?? 0);
  }, [user?.id, user?.walletBalance]);

  useEffect(() => {
    loadData();

    // Real-time balance subscription
    if (!user?.id) return;
    const sub = subscribeToWallet(user.id, (newBal) => {
      setBalance(newBal);
      updateBalance(newBal - (user.walletBalance ?? 0));
    });
    return () => { sub.unsubscribe(); };
  }, [user?.id]);

  const onRefresh = async () => {
    setIsRefreshing(true);
    await loadData();
    setIsRefreshing(false);
  };

  const handleRecharge = async () => {
    const amount = parseFloat(rechargeAmount);
    if (!amount || amount <= 0 || amount > 10000) {
      if (Platform.OS !== 'web') Alert.alert('خطأ', 'أدخل مبلغاً بين 1 و 10,000 ج.م');
      return;
    }
    if (!user?.id) return;
    setIsLoading(true);

    const payMethodName =
      PAYMENT_METHODS.find(p => p.type === selectedPayment)?.label ?? selectedPayment;

    const { newBalance, error } = await rechargeWallet(user.id, amount, payMethodName);

    if (error) {
      setIsLoading(false);
      if (Platform.OS !== 'web') Alert.alert('فشل الشحن', error);
      return;
    }

    setBalance(isSupabaseConfigured ? newBalance : (balance + amount));
    updateBalance(amount);
    await notifyPaymentSuccess(amount, payMethodName);
    await loadData();

    setIsLoading(false);
    setShowRecharge(false);
    setRechargeAmount('');

    if (Platform.OS !== 'web')
      Alert.alert('تم الشحن ✅', `تم إضافة ${amount} ج.م عبر ${payMethodName}`);
  };

  const filteredTx = transactions.filter(
    tx => filter === 'all' || tx.type === filter
  );

  // Stats
  const totalRecharge = transactions
    .filter(t => t.type === 'recharge')
    .reduce((s, t) => s + t.amount, 0);
  const totalSpent = transactions
    .filter(t => t.type === 'ride_payment')
    .reduce((s, t) => s + Math.abs(t.amount), 0);
  const totalRefunds = transactions
    .filter(t => t.type === 'refund')
    .reduce((s, t) => s + t.amount, 0);

  const formatDate = (iso: string) => {
    const d = new Date(iso);
    return d.toLocaleDateString('ar-EG', { day: '2-digit', month: 'short', year: 'numeric' });
  };

  const renderTransaction = ({ item: tx }: { item: WalletTransaction }) => {
    const meta = TX_ICONS[tx.type] ?? TX_ICONS.recharge;
    const isPositive = tx.amount > 0;
    return (
      <View style={styles.txItem}>
        <View style={styles.txRight}>
          <Text style={[styles.txAmount, { color: isPositive ? Colors.success : Colors.error }]}>
            {isPositive ? '+' : ''}{tx.amount.toFixed(0)} ج
          </Text>
          <Text style={styles.txBalance}>{tx.balance_after.toFixed(0)} ج</Text>
        </View>
        <View style={styles.txMiddle}>
          <Text style={styles.txDesc} numberOfLines={1}>{tx.description}</Text>
          <View style={styles.txMeta}>
            {tx.payment_method ? (
              <View style={styles.txMethodBadge}>
                <Text style={styles.txMethodText}>
                  {PAYMENT_METHOD_NAMES[tx.payment_method] ?? tx.payment_method}
                </Text>
              </View>
            ) : null}
            <Text style={styles.txDate}>{formatDate(tx.created_at)}</Text>
          </View>
        </View>
        <View style={[styles.txIconBg, { backgroundColor: meta.color + '18' }]}>
          <MaterialIcons name={meta.icon as any} size={20} color={meta.color} />
        </View>
      </View>
    );
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={isRefreshing} onRefresh={onRefresh} tintColor={Colors.primary} />}
      >
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity style={styles.headerBtn} onPress={() => setShowAllTx(true)}>
            <MaterialIcons name="history" size={20} color={Colors.textSecondary} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>المحفظة الإلكترونية</Text>
        </View>

        {/* Balance Card */}
        <View style={styles.cardWrapper}>
          <LinearGradient
            colors={['#0D2B1E', '#0F3D26', '#0D2B1E']}
            style={styles.balanceCard}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
          >
            <View style={styles.decorCircle1} />
            <View style={styles.decorCircle2} />
            <View style={styles.balanceTop}>
              <View style={styles.balanceRight}>
                <Text style={styles.balanceLabel}>الرصيد المتاح</Text>
                <Text style={styles.balanceAmount}>{balance.toFixed(2)}</Text>
                <Text style={styles.balanceCurrency}>جنيه مصري</Text>
              </View>
              <View style={styles.balanceIconBg}>
                <MaterialIcons name="account-balance-wallet" size={28} color={Colors.primary} />
              </View>
            </View>

            {/* Quick stats */}
            <View style={styles.balanceStats}>
              {[
                { label: 'إجمالي الشحن',    value: `${totalRecharge.toFixed(0)} ج`,  icon: 'arrow-downward', color: Colors.success },
                { label: 'إجمالي الإنفاق',   value: `${totalSpent.toFixed(0)} ج`,     icon: 'arrow-upward',   color: Colors.error },
                { label: 'المستردات',         value: `${totalRefunds.toFixed(0)} ج`,   icon: 'replay',         color: Colors.accent },
              ].map((s, i) => (
                <View key={i} style={styles.balanceStat}>
                  <MaterialIcons name={s.icon as any} size={12} color={s.color} />
                  <Text style={[styles.balanceStatVal, { color: s.color }]}>{s.value}</Text>
                  <Text style={styles.balanceStatLabel}>{s.label}</Text>
                </View>
              ))}
            </View>

            <View style={styles.cardActions}>
              <TouchableOpacity style={styles.cardAction} onPress={() => setShowRecharge(true)}>
                <MaterialIcons name="add-circle" size={20} color={Colors.primary} />
                <Text style={styles.cardActionText}>شحن الرصيد</Text>
              </TouchableOpacity>
              <View style={styles.cardActionDiv} />
              <TouchableOpacity style={styles.cardAction}>
                <MaterialIcons name="send" size={20} color={Colors.accent} />
                <Text style={styles.cardActionText}>تحويل</Text>
              </TouchableOpacity>
              <View style={styles.cardActionDiv} />
              <TouchableOpacity style={styles.cardAction} onPress={() => setShowAllTx(true)}>
                <MaterialIcons name="receipt-long" size={20} color={Colors.gold} />
                <Text style={styles.cardActionText}>كشف الحساب</Text>
              </TouchableOpacity>
            </View>
          </LinearGradient>
        </View>

        {/* Payment Methods */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <TouchableOpacity>
              <Text style={styles.sectionAction}>+ إضافة</Text>
            </TouchableOpacity>
            <Text style={styles.sectionTitle}>طرق الدفع</Text>
          </View>
          <View style={styles.paymentList}>
            {PAYMENT_METHODS.map((method) => (
              <TouchableOpacity key={method.id} style={styles.paymentCard} activeOpacity={0.8}>
                <View style={styles.paymentLeft}>
                  {method.isDefault ? (
                    <View style={styles.defaultBadge}>
                      <Text style={styles.defaultText}>افتراضي</Text>
                    </View>
                  ) : null}
                  <MaterialIcons name="chevron-left" size={20} color={Colors.textTertiary} />
                </View>
                <View style={styles.paymentRight}>
                  <Text style={styles.paymentIcon}>{method.icon}</Text>
                  <View>
                    <Text style={styles.paymentLabel}>{method.label}</Text>
                    {method.balance !== null ? (
                      <Text style={styles.paymentBalance}>{method.balance.toFixed(2)} ج.م</Text>
                    ) : null}
                  </View>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Filter chips */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <TouchableOpacity onPress={() => setShowAllTx(true)}>
              <Text style={styles.sectionAction}>عرض الكل</Text>
            </TouchableOpacity>
            <Text style={styles.sectionTitle}>المعاملات الأخيرة</Text>
          </View>

          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filterScroll}>
            <View style={styles.filterRow}>
              {([
                { key: 'all', label: 'الكل' },
                { key: 'recharge', label: 'الشحن' },
                { key: 'ride_payment', label: 'الرحلات' },
                { key: 'refund', label: 'المستردات' },
              ] as const).map(f => (
                <TouchableOpacity
                  key={f.key}
                  style={[styles.filterChip, filter === f.key && styles.filterChipActive]}
                  onPress={() => setFilter(f.key)}
                >
                  <Text style={[styles.filterChipText, filter === f.key && styles.filterChipTextActive]}>
                    {f.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>

          {filteredTx.length > 0 ? (
            <View style={styles.txList}>
              {filteredTx.slice(0, 5).map(tx => renderTransaction({ item: tx }))}
            </View>
          ) : (
            <View style={styles.emptyTx}>
              <MaterialIcons name="receipt-long" size={40} color={Colors.textTertiary} />
              <Text style={styles.emptyText}>لا توجد معاملات بعد</Text>
            </View>
          )}
        </View>

        {!isSupabaseConfigured ? (
          <View style={styles.infoBanner}>
            <MaterialIcons name="info" size={14} color={Colors.warning} />
            <Text style={styles.infoBannerText}>وضع تجريبي — المعاملات محلية غير محفوظة</Text>
          </View>
        ) : null}

        <View style={{ height: 24 }} />
      </ScrollView>

      {/* Recharge Modal */}
      <Modal visible={showRecharge} transparent animationType="slide" onRequestClose={() => setShowRecharge(false)}>
        <View style={styles.modalOverlay}>
          <View style={[styles.modalSheet, { paddingBottom: insets.bottom + 20 }]}>
            <View style={styles.modalHandle} />
            <View style={styles.modalHeader}>
              <TouchableOpacity onPress={() => setShowRecharge(false)}>
                <MaterialIcons name="close" size={22} color={Colors.textSecondary} />
              </TouchableOpacity>
              <Text style={styles.modalTitle}>شحن الرصيد</Text>
              <View style={{ width: 22 }} />
            </View>

            <View style={styles.currentBalanceRow}>
              <Text style={styles.currentBalanceVal}>{balance.toFixed(2)} ج.م</Text>
              <Text style={styles.currentBalanceLabel}>الرصيد الحالي</Text>
            </View>

            <View style={styles.quickAmounts}>
              {QUICK_AMOUNTS.map(amount => (
                <TouchableOpacity
                  key={amount}
                  style={[styles.quickAmount, rechargeAmount === String(amount) && styles.quickAmountActive]}
                  onPress={() => setRechargeAmount(String(amount))}
                >
                  <Text style={[styles.quickAmountText, rechargeAmount === String(amount) && styles.quickAmountTextActive]}>
                    {amount} ج
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            <View style={styles.amountRow}>
              <Text style={styles.amountCurrency}>ج.م</Text>
              <TextInput
                style={styles.amountInput}
                value={rechargeAmount}
                onChangeText={setRechargeAmount}
                placeholder="0.00"
                placeholderTextColor={Colors.textTertiary}
                keyboardType="decimal-pad"
                textAlign="right"
              />
            </View>

            <Text style={styles.payModalLabel}>اختر طريقة الدفع</Text>
            <View style={styles.payOptions}>
              {PAYMENT_METHODS.filter(p => p.type !== 'cash').map(p => (
                <TouchableOpacity
                  key={p.id}
                  style={[styles.payOption, selectedPayment === p.type && styles.payOptionActive]}
                  onPress={() => setSelectedPayment(p.type)}
                >
                  <Text style={styles.payOptionIcon}>{p.icon}</Text>
                  <Text style={[styles.payOptionText, selectedPayment === p.type && styles.payOptionTextActive]}>
                    {p.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            {rechargeAmount ? (
              <View style={styles.summaryRow}>
                <Text style={styles.summaryVal}>{parseFloat(rechargeAmount || '0').toFixed(2)} ج.م</Text>
                <Text style={styles.summaryLabel}>سيضاف إلى رصيدك:</Text>
              </View>
            ) : null}

            <TouchableOpacity
              style={[styles.confirmBtn, (!rechargeAmount || isLoading) && { opacity: 0.5 }]}
              onPress={handleRecharge}
              disabled={!rechargeAmount || isLoading}
            >
              <LinearGradient colors={[Colors.primary, Colors.primaryDark]} style={styles.confirmGrad}>
                <Text style={styles.confirmText}>
                  {isLoading ? 'جاري الشحن...' : `شحن ${rechargeAmount || 0} ج.م الآن`}
                </Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* All Transactions Modal */}
      <Modal visible={showAllTx} transparent animationType="slide" onRequestClose={() => setShowAllTx(false)}>
        <View style={styles.modalOverlay}>
          <View style={[styles.allTxSheet, { paddingBottom: insets.bottom + 16 }]}>
            <View style={styles.modalHandle} />
            <View style={styles.modalHeader}>
              <TouchableOpacity onPress={() => setShowAllTx(false)}>
                <MaterialIcons name="close" size={22} color={Colors.textSecondary} />
              </TouchableOpacity>
              <Text style={styles.modalTitle}>سجل المعاملات الكامل</Text>
              <View style={{ width: 22 }} />
            </View>
            <FlatList
              data={transactions}
              renderItem={renderTransaction}
              keyExtractor={t => t.id}
              showsVerticalScrollIndicator={false}
              contentContainerStyle={{ padding: Spacing.base, gap: Spacing.sm }}
              ListEmptyComponent={
                <View style={styles.emptyTx}>
                  <MaterialIcons name="receipt-long" size={40} color={Colors.textTertiary} />
                  <Text style={styles.emptyText}>لا توجد معاملات بعد</Text>
                </View>
              }
            />
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.base, paddingVertical: Spacing.base,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  headerTitle: { fontSize: 22, fontWeight: Fonts.bold as any, color: Colors.text },
  headerBtn: { width: 40, height: 40, justifyContent: 'center', alignItems: 'center' },
  cardWrapper: { margin: Spacing.base, borderRadius: Radius.xl, overflow: 'hidden', ...Shadow.lg },
  balanceCard: { padding: Spacing.xl, borderRadius: Radius.xl, overflow: 'hidden', gap: Spacing.md },
  decorCircle1: {
    position: 'absolute', width: 180, height: 180, borderRadius: 90,
    backgroundColor: Colors.primary + '08', top: -60, left: -40,
  },
  decorCircle2: {
    position: 'absolute', width: 120, height: 120, borderRadius: 60,
    backgroundColor: Colors.primary + '06', bottom: -30, right: -20,
  },
  balanceTop: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'flex-start' },
  balanceRight: { alignItems: 'flex-end', gap: 4 },
  balanceLabel: { fontSize: 13, color: Colors.primary + 'AA' },
  balanceAmount: { fontSize: 40, fontWeight: Fonts.extrabold as any, color: Colors.text, letterSpacing: -1 },
  balanceCurrency: { fontSize: 14, color: Colors.textSecondary },
  balanceIconBg: {
    width: 56, height: 56, borderRadius: 28, backgroundColor: Colors.primaryFaded,
    justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: Colors.primary + '30',
  },
  balanceStats: {
    flexDirection: 'row-reverse', backgroundColor: 'rgba(0,0,0,0.15)',
    borderRadius: Radius.md, padding: Spacing.md, gap: Spacing.md,
  },
  balanceStat: { flex: 1, alignItems: 'center', gap: 3 },
  balanceStatVal: { fontSize: 13, fontWeight: Fonts.bold as any },
  balanceStatLabel: { fontSize: 10, color: Colors.textTertiary, textAlign: 'center' },
  cardActions: {
    flexDirection: 'row-reverse', backgroundColor: 'rgba(0,0,0,0.2)',
    borderRadius: Radius.md, overflow: 'hidden',
  },
  cardAction: { flex: 1, alignItems: 'center', gap: 4, paddingVertical: Spacing.sm },
  cardActionText: { fontSize: 11, color: Colors.textSecondary },
  cardActionDiv: { width: 1, backgroundColor: Colors.border, marginVertical: 8 },
  section: { paddingHorizontal: Spacing.base, marginBottom: Spacing.lg },
  sectionHeader: {
    flexDirection: 'row-reverse', justifyContent: 'space-between',
    alignItems: 'center', marginBottom: Spacing.md,
  },
  sectionTitle: { fontSize: 17, fontWeight: Fonts.bold as any, color: Colors.text },
  sectionAction: { fontSize: 13, color: Colors.primary, fontWeight: Fonts.medium as any },
  paymentList: { gap: Spacing.sm },
  paymentCard: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: Colors.card, borderRadius: Radius.md, padding: Spacing.base,
    borderWidth: 1, borderColor: Colors.border,
  },
  paymentRight: { flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.md },
  paymentLeft: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  paymentIcon: { fontSize: 24 },
  paymentLabel: { fontSize: 14, fontWeight: Fonts.medium as any, color: Colors.text, textAlign: 'right' },
  paymentBalance: { fontSize: 13, color: Colors.primary, textAlign: 'right' },
  defaultBadge: {
    backgroundColor: Colors.primaryFaded, paddingHorizontal: 8, paddingVertical: 3,
    borderRadius: Radius.full, borderWidth: 1, borderColor: Colors.primary + '40',
  },
  defaultText: { fontSize: 11, color: Colors.primary, fontWeight: Fonts.medium as any },
  filterScroll: { marginBottom: Spacing.md },
  filterRow: { flexDirection: 'row-reverse', gap: Spacing.sm, paddingVertical: 2 },
  filterChip: {
    paddingHorizontal: 14, paddingVertical: 7, borderRadius: Radius.full,
    backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border,
  },
  filterChipActive: { backgroundColor: Colors.primaryFaded, borderColor: Colors.primary },
  filterChipText: { fontSize: 13, color: Colors.textSecondary, fontWeight: Fonts.medium as any },
  filterChipTextActive: { color: Colors.primary, fontWeight: Fonts.semibold as any },
  txList: { gap: Spacing.sm },
  txItem: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.md,
    backgroundColor: Colors.card, borderRadius: Radius.md, padding: Spacing.md,
    borderWidth: 1, borderColor: Colors.border,
  },
  txIconBg: { width: 40, height: 40, borderRadius: 20, justifyContent: 'center', alignItems: 'center' },
  txMiddle: { flex: 1, alignItems: 'flex-end', gap: 4 },
  txDesc: { fontSize: 14, color: Colors.text, fontWeight: Fonts.medium as any },
  txMeta: { flexDirection: 'row-reverse', alignItems: 'center', gap: 6 },
  txMethodBadge: {
    backgroundColor: Colors.surface, borderRadius: Radius.full,
    paddingHorizontal: 6, paddingVertical: 2,
  },
  txMethodText: { fontSize: 10, color: Colors.textTertiary },
  txDate: { fontSize: 11, color: Colors.textTertiary },
  txRight: { alignItems: 'flex-end', gap: 2, minWidth: 64 },
  txAmount: { fontSize: 15, fontWeight: Fonts.bold as any },
  txBalance: { fontSize: 11, color: Colors.textTertiary },
  emptyTx: {
    alignItems: 'center', paddingVertical: Spacing.xxl, gap: Spacing.md,
  },
  emptyText: { fontSize: 14, color: Colors.textTertiary },
  infoBanner: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: 6,
    backgroundColor: Colors.warningFaded, borderRadius: Radius.md,
    marginHorizontal: Spacing.base, padding: Spacing.md,
    borderWidth: 1, borderColor: Colors.warning + '30', marginBottom: Spacing.lg,
  },
  infoBannerText: { flex: 1, fontSize: 12, color: Colors.warning, textAlign: 'right' },
  // Modal
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'flex-end' },
  modalSheet: {
    backgroundColor: Colors.surface, borderTopLeftRadius: Radius.xxl,
    borderTopRightRadius: Radius.xxl, padding: Spacing.base,
    borderTopWidth: 1, borderTopColor: Colors.border,
  },
  allTxSheet: {
    backgroundColor: Colors.surface, borderTopLeftRadius: Radius.xxl,
    borderTopRightRadius: Radius.xxl, maxHeight: '90%',
    borderTopWidth: 1, borderTopColor: Colors.border,
  },
  modalHandle: {
    width: 40, height: 4, backgroundColor: Colors.border,
    borderRadius: 2, alignSelf: 'center', marginBottom: Spacing.base,
  },
  modalHeader: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between',
    marginBottom: Spacing.lg,
  },
  modalTitle: { fontSize: 20, fontWeight: Fonts.bold as any, color: Colors.text },
  currentBalanceRow: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: Colors.card, borderRadius: Radius.md, padding: Spacing.md,
    borderWidth: 1, borderColor: Colors.border, marginBottom: Spacing.lg,
  },
  currentBalanceLabel: { fontSize: 13, color: Colors.textSecondary },
  currentBalanceVal: { fontSize: 22, fontWeight: Fonts.bold as any, color: Colors.primary },
  quickAmounts: { flexDirection: 'row-reverse', gap: Spacing.sm, marginBottom: Spacing.lg },
  quickAmount: {
    flex: 1, paddingVertical: 10, alignItems: 'center',
    borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.border, backgroundColor: Colors.card,
  },
  quickAmountActive: { backgroundColor: Colors.primaryFaded, borderColor: Colors.primary },
  quickAmountText: { fontSize: 14, color: Colors.textSecondary, fontWeight: Fonts.medium as any },
  quickAmountTextActive: { color: Colors.primary, fontWeight: Fonts.bold as any },
  amountRow: {
    flexDirection: 'row-reverse', alignItems: 'center',
    backgroundColor: Colors.card, borderRadius: Radius.md,
    borderWidth: 1, borderColor: Colors.border, marginBottom: Spacing.lg, overflow: 'hidden',
  },
  amountCurrency: {
    paddingHorizontal: 16, color: Colors.primary, fontSize: 16, fontWeight: Fonts.bold as any,
    borderRightWidth: 1, borderRightColor: Colors.border, paddingVertical: 14,
  },
  amountInput: { flex: 1, paddingHorizontal: 16, color: Colors.text, fontSize: 20, fontWeight: Fonts.bold as any, height: 52 },
  payModalLabel: { fontSize: 14, color: Colors.textSecondary, textAlign: 'right', marginBottom: Spacing.sm },
  payOptions: { flexDirection: 'row-reverse', flexWrap: 'wrap', gap: Spacing.sm, marginBottom: Spacing.lg },
  payOption: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: 6,
    paddingHorizontal: 12, paddingVertical: 8, borderRadius: Radius.full,
    borderWidth: 1, borderColor: Colors.border, backgroundColor: Colors.card,
  },
  payOptionActive: { backgroundColor: Colors.primaryFaded, borderColor: Colors.primary },
  payOptionIcon: { fontSize: 16 },
  payOptionText: { fontSize: 13, color: Colors.textSecondary },
  payOptionTextActive: { color: Colors.primary, fontWeight: Fonts.semibold as any },
  summaryRow: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: Colors.successFaded, borderRadius: Radius.md, padding: Spacing.md,
    borderWidth: 1, borderColor: Colors.success + '30', marginBottom: Spacing.md,
  },
  summaryLabel: { fontSize: 14, color: Colors.success },
  summaryVal: { fontSize: 18, fontWeight: Fonts.bold as any, color: Colors.success },
  confirmBtn: { borderRadius: Radius.md, overflow: 'hidden', ...Shadow.glow },
  confirmGrad: { paddingVertical: 16, alignItems: 'center' },
  confirmText: { color: Colors.textInverse, fontSize: 16, fontWeight: Fonts.bold as any },
});
