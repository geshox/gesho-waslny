// Powered by OnSpace.AI
import React, { useState, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Animated,
  Pressable,
  Platform,
  Dimensions,
  FlatList,
  Alert,
} from 'react-native';
import { Image } from 'expo-image';
import { useRouter, useFocusEffect } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import RideMap from '@/components/RideMap';
import { Colors, Spacing, Radius, Fonts, Shadow } from '@/constants/theme';
import { useAuth } from '@/hooks/useAuth';
import { useRide } from '@/hooks/useRide';
import { useNotifications } from '@/hooks/useNotifications';
import {
  MOCK_DRIVERS,
  Driver,
  VEHICLE_ICONS,
  VEHICLE_LABELS,
  VehicleType,
} from '@/constants/mockData';
import { isSupabaseConfigured } from '@/lib/supabase';
import {
  getOnlineDrivers,
  mapOnlineDriver,
  OnlineDriverRow,
} from '@/services/driverService';

const { width, height } = Dimensions.get('window');

const CAIRO_REGION = {
  latitude: 30.0626,
  longitude: 31.2497,
  latitudeDelta: 0.02,
  longitudeDelta: 0.02,
};

const VEHICLE_COLORS_MAP: Record<string, string> = {
  car: Colors.primary,
  tuk: Colors.gold,
  moto: Colors.accent,
  microbus: '#8B5CF6',
  all: Colors.textSecondary,
};

const VEHICLE_FILTERS: { type: VehicleType | 'all'; label: string; icon: string }[] = [
  { type: 'all', label: 'الكل', icon: '🚀' },
  { type: 'car', label: 'سيارة', icon: '🚗' },
  { type: 'tuk', label: 'توكتوك', icon: '🛺' },
  { type: 'moto', label: 'موتو', icon: '🏍️' },
  { type: 'microbus', label: 'ميكروباص', icon: '🚐' },
];


export default function HomeScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { requestRide, rideStatus } = useRide();
  const { unreadCount, addNotification } = useNotifications();
  const [filter, setFilter] = useState<VehicleType | 'all'>('all');
  const [selectedDriver, setSelectedDriver] = useState<Driver | null>(null);
  const [fromLocation, setFromLocation] = useState('موقعك الحالي');
  const [toLocation, setToLocation] = useState('');
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [locationError, setLocationError] = useState(false);
  const [onlineDriverRows, setOnlineDriverRows] = useState<OnlineDriverRow[] | null>(null);
  const sheetAnim = useRef(new Animated.Value(0)).current;

  // ── Fetch real online drivers (poll every 15s, only while home tab is focused) ──
  useFocusEffect(
    React.useCallback(() => {
      if (!isSupabaseConfigured) return;

      let cancelled = false;
      const loadDrivers = async () => {
        const online = await getOnlineDrivers();
        if (!cancelled) setOnlineDriverRows(online);
      };

      loadDrivers();
      const interval = setInterval(loadDrivers, 15000);
      return () => {
        cancelled = true;
        clearInterval(interval);
      };
    }, [])
  );

  const nearbyDrivers = useMemo(() => {
    if (!isSupabaseConfigured || onlineDriverRows === null) return MOCK_DRIVERS;
    return onlineDriverRows.map(d => mapOnlineDriver(d, userLocation));
  }, [onlineDriverRows, userLocation]);

  const filteredDrivers = filter === 'all'
    ? nearbyDrivers
    : nearbyDrivers.filter(d => d.vehicleType === filter);

  const openDriverSheet = (driver: Driver) => {
    setSelectedDriver(driver);
    Animated.spring(sheetAnim, {
      toValue: 1,
      useNativeDriver: true,
      tension: 80,
      friction: 10,
    }).start();
  };

  const closeDriverSheet = () => {
    Animated.timing(sheetAnim, {
      toValue: 0,
      duration: 250,
      useNativeDriver: true,
    }).start(() => setSelectedDriver(null));
  };

  const handleRequestRide = async () => {
    if (!selectedDriver) return;
    closeDriverSheet();
    await requestRide(
      selectedDriver,
      fromLocation,
      toLocation || 'الوجهة المحددة',
      'wallet',
      user?.id
    );
    addNotification({
      type: 'ride_accepted',
      title: 'تم قبول رحلتك ✅',
      body: `السائق ${selectedDriver.name} في طريقه إليك — التوقع ${selectedDriver.eta} دقيقة`,
      icon: '🚗',
    });
    router.push('/ride/active');
  };

  const sheetTranslateY = sheetAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [500, 0],
  });

  const greeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'صباح الخير 🌤';
    if (hour < 17) return 'مساء الخير ☀️';
    return 'مساء النور 🌙';
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <LinearGradient
        colors={[Colors.surface, 'transparent']}
        style={[styles.header, { paddingTop: insets.top + 8 }]}
      >
        <View style={styles.headerContent}>
          <TouchableOpacity style={styles.notifButton} onPress={() => router.push('/notifications')}>
            <MaterialIcons name="notifications-none" size={24} color={Colors.text} />
            {unreadCount > 0 ? <View style={styles.notifDot} /> : null}
          </TouchableOpacity>

          <View style={styles.locationRow}>
            <MaterialIcons name="location-on" size={14} color={Colors.primary} />
            <Text style={styles.locationText} numberOfLines={1}>
              📍 القاهرة، مصر
            </Text>
          </View>

          <View style={styles.userSection}>
            <View>
              <Text style={styles.greetingText}>{greeting()}</Text>
              <Text style={styles.userName} numberOfLines={1}>
                {user?.name?.split(' ')[0] || 'المستخدم'}
              </Text>
            </View>
            <Image
              source={{ uri: user?.avatar }}
              style={styles.avatar}
              contentFit="cover"
            />
          </View>
        </View>
      </LinearGradient>

      {/* Map — platform-specific (native: react-native-maps, web: styled mock) */}
      <View style={styles.mapContainer}>
        <RideMap
          drivers={filteredDrivers}
          userLocation={userLocation}
          onUserLocation={(coords) => { setUserLocation(coords); setFromLocation('موقعك الحالي'); }}
          onLocationError={() => setLocationError(true)}
          onDriverPress={openDriverSheet}
          insetTop={insets.top}
          vehicleColors={VEHICLE_COLORS_MAP}
        />
        {locationError ? (
          <View style={styles.locationErrorBanner}>
            <MaterialIcons name="location-off" size={14} color={Colors.warning} />
            <Text style={styles.locationErrorText}>تعذّر تحديد موقعك — القاهرة كموقع افتراضي</Text>
          </View>
        ) : null}
      </View>

      {/* Bottom Panel */}
      <View style={[styles.bottomPanel, { paddingBottom: insets.bottom + 80 }]}>
        {/* Search Box */}
        <View style={styles.searchBox}>
          <TouchableOpacity
            style={styles.searchRow}
            onPress={() => router.push('/ride/search')}
            activeOpacity={0.85}
          >
            <MaterialIcons name="my-location" size={18} color={Colors.primary} />
            <Text style={styles.searchFrom} numberOfLines={1}>{fromLocation}</Text>
          </TouchableOpacity>
          <View style={styles.searchDivider} />
          <TouchableOpacity
            style={styles.searchRow}
            onPress={() => router.push('/ride/search')}
            activeOpacity={0.85}
          >
            <MaterialIcons name="location-on" size={18} color={Colors.error} />
            <Text style={[styles.searchFrom, !toLocation && { color: Colors.textTertiary }]} numberOfLines={1}>
              {toLocation || 'إلى أين؟'}
            </Text>
            <MaterialIcons name="arrow-forward-ios" size={12} color={Colors.primary} style={{ marginRight: 'auto' as any }} />
          </TouchableOpacity>
        </View>

        {/* Filter Chips */}
        <View style={styles.filterOuter}>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.filterScroll}
          >
            {VEHICLE_FILTERS.map((f) => {
              const isSelected = filter === f.type;
              return (
                <TouchableOpacity
                  key={f.type}
                  style={[
                    styles.filterChip,
                    isSelected && { backgroundColor: VEHICLE_COLORS_MAP[f.type] + '20', borderColor: VEHICLE_COLORS_MAP[f.type] },
                  ]}
                  onPress={() => setFilter(f.type as any)}
                  activeOpacity={0.75}
                >
                  <Text style={styles.filterIcon}>{f.icon}</Text>
                  <Text style={[
                    styles.filterLabel,
                    isSelected && { color: VEHICLE_COLORS_MAP[f.type], fontWeight: Fonts.semibold as any },
                  ]}>
                    {f.label}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </ScrollView>
        </View>

        {/* Nearby Drivers List */}
        <View style={styles.driversSection}>
          <Text style={styles.driversSectionTitle}>
            السائقون القريبون ({filteredDrivers.length})
          </Text>
          <FlatList
            data={filteredDrivers}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.driversList}
            keyExtractor={(item) => item.id}
            renderItem={({ item: driver }) => (
              <TouchableOpacity
                style={styles.driverCard}
                onPress={() => openDriverSheet(driver)}
                activeOpacity={0.85}
              >
                <Image
                  source={{ uri: driver.avatar }}
                  style={styles.driverAvatar}
                  contentFit="cover"
                />
                <View style={[styles.vehicleBadge, { backgroundColor: VEHICLE_COLORS_MAP[driver.vehicleType] }]}>
                  <Text style={styles.vehicleBadgeIcon}>{VEHICLE_ICONS[driver.vehicleType]}</Text>
                </View>
                <Text style={styles.driverName} numberOfLines={1}>{driver.name.split(' ')[0]}</Text>
                <View style={styles.driverRatingRow}>
                  <MaterialIcons name="star" size={12} color={Colors.gold} />
                  <Text style={styles.driverRating}>{driver.rating}</Text>
                </View>
                <View style={styles.driverDistanceRow}>
                  <MaterialIcons name="navigation" size={11} color={Colors.primary} />
                  <Text style={styles.driverDistance}>{driver.distance} كم</Text>
                </View>
                <Text style={styles.driverPrice}>{driver.price} ج</Text>
              </TouchableOpacity>
            )}
          />
        </View>
      </View>

      {/* Driver Bottom Sheet Backdrop */}
      {selectedDriver ? (
        <Pressable style={styles.backdrop} onPress={closeDriverSheet} />
      ) : null}

      {/* Driver Bottom Sheet */}
      {selectedDriver ? (
        <Animated.View style={[styles.driverSheet, { transform: [{ translateY: sheetTranslateY }], paddingBottom: insets.bottom + 16 }]}>
          {/* Sheet Handle */}
          <View style={styles.sheetHandle} />

          {/* Driver Header */}
          <View style={styles.sheetDriverHeader}>
            <View style={styles.sheetDriverInfo}>
              <Image
                source={{ uri: selectedDriver.avatar }}
                style={styles.sheetAvatar}
                contentFit="cover"
              />
              <View style={[styles.sheetVehicleBadge, { backgroundColor: VEHICLE_COLORS_MAP[selectedDriver.vehicleType] + '20', borderColor: VEHICLE_COLORS_MAP[selectedDriver.vehicleType] }]}>
                <Text>{VEHICLE_ICONS[selectedDriver.vehicleType]}</Text>
              </View>
            </View>
            <View style={styles.sheetDriverDetails}>
              <Text style={styles.sheetDriverName}>{selectedDriver.name}</Text>
              <View style={styles.sheetRatingRow}>
                {[1, 2, 3, 4, 5].map(star => (
                  <MaterialIcons
                    key={star}
                    name="star"
                    size={14}
                    color={star <= Math.floor(selectedDriver.rating) ? Colors.gold : Colors.border}
                  />
                ))}
                <Text style={styles.sheetRatingText}>{selectedDriver.rating} ({selectedDriver.totalRides})</Text>
              </View>
              <Text style={styles.sheetVehicleLabel}>
                {VEHICLE_LABELS[selectedDriver.vehicleType]} — {selectedDriver.vehicleModel}
              </Text>
            </View>
          </View>

          {/* Stats Row */}
          <View style={styles.sheetStats}>
            <View style={styles.sheetStatItem}>
              <MaterialIcons name="directions-car" size={20} color={Colors.primary} />
              <Text style={styles.sheetStatValue}>{selectedDriver.vehiclePlate}</Text>
              <Text style={styles.sheetStatLabel}>رقم اللوحة</Text>
            </View>
            <View style={styles.sheetStatDivider} />
            <View style={styles.sheetStatItem}>
              <MaterialIcons name="access-time" size={20} color={Colors.accent} />
              <Text style={styles.sheetStatValue}>{selectedDriver.eta} دقيقة</Text>
              <Text style={styles.sheetStatLabel}>وقت الوصول</Text>
            </View>
            <View style={styles.sheetStatDivider} />
            <View style={styles.sheetStatItem}>
              <MaterialIcons name="attach-money" size={20} color={Colors.gold} />
              <Text style={styles.sheetStatValue}>{selectedDriver.price} ج.م</Text>
              <Text style={styles.sheetStatLabel}>التكلفة التقديرية</Text>
            </View>
          </View>

          {/* Action Buttons */}
          <View style={styles.sheetActions}>
            <TouchableOpacity style={styles.callButton} activeOpacity={0.8}>
              <MaterialIcons name="phone" size={20} color={Colors.primary} />
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.requestButton}
              onPress={handleRequestRide}
              activeOpacity={0.85}
            >
              <LinearGradient
                colors={[Colors.primary, Colors.primaryDark]}
                style={styles.requestButtonGradient}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
              >
                <MaterialIcons name="directions-car" size={20} color={Colors.textInverse} />
                <Text style={styles.requestButtonText}>طلب الرحلة</Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        </Animated.View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 10,
    paddingHorizontal: Spacing.base,
    paddingBottom: Spacing.lg,
  },
  headerContent: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  userSection: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  greetingText: {
    fontSize: 12,
    color: Colors.textSecondary,
    textAlign: 'right',
  },
  userName: {
    fontSize: 16,
    fontWeight: Fonts.bold as any,
    color: Colors.text,
    textAlign: 'right',
    maxWidth: 100,
  },
  avatar: {
    width: 42,
    height: 42,
    borderRadius: 21,
    borderWidth: 2,
    borderColor: Colors.primary,
  },
  locationRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 4,
    backgroundColor: Colors.card,
    borderRadius: Radius.full,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  locationText: {
    fontSize: 12,
    color: Colors.textSecondary,
    maxWidth: 100,
  },
  notifButton: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: Colors.card,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.border,
  },
  notifDot: {
    position: 'absolute',
    top: 8,
    right: 8,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.error,
    borderWidth: 1.5,
    borderColor: Colors.background,
  },
  // Map
  mapContainer: {
    flex: 1,
    position: 'relative',
  },
  locationErrorBanner: {
    position: 'absolute',
    bottom: 8,
    left: 12,
    right: 12,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 6,
    backgroundColor: Colors.warningFaded,
    borderRadius: Radius.full,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderWidth: 1,
    borderColor: Colors.warning + '30',
  },
  locationErrorText: {
    fontSize: 11,
    color: Colors.warning,
    flex: 1,
    textAlign: 'right',
  },
  // Bottom Panel
  bottomPanel: {
    backgroundColor: Colors.surface,
    borderTopLeftRadius: Radius.xxl,
    borderTopRightRadius: Radius.xxl,
    paddingTop: Spacing.base,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  searchBox: {
    marginHorizontal: Spacing.base,
    backgroundColor: Colors.card,
    borderRadius: Radius.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    overflow: 'hidden',
    marginBottom: Spacing.md,
  },
  searchRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
    gap: Spacing.sm,
  },
  searchDivider: {
    height: 1,
    backgroundColor: Colors.border,
    marginLeft: 52,
  },
  searchFrom: {
    flex: 1,
    color: Colors.textSecondary,
    fontSize: 14,
    textAlign: 'right',
  },
  searchInput: {
    flex: 1,
    color: Colors.text,
    fontSize: 14,
    textAlign: 'right',
    height: 24,
  },
  // Filters
  filterOuter: {
    height: 52,
    marginBottom: Spacing.md,
  },
  filterScroll: {
    paddingHorizontal: Spacing.base,
    gap: Spacing.sm,
    alignItems: 'center',
  },
  filterChip: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: Radius.full,
    borderWidth: 1,
    borderColor: Colors.border,
    backgroundColor: Colors.card,
  },
  filterIcon: { fontSize: 14 },
  filterLabel: {
    fontSize: 13,
    color: Colors.textSecondary,
  },
  // Drivers List
  driversSection: {
    paddingLeft: Spacing.base,
  },
  driversSectionTitle: {
    fontSize: 14,
    fontWeight: Fonts.semibold as any,
    color: Colors.textSecondary,
    marginBottom: Spacing.sm,
    textAlign: 'right',
    paddingRight: Spacing.base,
  },
  driversList: {
    paddingRight: Spacing.base,
    gap: Spacing.sm,
  },
  driverCard: {
    width: 100,
    backgroundColor: Colors.card,
    borderRadius: Radius.lg,
    padding: Spacing.sm,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.border,
    ...Shadow.sm,
  },
  driverAvatar: {
    width: 52,
    height: 52,
    borderRadius: 26,
    marginBottom: 4,
  },
  vehicleBadge: {
    position: 'absolute',
    top: 36,
    right: 8,
    width: 20,
    height: 20,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: Colors.surface,
  },
  vehicleBadgeIcon: { fontSize: 10 },
  driverName: {
    fontSize: 12,
    fontWeight: Fonts.semibold as any,
    color: Colors.text,
    marginBottom: 3,
  },
  driverRatingRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 2,
    marginBottom: 3,
  },
  driverRating: {
    fontSize: 11,
    color: Colors.gold,
    fontWeight: Fonts.medium as any,
  },
  driverDistanceRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 2,
    marginBottom: 4,
  },
  driverDistance: {
    fontSize: 11,
    color: Colors.textSecondary,
  },
  driverPrice: {
    fontSize: 13,
    fontWeight: Fonts.bold as any,
    color: Colors.primary,
  },
  // Bottom Sheet
  backdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.5)',
    zIndex: 20,
  },
  driverSheet: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: Colors.surface,
    borderTopLeftRadius: Radius.xxl,
    borderTopRightRadius: Radius.xxl,
    padding: Spacing.base,
    zIndex: 30,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    ...Shadow.lg,
  },
  sheetHandle: {
    width: 40,
    height: 4,
    backgroundColor: Colors.border,
    borderRadius: 2,
    alignSelf: 'center',
    marginBottom: Spacing.base,
  },
  sheetDriverHeader: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: Spacing.md,
    marginBottom: Spacing.base,
  },
  sheetDriverInfo: {
    position: 'relative',
  },
  sheetAvatar: {
    width: 72,
    height: 72,
    borderRadius: 36,
    borderWidth: 2,
    borderColor: Colors.primary,
  },
  sheetVehicleBadge: {
    position: 'absolute',
    bottom: -2,
    left: -2,
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: Colors.border,
  },
  sheetDriverDetails: {
    flex: 1,
    alignItems: 'flex-end',
    gap: 4,
  },
  sheetDriverName: {
    fontSize: 18,
    fontWeight: Fonts.bold as any,
    color: Colors.text,
    textAlign: 'right',
  },
  sheetRatingRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 3,
  },
  sheetRatingText: {
    fontSize: 12,
    color: Colors.textSecondary,
    marginRight: 4,
  },
  sheetVehicleLabel: {
    fontSize: 13,
    color: Colors.textSecondary,
    textAlign: 'right',
  },
  sheetStats: {
    flexDirection: 'row-reverse',
    backgroundColor: Colors.card,
    borderRadius: Radius.lg,
    padding: Spacing.base,
    marginBottom: Spacing.base,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  sheetStatItem: {
    flex: 1,
    alignItems: 'center',
    gap: 4,
  },
  sheetStatDivider: {
    width: 1,
    backgroundColor: Colors.border,
    marginVertical: 4,
  },
  sheetStatValue: {
    fontSize: 13,
    fontWeight: Fonts.semibold as any,
    color: Colors.text,
    textAlign: 'center',
  },
  sheetStatLabel: {
    fontSize: 11,
    color: Colors.textTertiary,
    textAlign: 'center',
  },
  sheetActions: {
    flexDirection: 'row-reverse',
    gap: Spacing.sm,
  },
  callButton: {
    width: 56,
    height: 56,
    borderRadius: Radius.md,
    backgroundColor: Colors.primaryFaded,
    borderWidth: 1,
    borderColor: Colors.primary + '40',
    justifyContent: 'center',
    alignItems: 'center',
  },
  requestButton: {
    flex: 1,
    borderRadius: Radius.md,
    overflow: 'hidden',
    ...Shadow.glow,
  },
  requestButtonGradient: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    borderRadius: Radius.md,
  },
  requestButtonText: {
    color: Colors.textInverse,
    fontSize: 16,
    fontWeight: Fonts.bold as any,
  },
});
