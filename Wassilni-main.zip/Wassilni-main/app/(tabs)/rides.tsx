// Powered by OnSpace.AI
import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ScrollView,
  Animated,
  Dimensions,
} from 'react-native';
import { Image } from 'expo-image';
import { useRouter, useFocusEffect } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Spacing, Radius, Fonts, Shadow } from '@/constants/theme';
import { useRide } from '@/hooks/useRide';
import { useAuth } from '@/hooks/useAuth';
import { RideHistory, VEHICLE_ICONS, VEHICLE_LABELS } from '@/constants/mockData';

const { width } = Dimensions.get('window');

const STATUS_FILTERS = [
  { key: 'all',       label: 'الكل',      icon: 'list' },
  { key: 'completed', label: 'مكتملة',    icon: 'check-circle' },
  { key: 'cancelled', label: 'ملغية',     icon: 'cancel' },
];

const DATE_FILTERS = [
  { key: 'all',   label: 'كل الأوقات' },
  { key: 'week',  label: 'هذا الأسبوع' },
  { key: 'month', label: 'هذا الشهر' },
];

const STATUS_META: Record<string, { label: string; color: string; bg: string; icon: string }> = {
  completed: { label: 'مكتملة',       color: Colors.success, bg: Colors.successFaded, icon: 'check-circle' },
  cancelled: { label: 'ملغية',        color: Colors.error,   bg: Colors.errorFaded,   icon: 'cancel' },
  pending:   { label: 'قيد الانتظار', color: Colors.warning, bg: Colors.warningFaded, icon: 'schedule' },
};

const VEHICLE_COLOR: Record<string, string> = {
  car:      Colors.primary,
  tuk:      Colors.gold,
  moto:     Colors.accent,
  microbus: '#8B5CF6',
};

export default function RidesScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { rideHistory, loadRideHistory } = useRide();
  const { user } = useAuth();
  const [activeStatus, setActiveStatus] = useState('all');
  const [activeDateFilter, setActiveDateFilter] = useState('all');
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const expandAnims = useRef<Record<string, Animated.Value>>({}).current;

  useFocusEffect(
    React.useCallback(() => {
      if (user?.id) loadRideHistory(user.id);
    }, [user?.id])
  );

  const getExpandAnim = (id: string) => {
    if (!expandAnims[id]) expandAnims[id] = new Animated.Value(0);
    return expandAnims[id];
  };

  const toggleExpand = (id: string) => {
    const isOpen = expandedId === id;
    const anim = getExpandAnim(id);
    if (isOpen) {
      Animated.timing(anim, { toValue: 0, duration: 220, useNativeDriver: false }).start();
      setExpandedId(null);
    } else {
      if (expandedId) {
        Animated.timing(getExpandAnim(expandedId), { toValue: 0, duration: 180, useNativeDriver: false }).start();
      }
      setExpandedId(id);
      Animated.timing(anim, { toValue: 1, duration: 280, useNativeDriver: false }).start();
    }
  };

  const filteredRides = rideHistory.filter(r => {
    const statusOk = activeStatus === 'all' || r.status === activeStatus;
    return statusOk;
  });

  const completedRides = rideHistory.filter(r => r.status === 'completed');
  const totalSpent = completedRides.reduce((sum, r) => sum + r.price, 0);
  const avgRating = completedRides.filter(r => r.rating)
    .reduce((sum, r, _, arr) => sum + (r.rating ?? 0) / arr.length, 0);

  const renderRide = ({ item, index }: { item: RideHistory; index: number }) => {
    const status = STATUS_META[item.status];
    const isExpanded = expandedId === item.id;
    const expandAnim = getExpandAnim(item.id);
    const vehicleColor = VEHICLE_COLOR[item.vehicleType] || Colors.primary;

    const detailHeight = expandAnim.interpolate({
      inputRange: [0, 1],
      outputRange: [0, 120],
    });
    const detailOpacity = expandAnim.interpolate({
      inputRange: [0, 0.5, 1],
      outputRange: [0, 0, 1],
    });

    return (
      <TouchableOpacity
        style={[styles.rideCard, isExpanded && styles.rideCardExpanded]}
        onPress={() => toggleExpand(item.id)}
        activeOpacity={0.92}
      >
        {/* Left accent strip */}
        <View style={[styles.cardAccent, { backgroundColor: vehicleColor }]} />

        <View style={styles.cardBody}>
          {/* ── Header Row ── */}
          <View style={styles.cardHeader}>
            <View style={styles.cardHeaderLeft}>
              <View style={[styles.statusBadge, { backgroundColor: status.bg }]}>
                <MaterialIcons name={status.icon as any} size={11} color={status.color} />
                <Text style={[styles.statusText, { color: status.color }]}>{status.label}</Text>
              </View>
              <Text style={styles.dateText}>{item.date} · {item.time}</Text>
            </View>

            <View style={styles.driverRow}>
              <View style={styles.driverDetails}>
                <Text style={styles.driverName}>{item.driverName}</Text>
                <View style={styles.vehicleTag}>
                  <Text style={styles.vehicleEmoji}>{VEHICLE_ICONS[item.vehicleType]}</Text>
                  <Text style={[styles.vehicleLabel, { color: vehicleColor }]}>
                    {VEHICLE_LABELS[item.vehicleType]}
                  </Text>
                </View>
              </View>
              <View style={styles.avatarWrap}>
                <Image
                  source={{ uri: item.driverAvatar }}
                  style={[styles.driverAvatar, { borderColor: vehicleColor + '60' }]}
                  contentFit="cover"
                />
                {item.rating ? (
                  <View style={styles.ratingBadge}>
                    <MaterialIcons name="star" size={9} color={Colors.gold} />
                    <Text style={styles.ratingBadgeText}>{item.rating}</Text>
                  </View>
                ) : null}
              </View>
            </View>
          </View>

          {/* ── Route ── */}
          <View style={styles.routeBox}>
            <View style={styles.routeDotsColumn}>
              <View style={[styles.routeDot, { backgroundColor: Colors.primary }]} />
              <View style={styles.routeConnector} />
              <View style={[styles.routeDot, { backgroundColor: Colors.error }]} />
            </View>
            <View style={styles.routeLabels}>
              <Text style={styles.routeFrom} numberOfLines={1}>{item.fromLocation}</Text>
              <Text style={styles.routeTo} numberOfLines={1}>{item.toLocation}</Text>
            </View>
          </View>

          {/* ── Footer Stats ── */}
          <View style={styles.footerRow}>
            <View style={styles.footerLeft}>
              <View style={styles.metaItem}>
                <MaterialIcons name="straighten" size={12} color={Colors.textTertiary} />
                <Text style={styles.metaText}>{item.distance} كم</Text>
              </View>
              {item.duration > 0 ? (
                <View style={styles.metaItem}>
                  <MaterialIcons name="access-time" size={12} color={Colors.textTertiary} />
                  <Text style={styles.metaText}>{item.duration} د</Text>
                </View>
              ) : null}
              <MaterialIcons
                name={isExpanded ? 'keyboard-arrow-up' : 'keyboard-arrow-down'}
                size={16}
                color={Colors.textTertiary}
              />
            </View>
            <Text style={[styles.priceText, { color: vehicleColor }]}>{item.price} ج.م</Text>
          </View>

          {/* ── Expandable detail ── */}
          <Animated.View style={{ height: detailHeight, overflow: 'hidden' }}>
            <Animated.View style={[styles.expandedContent, { opacity: detailOpacity }]}>
              <View style={styles.expandDivider} />
              <View style={styles.expandGrid}>
                <View style={styles.expandItem}>
                  <MaterialIcons name="payments" size={18} color={Colors.gold} />
                  <Text style={styles.expandItemLabel}>طريقة الدفع</Text>
                  <Text style={styles.expandItemVal}>محفظة</Text>
                </View>
                <View style={styles.expandItem}>
                  <MaterialIcons name="speed" size={18} color={Colors.accent} />
                  <Text style={styles.expandItemLabel}>متوسط السرعة</Text>
                  <Text style={styles.expandItemVal}>
                    {item.duration > 0 ? Math.round((item.distance / item.duration) * 60) : '—'} كم/س
                  </Text>
                </View>
                <View style={styles.expandItem}>
                  <MaterialIcons name="attach-money" size={18} color={Colors.success} />
                  <Text style={styles.expandItemLabel}>سعر الكيلومتر</Text>
                  <Text style={styles.expandItemVal}>
                    {item.distance > 0 ? (item.price / item.distance).toFixed(1) : '—'} ج
                  </Text>
                </View>
              </View>

              <View style={styles.expandActions}>
                {item.status === 'completed' && !item.rating ? (
                  <TouchableOpacity
                    style={styles.rateBtn}
                    onPress={() => router.push('/ride/rating')}
                  >
                    <LinearGradient
                      colors={[Colors.goldFaded, Colors.warningFaded]}
                      style={styles.rateBtnGrad}
                    >
                      <MaterialIcons name="star" size={14} color={Colors.gold} />
                      <Text style={styles.rateBtnText}>قيّم الرحلة</Text>
                    </LinearGradient>
                  </TouchableOpacity>
                ) : null}
                <TouchableOpacity
                  style={styles.repeatBtn}
                  onPress={() => router.push('/(tabs)')}
                >
                  <MaterialIcons name="refresh" size={14} color={Colors.primary} />
                  <Text style={styles.repeatBtnText}>كرّر الرحلة</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.reportBtn}>
                  <MaterialIcons name="report-problem" size={14} color={Colors.error} />
                  <Text style={styles.reportBtnText}>بلّغ</Text>
                </TouchableOpacity>
              </View>
            </Animated.View>
          </Animated.View>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* ── Header ── */}
      <LinearGradient
        colors={['#0D2B1E', Colors.background]}
        style={styles.header}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
      >
        <View style={styles.headerRow}>
          <View style={styles.headerRight}>
            <Text style={styles.headerTitle}>رحلاتي</Text>
            <Text style={styles.headerSub}>{rideHistory.length} رحلة إجمالاً</Text>
          </View>
          <View style={styles.headerIconBg}>
            <MaterialIcons name="history" size={24} color={Colors.primary} />
          </View>
        </View>

        {/* ── Stats Strip ── */}
        <View style={styles.statsStrip}>
          <View style={styles.statChip}>
            <LinearGradient colors={[Colors.successFaded, Colors.primaryFaded]} style={styles.statChipGrad}>
              <Text style={styles.statChipValue}>{completedRides.length}</Text>
              <Text style={styles.statChipLabel}>مكتملة</Text>
            </LinearGradient>
          </View>
          <View style={styles.statChip}>
            <LinearGradient colors={[Colors.goldFaded, Colors.primaryFaded]} style={styles.statChipGrad}>
              <Text style={[styles.statChipValue, { color: Colors.gold }]}>{totalSpent} ج</Text>
              <Text style={styles.statChipLabel}>المصروف</Text>
            </LinearGradient>
          </View>
          <View style={styles.statChip}>
            <LinearGradient colors={[Colors.warningFaded, Colors.goldFaded]} style={styles.statChipGrad}>
              <View style={styles.ratingRow}>
                <MaterialIcons name="star" size={13} color={Colors.gold} />
                <Text style={[styles.statChipValue, { color: Colors.gold }]}>
                  {avgRating > 0 ? avgRating.toFixed(1) : '—'}
                </Text>
              </View>
              <Text style={styles.statChipLabel}>متوسط تقييمي</Text>
            </LinearGradient>
          </View>
          <View style={styles.statChip}>
            <LinearGradient colors={[Colors.errorFaded, Colors.warningFaded]} style={styles.statChipGrad}>
              <Text style={[styles.statChipValue, { color: Colors.error }]}>
                {rideHistory.filter(r => r.status === 'cancelled').length}
              </Text>
              <Text style={styles.statChipLabel}>ملغية</Text>
            </LinearGradient>
          </View>
        </View>
      </LinearGradient>

      {/* ── Status Filter Tabs ── */}
      <View style={styles.filterSection}>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.filterRow}
        >
          {STATUS_FILTERS.map(f => {
            const isActive = activeStatus === f.key;
            return (
              <TouchableOpacity
                key={f.key}
                style={[styles.filterTab, isActive && styles.filterTabActive]}
                onPress={() => setActiveStatus(f.key)}
                activeOpacity={0.8}
              >
                <MaterialIcons
                  name={f.icon as any}
                  size={14}
                  color={isActive ? Colors.primary : Colors.textTertiary}
                />
                <Text style={[styles.filterTabText, isActive && styles.filterTabTextActive]}>
                  {f.label}
                </Text>
                {isActive ? (
                  <View style={styles.filterTabCount}>
                    <Text style={styles.filterTabCountText}>
                      {f.key === 'all'
                        ? rideHistory.length
                        : rideHistory.filter(r => r.status === f.key).length}
                    </Text>
                  </View>
                ) : null}
              </TouchableOpacity>
            );
          })}
        </ScrollView>

        {/* Date sub-filter */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.dateFilterRow}
        >
          {DATE_FILTERS.map(f => (
            <TouchableOpacity
              key={f.key}
              style={[styles.datePill, activeDateFilter === f.key && styles.datePillActive]}
              onPress={() => setActiveDateFilter(f.key)}
            >
              <Text style={[styles.datePillText, activeDateFilter === f.key && styles.datePillTextActive]}>
                {f.label}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      {/* ── Ride List ── */}
      <FlatList
        data={filteredRides}
        renderItem={renderRide}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        ItemSeparatorComponent={() => <View style={{ height: Spacing.md }} />}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <View style={styles.emptyIconWrap}>
              <LinearGradient colors={[Colors.primaryFaded, Colors.surfaceElevated]} style={styles.emptyIconBg}>
                <MaterialIcons name="history" size={48} color={Colors.primary + '80'} />
              </LinearGradient>
            </View>
            <Text style={styles.emptyTitle}>لا توجد رحلات</Text>
            <Text style={styles.emptySubtitle}>ستظهر رحلاتك هنا بعد إتمامها</Text>
            <TouchableOpacity
              style={styles.emptyAction}
              onPress={() => router.push('/(tabs)')}
            >
              <LinearGradient colors={[Colors.primary, Colors.primaryDark]} style={styles.emptyActionGrad}>
                <MaterialIcons name="add" size={16} color={Colors.textInverse} />
                <Text style={styles.emptyActionText}>احجز رحلتك الأولى</Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },

  // Header
  header: {
    paddingHorizontal: Spacing.base,
    paddingBottom: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  headerRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: Spacing.md,
  },
  headerRight: { alignItems: 'flex-end', gap: 2 },
  headerTitle: { fontSize: 22, fontWeight: Fonts.bold as any, color: Colors.text },
  headerSub: { fontSize: 12, color: Colors.textTertiary },
  headerIconBg: {
    width: 48, height: 48, borderRadius: 14,
    backgroundColor: Colors.primaryFaded, justifyContent: 'center', alignItems: 'center',
    borderWidth: 1, borderColor: Colors.primary + '30',
  },

  // Stats strip
  statsStrip: {
    flexDirection: 'row-reverse',
    gap: Spacing.sm,
    marginTop: Spacing.sm,
  },
  statChip: {
    flex: 1, borderRadius: Radius.md, overflow: 'hidden',
    borderWidth: 1, borderColor: Colors.border,
  },
  statChipGrad: { padding: Spacing.sm, alignItems: 'center', gap: 2 },
  statChipValue: { fontSize: 15, fontWeight: Fonts.bold as any, color: Colors.text },
  statChipLabel: { fontSize: 9, color: Colors.textTertiary, textAlign: 'center' },
  ratingRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 2 },

  // Filters
  filterSection: { borderBottomWidth: 1, borderBottomColor: Colors.border },
  filterRow: {
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.sm,
    gap: Spacing.sm,
    flexDirection: 'row-reverse',
  },
  filterTab: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: Radius.full,
    borderWidth: 1,
    borderColor: Colors.border,
    backgroundColor: Colors.card,
  },
  filterTabActive: {
    backgroundColor: Colors.primaryFaded,
    borderColor: Colors.primary + '60',
  },
  filterTabText: { fontSize: 13, color: Colors.textTertiary, fontWeight: Fonts.medium as any },
  filterTabTextActive: { color: Colors.primary, fontWeight: Fonts.semibold as any },
  filterTabCount: {
    backgroundColor: Colors.primary,
    borderRadius: Radius.full,
    minWidth: 18, height: 18,
    justifyContent: 'center', alignItems: 'center',
    paddingHorizontal: 4,
  },
  filterTabCountText: { fontSize: 10, color: Colors.textInverse, fontWeight: Fonts.bold as any },

  dateFilterRow: {
    paddingHorizontal: Spacing.base,
    paddingBottom: Spacing.sm,
    gap: 8,
    flexDirection: 'row-reverse',
  },
  datePill: {
    paddingHorizontal: 12, paddingVertical: 5,
    borderRadius: Radius.full, borderWidth: 1, borderColor: Colors.border,
  },
  datePillActive: { borderColor: Colors.primary + '40', backgroundColor: Colors.primary + '08' },
  datePillText: { fontSize: 11, color: Colors.textTertiary },
  datePillTextActive: { color: Colors.primary, fontWeight: Fonts.medium as any },

  // List
  listContent: {
    padding: Spacing.base,
    paddingBottom: 100,
  },

  // Ride Card
  rideCard: {
    backgroundColor: Colors.card,
    borderRadius: Radius.xl,
    borderWidth: 1,
    borderColor: Colors.border,
    overflow: 'hidden',
    flexDirection: 'row',
    ...Shadow.sm,
  },
  rideCardExpanded: {
    borderColor: Colors.primary + '30',
    ...Shadow.md,
  },
  cardAccent: {
    width: 4,
  },
  cardBody: {
    flex: 1,
    padding: Spacing.base,
    paddingLeft: Spacing.md,
  },

  // Card header
  cardHeader: {
    flexDirection: 'row-reverse',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    marginBottom: Spacing.sm,
  },
  cardHeaderLeft: { alignItems: 'flex-start', gap: 5 },
  statusBadge: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8, paddingVertical: 3,
    borderRadius: Radius.full,
  },
  statusText: { fontSize: 11, fontWeight: Fonts.semibold as any },
  dateText: { fontSize: 11, color: Colors.textTertiary },
  driverRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.sm },
  driverDetails: { alignItems: 'flex-end', gap: 3 },
  driverName: { fontSize: 14, fontWeight: Fonts.semibold as any, color: Colors.text },
  vehicleTag: { flexDirection: 'row-reverse', alignItems: 'center', gap: 4 },
  vehicleEmoji: { fontSize: 12 },
  vehicleLabel: { fontSize: 11, fontWeight: Fonts.medium as any },
  avatarWrap: { position: 'relative' },
  driverAvatar: { width: 44, height: 44, borderRadius: 22, borderWidth: 2 },
  ratingBadge: {
    position: 'absolute', bottom: -3, right: -3,
    flexDirection: 'row-reverse', alignItems: 'center', gap: 1,
    backgroundColor: Colors.background, borderRadius: Radius.full,
    paddingHorizontal: 4, paddingVertical: 1,
    borderWidth: 1, borderColor: Colors.gold + '40',
  },
  ratingBadgeText: { fontSize: 9, color: Colors.gold, fontWeight: Fonts.bold as any },

  // Route
  routeBox: {
    flexDirection: 'row-reverse',
    alignItems: 'stretch',
    backgroundColor: Colors.surface,
    borderRadius: Radius.md,
    padding: Spacing.sm,
    gap: Spacing.sm,
    marginBottom: Spacing.sm,
  },
  routeDotsColumn: { alignItems: 'center', width: 12, justifyContent: 'space-between', paddingVertical: 2 },
  routeDot: { width: 8, height: 8, borderRadius: 4 },
  routeConnector: { flex: 1, width: 1.5, backgroundColor: Colors.border, marginVertical: 2 },
  routeLabels: { flex: 1, gap: 8, justifyContent: 'space-between' },
  routeFrom: { fontSize: 12, color: Colors.textSecondary, textAlign: 'right' },
  routeTo: { fontSize: 12, color: Colors.textSecondary, textAlign: 'right' },

  // Footer
  footerRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  footerLeft: { flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.sm },
  metaItem: { flexDirection: 'row-reverse', alignItems: 'center', gap: 3 },
  metaText: { fontSize: 11, color: Colors.textTertiary },
  priceText: { fontSize: 20, fontWeight: Fonts.extrabold as any },

  // Expanded
  expandedContent: { paddingTop: Spacing.sm },
  expandDivider: { height: 1, backgroundColor: Colors.border, marginBottom: Spacing.sm },
  expandGrid: { flexDirection: 'row-reverse', gap: Spacing.sm, marginBottom: Spacing.sm },
  expandItem: {
    flex: 1, alignItems: 'center', gap: 3,
    backgroundColor: Colors.surface, borderRadius: Radius.md, padding: Spacing.sm,
    borderWidth: 1, borderColor: Colors.border,
  },
  expandItemLabel: { fontSize: 10, color: Colors.textTertiary, textAlign: 'center' },
  expandItemVal: { fontSize: 12, fontWeight: Fonts.semibold as any, color: Colors.text, textAlign: 'center' },
  expandActions: { flexDirection: 'row-reverse', gap: Spacing.sm },
  rateBtn: { flex: 1.5, borderRadius: Radius.md, overflow: 'hidden' },
  rateBtnGrad: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center',
    gap: 5, paddingVertical: 10,
  },
  rateBtnText: { fontSize: 12, color: Colors.gold, fontWeight: Fonts.semibold as any },
  repeatBtn: {
    flex: 1.5, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center',
    gap: 5, paddingVertical: 10, borderRadius: Radius.md,
    backgroundColor: Colors.primaryFaded, borderWidth: 1, borderColor: Colors.primary + '30',
  },
  repeatBtnText: { fontSize: 12, color: Colors.primary, fontWeight: Fonts.medium as any },
  reportBtn: {
    flex: 0.8, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center',
    gap: 4, paddingVertical: 10, borderRadius: Radius.md,
    backgroundColor: Colors.errorFaded, borderWidth: 1, borderColor: Colors.error + '30',
  },
  reportBtnText: { fontSize: 12, color: Colors.error },

  // Empty
  emptyState: { alignItems: 'center', paddingTop: 60, gap: Spacing.base },
  emptyIconWrap: { borderRadius: 60, overflow: 'hidden', ...Shadow.sm },
  emptyIconBg: { width: 100, height: 100, justifyContent: 'center', alignItems: 'center' },
  emptyTitle: { fontSize: 18, fontWeight: Fonts.semibold as any, color: Colors.textSecondary },
  emptySubtitle: { fontSize: 14, color: Colors.textTertiary, textAlign: 'center' },
  emptyAction: { borderRadius: Radius.md, overflow: 'hidden', ...Shadow.glow },
  emptyActionGrad: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center',
    gap: 8, paddingVertical: 13, paddingHorizontal: 24,
  },
  emptyActionText: { color: Colors.textInverse, fontSize: 14, fontWeight: Fonts.semibold as any },
  surfaceElevated: {},
});
