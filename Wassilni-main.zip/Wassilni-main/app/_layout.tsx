// Powered by OnSpace.AI
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { I18nManager } from 'react-native';
import { AuthProvider } from '@/contexts/AuthContext';
import { RideProvider } from '@/contexts/RideContext';
import { NotificationsProvider } from '@/contexts/NotificationsContext';
import { ThemeProvider } from '@/contexts/ThemeContext';
import { DriverProvider } from '@/contexts/DriverContext';
import { SafeAreaProvider } from 'react-native-safe-area-context';

// Enable RTL for Arabic
I18nManager.allowRTL(true);

export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <ThemeProvider>
      <AuthProvider>
        <DriverProvider>
        <NotificationsProvider>
        <RideProvider>
          <StatusBar style="light" backgroundColor="#070B14" />
          <Stack screenOptions={{ headerShown: false }}>
            <Stack.Screen name="index" />
            <Stack.Screen name="onboarding" />
            <Stack.Screen name="auth/login" />
            <Stack.Screen name="auth/otp" />
            <Stack.Screen name="auth/driver-register" />
            <Stack.Screen name="(tabs)" />
            <Stack.Screen name="notifications" />
            <Stack.Screen name="admin/index" />
            <Stack.Screen name="admin/users" />
            <Stack.Screen name="admin/complaints" />
            <Stack.Screen name="admin/pricing" />
            <Stack.Screen name="ride/active" options={{ presentation: 'modal' }} />
            <Stack.Screen name="ride/rating" options={{ presentation: 'modal' }} />
            <Stack.Screen name="ride/chat" options={{ presentation: 'modal' }} />
            <Stack.Screen name="ride/search" />
            <Stack.Screen name="complaints/new" options={{ presentation: 'modal' }} />
            <Stack.Screen name="(driver)" />
          </Stack>
        </RideProvider>
        </NotificationsProvider>
        </DriverProvider>
      </AuthProvider>
      </ThemeProvider>
    </SafeAreaProvider>
  );
}
