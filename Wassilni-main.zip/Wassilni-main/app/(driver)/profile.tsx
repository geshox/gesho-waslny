// Powered by OnSpace.AI
import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Switch, Alert, Platform,
} from 'react-native';
import { Image } from 'expo-image';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Spacing, Radius, Fonts, Shadow } from '@/constants/theme';
import { useAuth } from '@/hooks/useAuth';
import { useDriver } from '@/hooks/useDriver';
import { ThemeToggle } from '@/components/ThemeToggle';
import { useTheme } from '@/hooks/useTheme';

const VEHICLE_ICONS: Record<string, string> = {
  car: '🚗', tuk: '🛺', moto: '🏍️', microbus: '🚐',
};

const APPROVAL_LABELS: Record<string, { label: string; color: string }> = {
  pending:  { label: 'قيد المراجعة', color: Colors.warning },
  approved: { label: 'معتمد ✓',      color: Colors.success },
  rejected: { label: 'مرفوض',        color: Colors.error },
};

export default function DriverProfile() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { user, logout } = useAuth();
  const { driverProfile, stats } = useDriver();
  const { isDark } = useTheme();
  const [notifications, setNotifications] = useState(true);

  const handleLogout = () => {
    if (Platform.OS !== 'web') {
      Alert.alert('تسجيل الخروج', 'هل أنت متأكد؟', [
        { text: 'إلغاء', style: 'cancel' },
        { text: 'خروج', style: 'destructive', onPress: () => { logout(); router.replace('/onboarding'); } },
      ]);
    } else {
      logout();
      router.replace('/onboarding');
    }
  };

  const approval = driverProfile?.approval_status
    ? APPROVAL_LABELS[driverProfile.approval_status]
    : APPROVAL_LABELS.pending;

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <LinearGradient colors={['#0D2B1E', Colors.background]} style={styles.profileHeader}>
          <View style={styles.avatarSection}>
            <View style={styles.avatarWrapper}>
              <Image source={{ uri: user?.avatar }} style={styles.avatar} contentFit="cover" />
              <View style={styles.driverBadge}>
                <Text style={styles.driverBadgeText}>سائق</Text>
              </View>
            </View>
            <View style={styles.profileInfo}>
              <Text style={styles.profileName}>{user?.name ?? 'السائق'}</Text>
              <Text style={styles.profilePhone}>{user?.phone}</Text>
              <View style={[styles.approvalBadge, { backgroundColor: approval.color + '18' }]}>
                <Text style={[styles.approvalText, { color: approval.color }]}>{approval.label}</Text>
              </View>
            </View>
          </View>

          {/* Stats */}
          <View style={styles.statsRow}>
            {[
              { label: 'التقييم', value: (stats?.avgRating ?? 5).toFixed(1), icon: '⭐' },
              { label: 'الرحلات', value: String(stats?.totalRides ?? 0), icon: '🚗' },
              { label: 'الأرباح', value: `${(stats?.totalEarnings ?? 0).toFixed(0)} ج`, icon: '💰' },
            ].map((s, i) => (
              <React.Fragment key={i}>
                {i > 0 ? <View style={styles.statDivider} /> : null}
                <View style={styles.statItem}>
                  <Text style={styles.statIcon}>{s.icon}</Text>
                  <Text style={styles.statValue}>{s.value}</Text>
                  <Text style={styles.statLabel}>{s.label}</Text>
                </View>
              </React.Fragment>
            ))}
          </View>
        </LinearGradient>

        {/* Vehicle info */}
        {driverProfile ? (
          <View style={styles.vehicleCard}>
            <View style={styles.vehicleLeft}>
              <Text style={styles.vehicleIcon}>{VEHICLE_ICONS[driverProfile.vehicle_type]}</Text>
            </View>
            <View style={styles.vehicleInfo}>
              <Text style={styles.vehicleModel}>{driverProfile.vehicle_model}</Text>
              <Text style={styles.vehiclePlate}>لوحة: {driverProfile.vehicle_plate}</Text>
              <Text style={styles.vehicleColor}>اللون: {driverProfile.vehicle_color}</Text>
            </View>
          </View>
        ) : null}

        {/* Settings */}
        {[
          {
            title: 'الإعدادات',
            items: [
              { id: 'notif', icon: 'notifications', label: 'الإشعارات', type: 'toggle' },
              { id: 'theme', icon: 'palette', label: isDark ? 'الوضع الليلي' : 'الوضع النهاري', type: 'theme' },
              { id: 'docs', icon: 'description', label: 'مستنداتي', type: 'link' },
            ],
          },
          {
            title: 'المساعدة',
            items: [
              { id: 'support', icon: 'headset-mic', label: 'الدعم الفني', type: 'link' },
              { id: 'complaint', icon: 'report-problem', label: 'إرسال شكوى', type: 'link' },
            ],
          },
          {
            title: 'الإدارة',
            items: [
              { id: 'admin', icon: 'admin-panel-settings', label: 'لوحة التحكم', type: 'link' },
            ],
          },
          {
            title: '',
            items: [
              { id: 'logout', icon: 'logout', label: 'تسجيل الخروج', type: 'danger' },
            ],
          },
        ].map((group, gi) => (
          <View key={gi} style={styles.settingsGroup}>
            {group.title ? <Text style={styles.groupTitle}>{group.title}</Text> : null}
            <View style={styles.groupItems}>
              {group.items.map((item, ii) => (
                <TouchableOpacity
                  key={item.id}
                  style={[
                    styles.settingItem,
                    ii < group.items.length - 1 && styles.settingItemBorder,
                    item.type === 'danger' && styles.settingItemDanger,
                  ]}
                  activeOpacity={item.type === 'theme' ? 1 : 0.7}
                  onPress={() => {
                    if (item.id === 'logout') handleLogout();
                    if (item.id === 'admin') router.push('/admin/index');
                    if (item.id === 'complaint') router.push('/complaints/new');
                    if (item.id === 'notif') setNotifications(!notifications);
                  }}
                >
                  <View style={styles.itemLeft}>
                    {item.type === 'theme' ? <ThemeToggle /> :
                     item.type === 'toggle' ? (
                       <Switch
                         value={notifications}
                         onValueChange={setNotifications}
                         trackColor={{ false: Colors.border, true: Colors.primaryFaded }}
                         thumbColor={notifications ? Colors.primary : Colors.textTertiary}
                       />
                     ) : (
                       <MaterialIcons
                         name="chevron-left"
                         size={18}
                         color={item.type === 'danger' ? Colors.error + '80' : Colors.textTertiary}
                       />
                     )}
                  </View>
                  <View style={styles.itemRight}>
                    <Text style={[styles.itemLabel, item.type === 'danger' && { color: Colors.error }]}>
                      {item.label}
                    </Text>
                    <View style={[
                      styles.itemIconBg,
                      item.type === 'danger' && { backgroundColor: Colors.errorFaded },
                    ]}>
                      <MaterialIcons
                        name={item.icon as any}
                        size={18}
                        color={item.type === 'danger' ? Colors.error : Colors.primary}
                      />
                    </View>
                  </View>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        ))}

        <Text style={styles.version}>وصّلني · وضع السائق v1.0</Text>
        <View style={{ height: 20 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  profileHeader: {
    padding: Spacing.base, paddingBottom: Spacing.xl,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  avatarSection: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.base, marginBottom: Spacing.lg,
  },
  avatarWrapper: { position: 'relative' },
  avatar: {
    width: 70, height: 70, borderRadius: 35,
    borderWidth: 2.5, borderColor: Colors.primary, ...Shadow.glow,
  },
  driverBadge: {
    position: 'absolute', bottom: -4, alignSelf: 'center',
    backgroundColor: Colors.primary, borderRadius: Radius.full,
    paddingHorizontal: 6, paddingVertical: 2,
    borderWidth: 1.5, borderColor: Colors.background,
  },
  driverBadgeText: { color: Colors.textInverse, fontSize: 9, fontWeight: Fonts.bold as any },
  profileInfo: { flex: 1, alignItems: 'flex-end', gap: 4 },
  profileName: { fontSize: 18, fontWeight: Fonts.bold as any, color: Colors.text },
  profilePhone: { fontSize: 13, color: Colors.textSecondary },
  approvalBadge: { borderRadius: Radius.full, paddingHorizontal: 10, paddingVertical: 3 },
  approvalText: { fontSize: 12, fontWeight: Fonts.semibold as any },
  statsRow: {
    flexDirection: 'row-reverse', backgroundColor: Colors.card, borderRadius: Radius.lg,
    padding: Spacing.md, borderWidth: 1, borderColor: Colors.border,
  },
  statItem: { flex: 1, alignItems: 'center', gap: 3 },
  statDivider: { width: 1, backgroundColor: Colors.border, marginVertical: 4 },
  statIcon: { fontSize: 16 },
  statValue: { fontSize: 16, fontWeight: Fonts.bold as any, color: Colors.text },
  statLabel: { fontSize: 11, color: Colors.textSecondary },
  vehicleCard: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.md,
    margin: Spacing.base, backgroundColor: Colors.card, borderRadius: Radius.lg,
    padding: Spacing.base, borderWidth: 1, borderColor: Colors.border,
  },
  vehicleLeft: {
    width: 52, height: 52, borderRadius: Radius.md, backgroundColor: Colors.surface,
    justifyContent: 'center', alignItems: 'center',
  },
  vehicleIcon: { fontSize: 28 },
  vehicleInfo: { flex: 1, alignItems: 'flex-end', gap: 3 },
  vehicleModel: { fontSize: 15, fontWeight: Fonts.bold as any, color: Colors.text },
  vehiclePlate: { fontSize: 13, color: Colors.textSecondary },
  vehicleColor: { fontSize: 12, color: Colors.textTertiary },
  settingsGroup: { paddingHorizontal: Spacing.base, marginTop: Spacing.md },
  groupTitle: {
    fontSize: 12, color: Colors.textTertiary, fontWeight: Fonts.semibold as any,
    textAlign: 'right', marginBottom: Spacing.sm, textTransform: 'uppercase',
  },
  groupItems: {
    backgroundColor: Colors.card, borderRadius: Radius.lg,
    borderWidth: 1, borderColor: Colors.border, overflow: 'hidden',
  },
  settingItem: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between',
    padding: Spacing.base,
  },
  settingItemBorder: { borderBottomWidth: 1, borderBottomColor: Colors.border },
  settingItemDanger: { backgroundColor: Colors.errorFaded },
  itemRight: { flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.md },
  itemLeft: {},
  itemIconBg: {
    width: 36, height: 36, borderRadius: Radius.sm,
    backgroundColor: Colors.primaryFaded, justifyContent: 'center', alignItems: 'center',
  },
  itemLabel: { fontSize: 15, color: Colors.text, fontWeight: Fonts.medium as any },
  version: { textAlign: 'center', color: Colors.textTertiary, fontSize: 12, marginTop: Spacing.lg },
});
