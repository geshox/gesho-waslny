// Powered by OnSpace.AI
import React, { useEffect, useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, FlatList,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Spacing, Radius, Fonts, Shadow } from '@/constants/theme';
import { useAuth } from '@/hooks/useAuth';
import { useDriver } from '@/hooks/useDriver';
import { getDriverRides } from '@/services/rideService';

type Period = 'today' | 'week' | 'month' | 'all';

export default function DriverEarnings() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { stats, driverProfile, refreshStats } = useDriver();
  const [period, setPeriod] = useState<Period>('week');
  const [rides, setRides] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (driverProfile?.id) loadRides();
  }, [driverProfile?.id]);

  useEffect(() => {
    refreshStats();
  }, []);

  const loadRides = async () => {
    if (!driverProfile?.id) return;
    setIsLoading(true);
    const data = await getDriverRides(driverProfile.id);
    setRides(data);
    setIsLoading(false);
  };

  const earningsMap: Record<Period, { value: number; label: string }> = {
    today: { value: stats?.todayEarnings ?? 0, label: 'اليوم' },
    week: { value: stats?.weekEarnings ?? 0, label: 'هذا الأسبوع' },
    month: { value: stats?.weekEarnings ? stats.weekEarnings * 4 : 0, label: 'هذا الشهر' },
    all: { value: stats?.totalEarnings ?? 0, label: 'إجمالي' },
  };

  const barData = [
    { label: 'أح', value: Math.random() * 200 },
    { label: 'إث', value: Math.random() * 300 },
    { label: 'ثل', value: Math.random() * 250 },
    { label: 'أر', value: Math.random() * 350 },
    { label: 'خم', value: Math.random() * 280 },
    { label: 'جم', value: Math.random() * 400 },
    { label: 'سب', value: Math.random() * 320 },
  ];

  const maxBar = Math.max(...barData.map(d => d.value), 1);

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>سجل الأرباح</Text>
        <TouchableOpacity style={styles.refreshBtn} onPress={refreshStats}>
          <MaterialIcons name="refresh" size={20} color={Colors.textSecondary} />
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Main earnings card */}
        <LinearGradient
          colors={['#0D2B1E', '#0F2818', Colors.background]}
          style={styles.earningsHero}
          start={{ x: 0, y: 0 }}
          end={{ x: 0, y: 1 }}
        >
          <Text style={styles.earningsLabel}>{earningsMap[period].label}</Text>
          <Text style={styles.earningsValue}>
            {earningsMap[period].value.toFixed(0)}
            <Text style={styles.earningsCurrency}> ج.م</Text>
          </Text>
          <Text style={styles.earningsSub}>
            {period === 'today' ? `${stats?.todayRides ?? 0} رحلة` :
             period === 'week' ? `${stats?.weekRides ?? 0} رحلة` :
             `${stats?.totalRides ?? 0} رحلة إجمالاً`}
          </Text>

          {/* Period selector */}
          <View style={styles.periodRow}>
            {(['today', 'week', 'month', 'all'] as Period[]).map(p => (
              <TouchableOpacity
                key={p}
                style={[styles.periodBtn, period === p && styles.periodBtnActive]}
                onPress={() => setPeriod(p)}
              >
                <Text style={[styles.periodText, period === p && styles.periodTextActive]}>
                  {p === 'today' ? 'اليوم' : p === 'week' ? 'الأسبوع' : p === 'month' ? 'الشهر' : 'الكل'}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </LinearGradient>

        {/* Stats summary */}
        <View style={styles.summaryRow}>
          {[
            { label: 'متوسط الرحلة', value: `${stats?.totalRides ? ((stats.totalEarnings ?? 0) / stats.totalRides).toFixed(0) : 0} ج.م`, icon: 'trending-up', color: Colors.success },
            { label: 'التقييم', value: (stats?.avgRating ?? 5).toFixed(1), icon: 'star', color: Colors.gold },
            { label: 'إجمالي الرحلات', value: String(stats?.totalRides ?? 0), icon: 'directions-car', color: Colors.accent },
          ].map((item, i) => (
            <View key={i} style={styles.summaryCard}>
              <MaterialIcons name={item.icon as any} size={18} color={item.color} />
              <Text style={[styles.summaryValue, { color: item.color }]}>{item.value}</Text>
              <Text style={styles.summaryLabel}>{item.label}</Text>
            </View>
          ))}
        </View>

        {/* Bar chart (visual) */}
        <View style={styles.chartSection}>
          <Text style={styles.sectionTitle}>أرباح آخر 7 أيام</Text>
          <View style={styles.barChart}>
            {barData.map((bar, i) => (
              <View key={i} style={styles.barItem}>
                <View style={styles.barTrack}>
                  <LinearGradient
                    colors={[Colors.primary, Colors.primaryDark]}
                    style={[styles.bar, { height: `${(bar.value / maxBar) * 100}%` as any }]}
                  />
                </View>
                <Text style={styles.barLabel}>{bar.label}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Recent rides */}
        <View style={styles.ridesSection}>
          <Text style={styles.sectionTitle}>آخر الرحلات</Text>
          {rides.length === 0 ? (
            <View style={styles.emptyRides}>
              <MaterialIcons name="history" size={40} color={Colors.textTertiary} />
              <Text style={styles.emptyText}>لا توجد رحلات بعد</Text>
            </View>
          ) : (
            rides.slice(0, 10).map((ride, i) => (
              <View key={i} style={styles.rideItem}>
                <Text style={styles.ridePrice}>{ride.price} ج.م</Text>
                <View style={styles.rideInfo}>
                  <Text style={styles.rideRoute} numberOfLines={1}>
                    {ride.from_address} ← {ride.to_address}
                  </Text>
                  <Text style={styles.rideDate}>
                    {new Date(ride.created_at).toLocaleDateString('ar-EG')}
                  </Text>
                </View>
                <View style={[
                  styles.rideStatus,
                  { backgroundColor: ride.status === 'completed' ? Colors.successFaded : Colors.errorFaded }
                ]}>
                  <Text style={[
                    styles.rideStatusText,
                    { color: ride.status === 'completed' ? Colors.success : Colors.error }
                  ]}>
                    {ride.status === 'completed' ? 'مكتملة' : 'ملغاة'}
                  </Text>
                </View>
              </View>
            ))
          )}
        </View>

        <View style={{ height: 24 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.base, paddingVertical: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  headerTitle: { fontSize: 18, fontWeight: Fonts.bold as any, color: Colors.text },
  refreshBtn: { padding: 8 },
  earningsHero: {
    padding: Spacing.xl, paddingBottom: Spacing.xxl,
    borderBottomWidth: 1, borderBottomColor: Colors.border, alignItems: 'center', gap: 8,
  },
  earningsLabel: { fontSize: 14, color: Colors.textSecondary },
  earningsValue: { fontSize: 48, fontWeight: Fonts.extrabold as any, color: Colors.primary },
  earningsCurrency: { fontSize: 20, fontWeight: Fonts.medium as any, color: Colors.textSecondary },
  earningsSub: { fontSize: 14, color: Colors.textSecondary, marginBottom: Spacing.md },
  periodRow: { flexDirection: 'row-reverse', gap: Spacing.sm, flexWrap: 'wrap', justifyContent: 'center' },
  periodBtn: {
    paddingHorizontal: 16, paddingVertical: 8, borderRadius: Radius.full,
    backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border,
  },
  periodBtnActive: { backgroundColor: Colors.primaryFaded, borderColor: Colors.primary },
  periodText: { fontSize: 13, color: Colors.textSecondary, fontWeight: Fonts.medium as any },
  periodTextActive: { color: Colors.primary, fontWeight: Fonts.semibold as any },
  summaryRow: {
    flexDirection: 'row-reverse', padding: Spacing.base, gap: Spacing.sm,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  summaryCard: {
    flex: 1, backgroundColor: Colors.card, borderRadius: Radius.md, padding: Spacing.md,
    alignItems: 'center', gap: 5, borderWidth: 1, borderColor: Colors.border,
  },
  summaryValue: { fontSize: 16, fontWeight: Fonts.bold as any },
  summaryLabel: { fontSize: 11, color: Colors.textTertiary, textAlign: 'center' },
  chartSection: { padding: Spacing.base, paddingBottom: 0 },
  sectionTitle: {
    fontSize: 16, fontWeight: Fonts.bold as any, color: Colors.text,
    textAlign: 'right', marginBottom: Spacing.md,
  },
  barChart: {
    flexDirection: 'row-reverse', alignItems: 'flex-end', gap: 6,
    backgroundColor: Colors.card, borderRadius: Radius.lg, padding: Spacing.md,
    height: 140, borderWidth: 1, borderColor: Colors.border, marginBottom: Spacing.lg,
  },
  barItem: { flex: 1, alignItems: 'center', height: '100%', gap: 4 },
  barTrack: {
    flex: 1, width: '80%', backgroundColor: Colors.border, borderRadius: 4,
    justifyContent: 'flex-end', overflow: 'hidden',
  },
  bar: { width: '100%', borderRadius: 4, minHeight: 4 },
  barLabel: { fontSize: 10, color: Colors.textTertiary },
  ridesSection: { padding: Spacing.base },
  emptyRides: { alignItems: 'center', gap: 8, paddingVertical: Spacing.xl },
  emptyText: { fontSize: 15, color: Colors.textTertiary },
  rideItem: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.md,
    backgroundColor: Colors.card, borderRadius: Radius.md, padding: Spacing.md,
    borderWidth: 1, borderColor: Colors.border, marginBottom: Spacing.sm,
  },
  rideInfo: { flex: 1, alignItems: 'flex-end', gap: 3 },
  rideRoute: { fontSize: 13, color: Colors.text, fontWeight: Fonts.medium as any, textAlign: 'right' },
  rideDate: { fontSize: 11, color: Colors.textTertiary },
  ridePrice: { fontSize: 16, fontWeight: Fonts.extrabold as any, color: Colors.primary, minWidth: 70, textAlign: 'center' },
  rideStatus: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: Radius.full },
  rideStatusText: { fontSize: 11, fontWeight: Fonts.medium as any },
});
