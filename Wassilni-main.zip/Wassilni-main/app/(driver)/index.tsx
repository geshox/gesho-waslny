// Powered by OnSpace.AI
import React, { useEffect, useRef, useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Switch, Animated, Platform,
} from 'react-native';
import { Image } from 'expo-image';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Spacing, Radius, Fonts, Shadow } from '@/constants/theme';
import { useAuth } from '@/hooks/useAuth';
import { useDriver } from '@/hooks/useDriver';

const VEHICLE_ICONS: Record<string, string> = {
  car: '🚗', tuk: '🛺', moto: '🏍️', microbus: '🚐',
};

export default function DriverDashboard() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { user } = useAuth();
  const { driverProfile, isOnline, stats, toggleOnline, loadDriver, refreshStats } = useDriver();
  const pulseAnim = useRef(new Animated.Value(1)).current;

  // Online pulse animation
  useEffect(() => {
    if (isOnline) {
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, { toValue: 1.3, duration: 800, useNativeDriver: true }),
          Animated.timing(pulseAnim, { toValue: 1, duration: 800, useNativeDriver: true }),
        ])
      ).start();
    } else {
      pulseAnim.setValue(1);
    }
  }, [isOnline]);

  useEffect(() => {
    if (user?.id) loadDriver(user.id);
  }, [user?.id]);

  const handleToggleOnline = async () => {
    await toggleOnline();
    await refreshStats();
  };

  const statItems = [
    { label: 'أرباح اليوم', value: `${stats?.todayEarnings?.toFixed(0) ?? 0} ج.م`, icon: 'attach-money', color: Colors.primary },
    { label: 'رحلات اليوم', value: String(stats?.todayRides ?? 0), icon: 'directions-car', color: Colors.accent },
    { label: 'متوسط التقييم', value: (stats?.avgRating ?? 5.0).toFixed(1), icon: 'star', color: Colors.gold },
    { label: 'إجمالي الرحلات', value: String(stats?.totalRides ?? 0), icon: 'history', color: Colors.textSecondary },
  ];

  const weekItems = [
    { label: 'أرباح الأسبوع', value: `${stats?.weekEarnings?.toFixed(0) ?? 0} ج.م`, icon: 'trending-up', color: Colors.success },
    { label: 'رحلات الأسبوع', value: String(stats?.weekRides ?? 0), icon: 'timeline', color: Colors.accent },
    { label: 'إجمالي الأرباح', value: `${stats?.totalEarnings?.toFixed(0) ?? 0} ج.م`, icon: 'account-balance', color: Colors.primary },
    { label: 'ساعات العمل', value: `${stats?.hoursOnline ?? 0} س`, icon: 'schedule', color: Colors.warning },
  ];

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      <LinearGradient
        colors={['#0D2B1E', Colors.background]}
        style={styles.header}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
      >
        <View style={styles.headerRow}>
          <TouchableOpacity style={styles.notifBtn} onPress={() => router.push('/notifications')}>
            <MaterialIcons name="notifications" size={22} color={Colors.text} />
          </TouchableOpacity>

          <View style={styles.headerInfo}>
            <Text style={styles.headerGreeting}>أهلاً، {user?.name?.split(' ')[0] ?? 'سائق'} 👋</Text>
            <View style={[styles.statusPill, { backgroundColor: isOnline ? Colors.successFaded : Colors.errorFaded }]}>
              <Animated.View style={[
                styles.statusDot,
                { backgroundColor: isOnline ? Colors.success : Colors.error },
                isOnline && { transform: [{ scale: pulseAnim }] },
              ]} />
              <Text style={[styles.statusText, { color: isOnline ? Colors.success : Colors.error }]}>
                {isOnline ? 'متاح للعمل' : 'غير متاح'}
              </Text>
            </View>
          </View>

          <View style={styles.avatarWrap}>
            <Image
              source={{ uri: user?.avatar }}
              style={styles.avatar}
              contentFit="cover"
            />
            {isOnline ? <View style={styles.onlineDot} /> : null}
          </View>
        </View>

        {/* Online toggle */}
        <View style={[styles.toggleCard, { borderColor: isOnline ? Colors.primary + '40' : Colors.error + '30' }]}>
          <Switch
            value={isOnline}
            onValueChange={handleToggleOnline}
            trackColor={{ false: Colors.error + '40', true: Colors.primaryFaded }}
            thumbColor={isOnline ? Colors.primary : Colors.error}
            style={{ transform: [{ scale: 1.15 }] }}
          />
          <View style={styles.toggleInfo}>
            {isOnline ? (
              <Text style={styles.toggleDesc}>أنت متاح الآن لاستقبال طلبات الرحلات</Text>
            ) : (
              <Text style={styles.toggleDescOff}>فعّل الخدمة لاستقبال طلبات الرحلات</Text>
            )}
            <Text style={[styles.toggleTitle, { color: isOnline ? Colors.primary : Colors.error }]}>
              {isOnline ? '🟢 تشغيل الخدمة' : '🔴 إيقاف الخدمة'}
            </Text>
          </View>
        </View>
      </LinearGradient>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        {/* Vehicle info */}
        {driverProfile ? (
          <View style={styles.vehicleCard}>
            <View style={styles.vehicleRight}>
              <Text style={styles.vehicleModel}>{driverProfile.vehicle_model}</Text>
              <Text style={styles.vehiclePlate}>
                {VEHICLE_ICONS[driverProfile.vehicle_type]} لوحة: {driverProfile.vehicle_plate}
              </Text>
            </View>
            <View style={[styles.vehicleIconBg, {
              backgroundColor:
                driverProfile.approval_status === 'approved' ? Colors.successFaded : Colors.warningFaded,
            }]}>
              <Text style={{ fontSize: 28 }}>{VEHICLE_ICONS[driverProfile.vehicle_type]}</Text>
            </View>
            {driverProfile.approval_status !== 'approved' ? (
              <View style={styles.pendingBadge}>
                <MaterialIcons name="pending" size={12} color={Colors.warning} />
                <Text style={styles.pendingText}>قيد المراجعة</Text>
              </View>
            ) : null}
          </View>
        ) : (
          <TouchableOpacity
            style={styles.registerDriverCard}
            onPress={() => router.push('/auth/driver-register')}
          >
            <MaterialIcons name="drive-eta" size={28} color={Colors.accent} />
            <Text style={styles.registerDriverText}>أكمل تسجيل بيانات المركبة للبدء</Text>
            <MaterialIcons name="chevron-left" size={20} color={Colors.accent} />
          </TouchableOpacity>
        )}

        {/* Today stats */}
        <Text style={styles.sectionTitle}>إحصائيات اليوم</Text>
        <View style={styles.statsGrid}>
          {statItems.map((item, i) => (
            <View key={i} style={styles.statCard}>
              <View style={[styles.statIconBg, { backgroundColor: item.color + '18' }]}>
                <MaterialIcons name={item.icon as any} size={20} color={item.color} />
              </View>
              <Text style={[styles.statValue, { color: item.color }]}>{item.value}</Text>
              <Text style={styles.statLabel}>{item.label}</Text>
            </View>
          ))}
        </View>

        {/* Weekly stats */}
        <Text style={styles.sectionTitle}>ملخص الأسبوع</Text>
        <View style={styles.statsGrid}>
          {weekItems.map((item, i) => (
            <View key={i} style={styles.statCard}>
              <View style={[styles.statIconBg, { backgroundColor: item.color + '18' }]}>
                <MaterialIcons name={item.icon as any} size={20} color={item.color} />
              </View>
              <Text style={[styles.statValue, { color: item.color }]}>{item.value}</Text>
              <Text style={styles.statLabel}>{item.label}</Text>
            </View>
          ))}
        </View>

        {/* Quick actions */}
        <Text style={styles.sectionTitle}>إجراءات سريعة</Text>
        <View style={styles.actionsRow}>
          {[
            { label: 'الطلبات الواردة', icon: 'notifications-active', route: '/(driver)/requests', color: Colors.primary },
            { label: 'سجل الأرباح', icon: 'account-balance-wallet', route: '/(driver)/earnings', color: Colors.gold },
            { label: 'إرسال شكوى', icon: 'report-problem', route: '/complaints/new', color: Colors.error },
            { label: 'الدعم الفني', icon: 'headset-mic', route: null, color: Colors.accent },
          ].map((action, i) => (
            <TouchableOpacity
              key={i}
              style={styles.actionCard}
              onPress={() => action.route ? router.push(action.route as any) : null}
            >
              <View style={[styles.actionIconBg, { backgroundColor: action.color + '18' }]}>
                <MaterialIcons name={action.icon as any} size={22} color={action.color} />
              </View>
              <Text style={styles.actionLabel}>{action.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={{ height: 24 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: { padding: Spacing.base, paddingBottom: Spacing.xl, borderBottomWidth: 1, borderBottomColor: Colors.border },
  headerRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.md, marginBottom: Spacing.md },
  notifBtn: {
    width: 40, height: 40, borderRadius: 20, backgroundColor: Colors.card,
    justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: Colors.border,
  },
  headerInfo: { flex: 1, alignItems: 'flex-end', gap: 4 },
  headerGreeting: { fontSize: 18, fontWeight: Fonts.bold as any, color: Colors.text },
  statusPill: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: 5,
    paddingHorizontal: 10, paddingVertical: 4, borderRadius: Radius.full,
  },
  statusDot: { width: 8, height: 8, borderRadius: 4 },
  statusText: { fontSize: 12, fontWeight: Fonts.medium as any },
  avatarWrap: { position: 'relative' },
  avatar: { width: 48, height: 48, borderRadius: 24, borderWidth: 2, borderColor: Colors.primary },
  onlineDot: {
    position: 'absolute', bottom: 0, right: 0, width: 14, height: 14,
    borderRadius: 7, backgroundColor: Colors.success, borderWidth: 2, borderColor: Colors.background,
  },
  toggleCard: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.md,
    backgroundColor: Colors.card, borderRadius: Radius.lg, padding: Spacing.md,
    borderWidth: 1,
  },
  toggleInfo: { flex: 1, alignItems: 'flex-end', gap: 2 },
  toggleTitle: { fontSize: 15, fontWeight: Fonts.bold as any },
  toggleDesc: { fontSize: 12, color: Colors.textSecondary, textAlign: 'right' },
  toggleDescOff: { fontSize: 12, color: Colors.textTertiary, textAlign: 'right' },
  content: { padding: Spacing.base },
  vehicleCard: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.md,
    backgroundColor: Colors.card, borderRadius: Radius.lg, padding: Spacing.base,
    borderWidth: 1, borderColor: Colors.border, marginBottom: Spacing.lg,
  },
  vehicleRight: { flex: 1, alignItems: 'flex-end', gap: 4 },
  vehicleModel: { fontSize: 16, fontWeight: Fonts.bold as any, color: Colors.text },
  vehiclePlate: { fontSize: 13, color: Colors.textSecondary },
  vehicleIconBg: {
    width: 52, height: 52, borderRadius: Radius.md, justifyContent: 'center', alignItems: 'center',
  },
  pendingBadge: {
    position: 'absolute', top: -6, left: -6,
    flexDirection: 'row-reverse', alignItems: 'center', gap: 3,
    backgroundColor: Colors.warningFaded, borderRadius: Radius.full,
    paddingHorizontal: 8, paddingVertical: 3, borderWidth: 1, borderColor: Colors.warning + '30',
  },
  pendingText: { fontSize: 10, color: Colors.warning, fontWeight: Fonts.medium as any },
  registerDriverCard: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.md,
    backgroundColor: Colors.accentFaded, borderRadius: Radius.lg, padding: Spacing.base,
    borderWidth: 1, borderColor: Colors.accent + '40', marginBottom: Spacing.lg,
  },
  registerDriverText: { flex: 1, textAlign: 'right', color: Colors.accent, fontSize: 14, fontWeight: Fonts.medium as any },
  sectionTitle: {
    fontSize: 16, fontWeight: Fonts.bold as any, color: Colors.text,
    textAlign: 'right', marginBottom: Spacing.md, marginTop: Spacing.sm,
  },
  statsGrid: { flexDirection: 'row-reverse', flexWrap: 'wrap', gap: Spacing.sm, marginBottom: Spacing.lg },
  statCard: {
    width: '47%', backgroundColor: Colors.card, borderRadius: Radius.lg, padding: Spacing.md,
    alignItems: 'flex-end', gap: 6, borderWidth: 1, borderColor: Colors.border,
  },
  statIconBg: { width: 40, height: 40, borderRadius: Radius.md, justifyContent: 'center', alignItems: 'center' },
  statValue: { fontSize: 20, fontWeight: Fonts.extrabold as any },
  statLabel: { fontSize: 12, color: Colors.textSecondary, textAlign: 'right' },
  actionsRow: { flexDirection: 'row-reverse', flexWrap: 'wrap', gap: Spacing.sm },
  actionCard: {
    width: '47%', backgroundColor: Colors.card, borderRadius: Radius.lg, padding: Spacing.md,
    alignItems: 'center', gap: 8, borderWidth: 1, borderColor: Colors.border,
  },
  actionIconBg: { width: 48, height: 48, borderRadius: Radius.md, justifyContent: 'center', alignItems: 'center' },
  actionLabel: { fontSize: 13, color: Colors.text, fontWeight: Fonts.medium as any, textAlign: 'center' },
});
