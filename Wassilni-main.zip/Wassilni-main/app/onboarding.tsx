// Powered by OnSpace.AI
import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
  Animated,
  ScrollView,
  NativeSyntheticEvent,
  NativeScrollEvent,
  Platform,
} from 'react-native';
import { Image } from 'expo-image';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Spacing, Radius, Shadow, Fonts } from '@/constants/theme';

const { width, height } = Dimensions.get('window');

const BRAND = {
  amber:      Colors.primary,
  amberDark:  Colors.primaryDark,
  amberLight: Colors.primaryLight,
  bg:         Colors.background,
  card:       Colors.card,
  text:       Colors.text,
  textSub:    Colors.textSecondary,
  textMuted:  Colors.textTertiary,
  border:     Colors.border,
  green:      Colors.success,
};

interface Slide {
  id: number;
  emoji: string;
  title: string;
  subtitle: string;
  description: string;
  features: { icon: string; label: string }[];
  accentColor: string;
  bgGradient: [string, string, string];
}

const SLIDES: Slide[] = [
  {
    id: 1,
    emoji: '🛺',
    title: 'تك توكي',
    subtitle: 'تنقّل بسهولة وأمان',
    description: 'اعثر على أقرب سائق متاح في منطقتك، واحجز رحلتك في ثوانٍ معدودة.',
    features: [
      { icon: 'flash-on', label: 'حجز فوري' },
      { icon: 'location-on', label: 'موقعك الجغرافي دقيق' },
      { icon: 'verified', label: 'سائقون موثّقون' },
    ],
    accentColor: Colors.primary,
    bgGradient: ['#1A0E00', '#120A00', Colors.background],
  },
  {
    id: 2,
    emoji: '📍',
    title: 'تتبّع رحلتك لحظةً بلحظة',
    subtitle: 'خريطة تفاعلية حية',
    description: 'ابقَ على اطلاع دائم بموقع سائقك وموعد وصوله الدقيق أثناء الرحلة.',
    features: [
      { icon: 'gps-fixed', label: 'تتبع الموقع الجغرافي' },
      { icon: 'access-time', label: 'وقت وصول دقيق' },
      { icon: 'map', label: 'خريطة مباشرة' },
    ],
    accentColor: '#3B82F6',
    bgGradient: ['#001A30', '#000E1C', Colors.background],
  },
  {
    id: 3,
    emoji: '💳',
    title: 'ادفع بالطريقة التي تناسبك',
    subtitle: 'وسائل دفع متعددة',
    description: 'نقداً، InstaPay، Vodafone Cash، أو محفظتك الإلكترونية — الخيار بيدك.',
    features: [
      { icon: 'account-balance-wallet', label: 'محفظة إلكترونية' },
      { icon: 'attach-money', label: 'دفع نقدي' },
      { icon: 'credit-card', label: 'بطاقات ومدفوعات رقمية' },
    ],
    accentColor: Colors.emerald,
    bgGradient: ['#001A0A', '#000E05', Colors.background],
  },
];

export default function OnboardingScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const scrollRef = useRef<ScrollView>(null);
  const [currentSlide, setCurrentSlide] = useState(0);

  // Entrance animations
  const fadeAnim   = useRef(new Animated.Value(0)).current;
  const slideAnim  = useRef(new Animated.Value(30)).current;
  const heroScale  = useRef(new Animated.Value(0.9)).current;
  const pulseAnim  = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 700, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0, duration: 600, useNativeDriver: true }),
      Animated.spring(heroScale, { toValue: 1, tension: 60, friction: 8, useNativeDriver: true }),
    ]).start();

    // Pulse the emoji
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.08, duration: 1200, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 1200, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  const handleScroll = (e: NativeSyntheticEvent<NativeScrollEvent>) => {
    const idx = Math.round(e.nativeEvent.contentOffset.x / width);
    setCurrentSlide(idx);
  };

  const goToSlide = (idx: number) => {
    scrollRef.current?.scrollTo({ x: idx * width, animated: true });
    setCurrentSlide(idx);
  };

  const handleNext = () => {
    if (currentSlide < SLIDES.length - 1) {
      goToSlide(currentSlide + 1);
    } else {
      router.replace('/auth/login');
    }
  };

  const handleSkip = () => {
    router.replace('/auth/login');
  };

  const activeSlide = SLIDES[currentSlide];

  return (
    <View style={styles.root}>
      {/* Hero image background — first slide only */}
      <Animated.View style={[styles.heroImgWrap, { opacity: fadeAnim, transform: [{ scale: heroScale }] }]}>
        <Image
          source={require('@/assets/images/welcome_hero.jpg')}
          style={styles.heroImg}
          contentFit="cover"
          transition={300}
        />
        <LinearGradient
          colors={['transparent', 'rgba(11,8,4,0.5)', 'rgba(11,8,4,0.88)', Colors.background]}
          style={styles.heroGrad}
          locations={[0, 0.4, 0.7, 1]}
        />
      </Animated.View>

      {/* Skip button */}
      <View style={[styles.skipRow, { paddingTop: insets.top + 12 }]}>
        {currentSlide < SLIDES.length - 1 ? (
          <TouchableOpacity style={styles.skipBtn} onPress={handleSkip}>
            <Text style={styles.skipText}>تخطي</Text>
            <MaterialIcons name="arrow-back" size={14} color={BRAND.textMuted} />
          </TouchableOpacity>
        ) : <View />}
        {/* Live badge */}
        <View style={styles.liveBadge}>
          <View style={styles.liveDot} />
          <Text style={styles.liveBadgeText}>متاح الآن</Text>
        </View>
      </View>

      {/* Horizontal scroll slides */}
      <ScrollView
        ref={scrollRef}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onMomentumScrollEnd={handleScroll}
        scrollEventThrottle={16}
        style={styles.slideScroll}
        contentContainerStyle={{ width: width * SLIDES.length }}
      >
        {SLIDES.map((slide, i) => (
          <Animated.View
            key={slide.id}
            style={[
              styles.slide,
              {
                opacity: i === 0 ? fadeAnim : 1,
                transform: i === 0 ? [{ translateY: slideAnim }] : [],
              },
            ]}
          >
            {/* Slide accent gradient bg (subtle) */}
            <View style={[styles.slideAccentBg, { backgroundColor: slide.accentColor + '06' }]} />

            {/* App name row — always visible on first slide */}
            {i === 0 ? (
              <View style={styles.appNameRow}>
                <Animated.View style={{ transform: [{ scale: pulseAnim }] }}>
                  <LinearGradient
                    colors={[BRAND.amberLight, BRAND.amber, BRAND.amberDark]}
                    style={styles.appNameBadge}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                  >
                    <Text style={styles.appEmoji}>🛺</Text>
                    <Text style={styles.appNameText}>تك توكي</Text>
                  </LinearGradient>
                </Animated.View>
              </View>
            ) : (
              <View style={styles.slideEmojiRow}>
                <View style={[styles.slideEmojiWrap, { borderColor: slide.accentColor + '50', backgroundColor: slide.accentColor + '14' }]}>
                  <Text style={styles.slideEmoji}>{slide.emoji}</Text>
                </View>
              </View>
            )}

            {/* Divider */}
            <View style={styles.dividerRow}>
              <View style={[styles.dividerLine, { backgroundColor: slide.accentColor + '30' }]} />
              <MaterialIcons name="location-on" size={13} color={slide.accentColor} />
              <View style={[styles.dividerLine, { backgroundColor: slide.accentColor + '30' }]} />
            </View>

            {/* Text */}
            <Text style={styles.slideTitle}>{slide.title}</Text>
            <Text style={[styles.slideSubtitle, { color: slide.accentColor }]}>{slide.subtitle}</Text>
            <Text style={styles.slideDesc}>{slide.description}</Text>

            {/* Feature chips */}
            <View style={styles.featuresRow}>
              {slide.features.map((f, fi) => (
                <View key={fi} style={[styles.featureChip, { borderColor: slide.accentColor + '35', backgroundColor: slide.accentColor + '10' }]}>
                  <MaterialIcons name={f.icon as any} size={13} color={slide.accentColor} />
                  <Text style={[styles.featureLabel, { color: slide.accentColor + 'EE' }]}>{f.label}</Text>
                </View>
              ))}
            </View>
          </Animated.View>
        ))}
      </ScrollView>

      {/* Bottom — dots + CTA */}
      <View style={[styles.bottomArea, { paddingBottom: insets.bottom + 24 }]}>
        {/* Dots indicator */}
        <View style={styles.dotsRow}>
          {SLIDES.map((_, i) => (
            <TouchableOpacity key={i} onPress={() => goToSlide(i)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
              <Animated.View
                style={[
                  styles.dot,
                  currentSlide === i
                    ? [styles.dotActive, { backgroundColor: activeSlide.accentColor }]
                    : styles.dotInactive,
                ]}
              />
            </TouchableOpacity>
          ))}
        </View>

        {/* CTA Button */}
        <TouchableOpacity style={styles.ctaBtn} onPress={handleNext} activeOpacity={0.88}>
          <LinearGradient
            colors={[BRAND.amberLight, BRAND.amber, BRAND.amberDark]}
            style={styles.ctaBtnGrad}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
          >
            {currentSlide < SLIDES.length - 1 ? (
              <>
                <MaterialIcons name="arrow-back" size={20} color={BRAND.bg} />
                <Text style={styles.ctaBtnText}>التالي</Text>
              </>
            ) : (
              <>
                <MaterialIcons name="rocket-launch" size={20} color={BRAND.bg} />
                <Text style={styles.ctaBtnText}>ابدأ الآن</Text>
              </>
            )}
          </LinearGradient>
        </TouchableOpacity>

        {/* Terms hint */}
        <Text style={styles.termsHint}>
          بالمتابعة توافق على{' '}
          <Text style={styles.termsLink}>شروط الاستخدام</Text>
          {' '}و{' '}
          <Text style={styles.termsLink}>سياسة الخصوصية</Text>
        </Text>
      </View>
    </View>
  );
}

const HERO_H = height * 0.48;

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: Colors.background,
  },

  // Hero image (behind everything)
  heroImgWrap: {
    position: 'absolute',
    top: 0, left: 0, right: 0,
    height: HERO_H,
  },
  heroImg: {
    width: '100%',
    height: '100%',
  },
  heroGrad: {
    position: 'absolute',
    bottom: 0, left: 0, right: 0,
    height: HERO_H,
  },

  // Top row
  skipRow: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: Spacing.base,
    zIndex: 10,
  },
  skipBtn: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 5,
    backgroundColor: 'rgba(0,0,0,0.3)',
    borderRadius: Radius.full,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  skipText: {
    fontSize: 13,
    color: Colors.textSecondary,
    fontWeight: Fonts.medium as any,
  },
  liveBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: 'rgba(0,0,0,0.45)',
    borderRadius: Radius.full,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  liveDot: {
    width: 7,
    height: 7,
    borderRadius: 3.5,
    backgroundColor: Colors.success,
  },
  liveBadgeText: {
    fontSize: 11,
    color: '#fff',
    fontWeight: Fonts.semibold as any,
  },

  // Slides
  slideScroll: {
    marginTop: HERO_H * 0.5,
    flex: 1,
  },
  slide: {
    width,
    paddingHorizontal: Spacing.xl,
    paddingTop: Spacing.xl,
    alignItems: 'center',
    position: 'relative',
  },
  slideAccentBg: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 0,
  },

  // App name badge (slide 1)
  appNameRow: {
    alignItems: 'center',
    marginBottom: Spacing.md,
  },
  appNameBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 22,
    paddingVertical: 10,
    borderRadius: Radius.lg,
    ...Shadow.glow,
  },
  appEmoji: { fontSize: 24 },
  appNameText: {
    fontSize: 30,
    fontWeight: Fonts.black as any,
    color: Colors.background,
    letterSpacing: -0.5,
  },

  // Slide emoji (slide 2, 3)
  slideEmojiRow: {
    alignItems: 'center',
    marginBottom: Spacing.md,
  },
  slideEmojiWrap: {
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 2,
    justifyContent: 'center',
    alignItems: 'center',
  },
  slideEmoji: { fontSize: 38 },

  // Divider
  dividerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    width: '65%',
    marginBottom: Spacing.lg,
  },
  dividerLine: {
    flex: 1,
    height: 1,
  },

  // Text
  slideTitle: {
    fontSize: 26,
    fontWeight: Fonts.bold as any,
    color: Colors.text,
    textAlign: 'center',
    marginBottom: 6,
  },
  slideSubtitle: {
    fontSize: 15,
    fontWeight: Fonts.semibold as any,
    textAlign: 'center',
    marginBottom: 12,
  },
  slideDesc: {
    fontSize: 14,
    color: Colors.textSecondary,
    textAlign: 'center',
    lineHeight: 22,
    marginBottom: Spacing.lg,
  },

  // Features
  featuresRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    justifyContent: 'center',
  },
  featureChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    borderRadius: Radius.full,
    borderWidth: 1,
    paddingHorizontal: 11,
    paddingVertical: 6,
  },
  featureLabel: {
    fontSize: 12,
    fontWeight: Fonts.medium as any,
  },

  // Bottom
  bottomArea: {
    paddingHorizontal: Spacing.xl,
    alignItems: 'center',
    gap: Spacing.md,
    paddingTop: Spacing.sm,
  },
  dotsRow: {
    flexDirection: 'row',
    gap: 7,
    alignItems: 'center',
  },
  dot: {
    borderRadius: Radius.full,
  },
  dotActive: {
    width: 24,
    height: 8,
    borderRadius: 4,
  },
  dotInactive: {
    width: 8,
    height: 8,
    backgroundColor: Colors.border,
  },
  ctaBtn: {
    width: width - Spacing.xl * 2,
    borderRadius: Radius.lg,
    overflow: 'hidden',
    ...Shadow.glow,
  },
  ctaBtnGrad: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 17,
  },
  ctaBtnText: {
    fontSize: 18,
    fontWeight: Fonts.black as any,
    color: Colors.background,
    letterSpacing: 0.3,
  },
  termsHint: {
    fontSize: 11,
    color: Colors.textTertiary,
    textAlign: 'center',
    lineHeight: 17,
  },
  termsLink: {
    color: Colors.primary,
    fontWeight: Fonts.medium as any,
  },
});
