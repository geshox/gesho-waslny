// Powered by OnSpace.AI
import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Pressable,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Spacing, Radius, Fonts, Shadow } from '@/constants/theme';
import { useNotifications } from '@/hooks/useNotifications';
import { AppNotification, NotificationType } from '@/contexts/NotificationsContext';

const TYPE_CONFIG: Record<NotificationType, { color: string; bg: string; icon: string }> = {
  ride_accepted: { color: Colors.primary, bg: Colors.primaryFaded, icon: 'directions-car' },
  driver_arrived: { color: Colors.accent, bg: Colors.accentFaded, icon: 'location-on' },
  payment: { color: Colors.gold, bg: Colors.goldFaded, icon: 'account-balance-wallet' },
  complaint: { color: Colors.warning, bg: Colors.warningFaded, icon: 'report-problem' },
  system: { color: Colors.textSecondary, bg: Colors.card, icon: 'campaign' },
};

const FILTERS: { key: string; label: string }[] = [
  { key: 'all', label: 'الكل' },
  { key: 'unread', label: 'غير مقروء' },
  { key: 'ride_accepted', label: 'الرحلات' },
  { key: 'payment', label: 'المدفوعات' },
  { key: 'complaint', label: 'الشكاوى' },
];

export default function NotificationsScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { notifications, unreadCount, markAsRead, markAllAsRead, clearAll } = useNotifications();
  const [activeFilter, setActiveFilter] = useState('all');

  const filtered = notifications.filter(n => {
    if (activeFilter === 'all') return true;
    if (activeFilter === 'unread') return !n.isRead;
    return n.type === activeFilter;
  });

  const renderItem = ({ item }: { item: AppNotification }) => {
    const config = TYPE_CONFIG[item.type];
    return (
      <Pressable
        style={[styles.notifCard, !item.isRead && styles.notifCardUnread]}
        onPress={() => markAsRead(item.id)}
      >
        {!item.isRead && <View style={styles.unreadDot} />}
        <View style={[styles.notifIconBg, { backgroundColor: config.bg }]}>
          <Text style={styles.notifEmoji}>{item.icon}</Text>
        </View>
        <View style={styles.notifContent}>
          <View style={styles.notifHeader}>
            <Text style={styles.notifTime}>{item.time}</Text>
            <Text style={[styles.notifTitle, !item.isRead && styles.notifTitleUnread]}>
              {item.title}
            </Text>
          </View>
          <Text style={styles.notifBody} numberOfLines={2}>{item.body}</Text>
        </View>
      </Pressable>
    );
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerActions}>
          {unreadCount > 0 ? (
            <TouchableOpacity onPress={markAllAsRead} style={styles.headerBtn}>
              <MaterialIcons name="done-all" size={18} color={Colors.primary} />
              <Text style={styles.headerBtnText}>قراءة الكل</Text>
            </TouchableOpacity>
          ) : null}
          <TouchableOpacity onPress={clearAll} style={styles.headerBtn}>
            <MaterialIcons name="delete-sweep" size={18} color={Colors.error} />
          </TouchableOpacity>
        </View>

        <View style={styles.headerLeft}>
          {unreadCount > 0 ? (
            <View style={styles.unreadBadge}>
              <Text style={styles.unreadBadgeText}>{unreadCount}</Text>
            </View>
          ) : null}
          <Text style={styles.headerTitle}>الإشعارات</Text>
        </View>

        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
          <MaterialIcons name="arrow-forward" size={24} color={Colors.text} />
        </TouchableOpacity>
      </View>

      {/* Filters */}
      <View style={styles.filtersOuter}>
        <FlatList
          data={FILTERS}
          horizontal
          showsHorizontalScrollIndicator={false}
          keyExtractor={i => i.key}
          contentContainerStyle={styles.filtersScroll}
          renderItem={({ item: f }) => (
            <TouchableOpacity
              style={[styles.filterChip, activeFilter === f.key && styles.filterChipActive]}
              onPress={() => setActiveFilter(f.key)}
            >
              <Text style={[styles.filterChipText, activeFilter === f.key && styles.filterChipTextActive]}>
                {f.label}
              </Text>
            </TouchableOpacity>
          )}
        />
      </View>

      {/* List */}
      <FlatList
        data={filtered}
        keyExtractor={item => item.id}
        renderItem={renderItem}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <LinearGradient
              colors={[Colors.primaryFaded, Colors.accentFaded]}
              style={styles.emptyIcon}
            >
              <MaterialIcons name="notifications-none" size={40} color={Colors.primary} />
            </LinearGradient>
            <Text style={styles.emptyTitle}>لا توجد إشعارات</Text>
            <Text style={styles.emptySubtitle}>ستظهر هنا جميع تحديثات رحلاتك ومدفوعاتك</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  backBtn: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.card,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  headerLeft: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: Fonts.bold as any,
    color: Colors.text,
  },
  unreadBadge: {
    backgroundColor: Colors.error,
    borderRadius: 12,
    minWidth: 22,
    height: 22,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 6,
  },
  unreadBadgeText: {
    color: Colors.text,
    fontSize: 12,
    fontWeight: Fonts.bold as any,
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  headerBtn: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 6,
    borderRadius: Radius.sm,
    backgroundColor: Colors.card,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  headerBtnText: {
    fontSize: 12,
    color: Colors.primary,
    fontWeight: Fonts.medium as any,
  },
  filtersOuter: {
    height: 50,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  filtersScroll: {
    paddingHorizontal: Spacing.base,
    alignItems: 'center',
    gap: Spacing.sm,
    height: 50,
  },
  filterChip: {
    paddingHorizontal: 14,
    paddingVertical: 7,
    borderRadius: Radius.full,
    borderWidth: 1,
    borderColor: Colors.border,
    backgroundColor: Colors.card,
  },
  filterChipActive: {
    backgroundColor: Colors.primaryFaded,
    borderColor: Colors.primary,
  },
  filterChipText: {
    fontSize: 13,
    color: Colors.textSecondary,
    fontWeight: Fonts.medium as any,
  },
  filterChipTextActive: {
    color: Colors.primary,
    fontWeight: Fonts.semibold as any,
  },
  listContent: {
    padding: Spacing.base,
    paddingBottom: Spacing.xxxl,
  },
  separator: {
    height: Spacing.sm,
  },
  notifCard: {
    flexDirection: 'row-reverse',
    alignItems: 'flex-start',
    gap: Spacing.md,
    backgroundColor: Colors.card,
    borderRadius: Radius.lg,
    padding: Spacing.base,
    borderWidth: 1,
    borderColor: Colors.border,
    position: 'relative',
    overflow: 'hidden',
  },
  notifCardUnread: {
    borderColor: Colors.primary + '40',
    backgroundColor: Colors.primaryFaded,
  },
  unreadDot: {
    position: 'absolute',
    top: 16,
    left: 16,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.primary,
  },
  notifIconBg: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    flexShrink: 0,
  },
  notifEmoji: {
    fontSize: 22,
  },
  notifContent: {
    flex: 1,
    gap: 5,
    alignItems: 'flex-end',
  },
  notifHeader: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
  },
  notifTitle: {
    fontSize: 14,
    fontWeight: Fonts.semibold as any,
    color: Colors.textSecondary,
    textAlign: 'right',
    flex: 1,
  },
  notifTitleUnread: {
    color: Colors.text,
    fontWeight: Fonts.bold as any,
  },
  notifTime: {
    fontSize: 11,
    color: Colors.textTertiary,
    flexShrink: 0,
    marginLeft: Spacing.sm,
  },
  notifBody: {
    fontSize: 13,
    color: Colors.textSecondary,
    lineHeight: 20,
    textAlign: 'right',
  },
  emptyState: {
    alignItems: 'center',
    paddingTop: 80,
    gap: Spacing.lg,
  },
  emptyIcon: {
    width: 88,
    height: 88,
    borderRadius: 44,
    justifyContent: 'center',
    alignItems: 'center',
    ...Shadow.glow,
    marginBottom: Spacing.sm,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: Fonts.bold as any,
    color: Colors.text,
  },
  emptySubtitle: {
    fontSize: 14,
    color: Colors.textTertiary,
    textAlign: 'center',
    lineHeight: 22,
    paddingHorizontal: Spacing.xl,
  },
});
