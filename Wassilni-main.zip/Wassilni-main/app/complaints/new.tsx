// Powered by OnSpace.AI
import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Spacing, Radius, Fonts, Shadow } from '@/constants/theme';

const COMPLAINT_TYPES = [
  { id: 'behavior', label: 'سلوك السائق', icon: 'person-off', color: Colors.error },
  { id: 'price', label: 'مشكلة في السعر', icon: 'attach-money', color: Colors.warning },
  { id: 'route', label: 'مسار خاطئ', icon: 'map', color: Colors.accent },
  { id: 'safety', label: 'مخاوف أمنية', icon: 'security', color: Colors.error },
  { id: 'vehicle', label: 'حالة المركبة', icon: 'car-repair', color: Colors.gold },
  { id: 'other', label: 'أخرى', icon: 'more-horiz', color: Colors.textSecondary },
];

export default function NewComplaintScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [selectedType, setSelectedType] = useState('');
  const [description, setDescription] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = () => {
    if (!selectedType) {
      if (Platform.OS !== 'web') Alert.alert('خطأ', 'يرجى اختيار نوع الشكوى');
      return;
    }
    if (description.trim().length < 10) {
      if (Platform.OS !== 'web') Alert.alert('خطأ', 'يرجى كتابة وصف تفصيلي للشكوى');
      return;
    }
    setSubmitted(true);
    setTimeout(() => router.back(), 2500);
  };

  if (submitted) {
    return (
      <View style={[styles.container, styles.successContainer, { paddingTop: insets.top }]}>
        <View style={styles.successIcon}>
          <LinearGradient colors={[Colors.primary, Colors.primaryDark]} style={styles.successGradientIcon}>
            <MaterialIcons name="check" size={40} color={Colors.textInverse} />
          </LinearGradient>
        </View>
        <Text style={styles.successTitle}>تم إرسال شكواك</Text>
        <Text style={styles.successSub}>
          سيقوم فريقنا بمراجعة شكواك والتواصل معك خلال 24 ساعة
        </Text>
      </View>
    );
  }

  return (
    <View style={[styles.container, { paddingTop: insets.top, paddingBottom: insets.bottom }]}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.closeButton}
          onPress={() => router.back()}
        >
          <MaterialIcons name="close" size={22} color={Colors.text} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>إرسال شكوى</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        {/* Info Banner */}
        <View style={styles.infoBanner}>
          <MaterialIcons name="info" size={18} color={Colors.accent} />
          <Text style={styles.infoText}>
            تحظى جميع الشكاوى بمراجعة دقيقة. عند تجاوز السائق 3 شكاوى مؤكدة، يتم إيقاف حسابه تلقائياً.
          </Text>
        </View>

        {/* Complaint Type */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>نوع الشكوى</Text>
          <View style={styles.typesGrid}>
            {COMPLAINT_TYPES.map(type => (
              <TouchableOpacity
                key={type.id}
                style={[
                  styles.typeCard,
                  selectedType === type.id && styles.typeCardSelected,
                  selectedType === type.id && { borderColor: type.color },
                ]}
                onPress={() => setSelectedType(type.id)}
                activeOpacity={0.8}
              >
                <MaterialIcons
                  name={type.icon as any}
                  size={22}
                  color={selectedType === type.id ? type.color : Colors.textSecondary}
                />
                <Text style={[
                  styles.typeLabel,
                  selectedType === type.id && { color: type.color },
                ]}>
                  {type.label}
                </Text>
                {selectedType === type.id ? (
                  <MaterialIcons name="check-circle" size={14} color={type.color} style={styles.typeCheck} />
                ) : null}
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Description */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>وصف المشكلة</Text>
          <TextInput
            style={styles.descriptionInput}
            value={description}
            onChangeText={setDescription}
            placeholder="اكتب وصفاً تفصيلياً لما حدث..."
            placeholderTextColor={Colors.textTertiary}
            multiline
            numberOfLines={5}
            textAlign="right"
            textAlignVertical="top"
          />
          <Text style={styles.charCount}>{description.length} / 500</Text>
        </View>

        {/* Evidence */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>إرفاق أدلة (اختياري)</Text>
          <TouchableOpacity style={styles.uploadArea}>
            <MaterialIcons name="camera-alt" size={28} color={Colors.textTertiary} />
            <Text style={styles.uploadText}>اضغط لإرفاق صور أو ملفات</Text>
            <Text style={styles.uploadSubtext}>JPEG, PNG, PDF — بحد أقصى 10 ميجابايت</Text>
          </TouchableOpacity>
        </View>

        {/* Submit */}
        <TouchableOpacity
          style={styles.submitButton}
          onPress={handleSubmit}
          activeOpacity={0.85}
        >
          <LinearGradient
            colors={[Colors.primary, Colors.primaryDark]}
            style={styles.submitGradient}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
          >
            <MaterialIcons name="send" size={18} color={Colors.textInverse} />
            <Text style={styles.submitText}>إرسال الشكوى</Text>
          </LinearGradient>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  successContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    padding: Spacing.xxl,
    gap: Spacing.lg,
  },
  successIcon: {
    borderRadius: 50,
    overflow: 'hidden',
    ...Shadow.glow,
    marginBottom: Spacing.md,
  },
  successGradientIcon: {
    width: 88,
    height: 88,
    justifyContent: 'center',
    alignItems: 'center',
  },
  successTitle: {
    fontSize: 26,
    fontWeight: Fonts.bold as any,
    color: Colors.text,
    textAlign: 'center',
  },
  successSub: {
    fontSize: 15,
    color: Colors.textSecondary,
    textAlign: 'center',
    lineHeight: 24,
  },
  header: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  closeButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.card,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: Fonts.bold as any,
    color: Colors.text,
  },
  content: {
    padding: Spacing.base,
    gap: Spacing.xl,
    paddingBottom: Spacing.xxxl,
  },
  infoBanner: {
    flexDirection: 'row-reverse',
    alignItems: 'flex-start',
    gap: Spacing.sm,
    backgroundColor: Colors.accentFaded,
    borderRadius: Radius.md,
    padding: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.accent + '30',
  },
  infoText: {
    flex: 1,
    fontSize: 13,
    color: Colors.accent,
    lineHeight: 20,
    textAlign: 'right',
  },
  section: {
    gap: Spacing.md,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: Fonts.semibold as any,
    color: Colors.text,
    textAlign: 'right',
  },
  typesGrid: {
    flexDirection: 'row-reverse',
    flexWrap: 'wrap',
    gap: Spacing.sm,
  },
  typeCard: {
    width: '31%',
    backgroundColor: Colors.card,
    borderRadius: Radius.md,
    padding: Spacing.sm,
    alignItems: 'center',
    gap: 5,
    borderWidth: 1.5,
    borderColor: Colors.border,
    position: 'relative',
  },
  typeCardSelected: {
    backgroundColor: Colors.primaryFaded,
  },
  typeLabel: {
    fontSize: 11,
    color: Colors.textSecondary,
    textAlign: 'center',
    fontWeight: Fonts.medium as any,
  },
  typeCheck: {
    position: 'absolute',
    top: 5,
    left: 5,
  },
  descriptionInput: {
    backgroundColor: Colors.card,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: Spacing.md,
    color: Colors.text,
    fontSize: 14,
    minHeight: 120,
  },
  charCount: {
    fontSize: 11,
    color: Colors.textTertiary,
    textAlign: 'left',
  },
  uploadArea: {
    backgroundColor: Colors.card,
    borderRadius: Radius.md,
    borderWidth: 1.5,
    borderColor: Colors.border,
    borderStyle: 'dashed',
    padding: Spacing.xl,
    alignItems: 'center',
    gap: Spacing.sm,
  },
  uploadText: {
    fontSize: 14,
    color: Colors.textSecondary,
  },
  uploadSubtext: {
    fontSize: 12,
    color: Colors.textTertiary,
  },
  submitButton: {
    borderRadius: Radius.md,
    overflow: 'hidden',
    ...Shadow.glow,
  },
  submitGradient: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
  },
  submitText: {
    color: Colors.textInverse,
    fontSize: 16,
    fontWeight: Fonts.bold as any,
  },
});
