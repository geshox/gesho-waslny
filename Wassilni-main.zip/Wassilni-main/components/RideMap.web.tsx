// Powered by OnSpace.AI — Web Map Fallback
import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Radius, Shadow, Spacing, Fonts } from '@/constants/theme';
import { Driver, VEHICLE_ICONS } from '@/constants/mockData';

interface RideMapProps {
  drivers: Driver[];
  userLocation: { latitude: number; longitude: number } | null;
  onUserLocation: (coords: { latitude: number; longitude: number }) => void;
  onLocationError: () => void;
  onDriverPress: (driver: Driver) => void;
  insetTop: number;
  vehicleColors: Record<string, string>;
}

// Fixed pin positions for web mock map (percentage of container)
const PIN_POSITIONS = [
  { id: 'd001', x: 38, y: 42 },
  { id: 'd002', x: 58, y: 33 },
  { id: 'd003', x: 25, y: 58 },
  { id: 'd004', x: 48, y: 62 },
  { id: 'd005', x: 68, y: 50 },
];

export default function RideMap({
  drivers,
  onDriverPress,
  vehicleColors,
}: RideMapProps) {
  return (
    <View style={styles.container}>
      {/* Dark road grid background */}
      <View style={styles.mapBg}>
        {/* Horizontal roads */}
        {[20, 38, 55, 72, 88].map(pos => (
          <View key={`h${pos}`} style={[styles.roadH, { top: `${pos}%` as any }]} />
        ))}
        {/* Vertical roads */}
        {[15, 32, 50, 67, 83].map(pos => (
          <View key={`v${pos}`} style={[styles.roadV, { left: `${pos}%` as any }]} />
        ))}

        {/* Wider main roads */}
        <View style={[styles.mainRoadH, { top: '48%' as any }]} />
        <View style={[styles.mainRoadV, { left: '48%' as any }]} />

        {/* City blocks */}
        {[
          { t: '22%', l: '17%', w: '13%', h: '14%' },
          { t: '22%', l: '52%', w: '13%', h: '14%' },
          { t: '58%', l: '17%', w: '13%', h: '12%' },
          { t: '58%', l: '52%', w: '13%', h: '12%' },
          { t: '22%', l: '34%', w: '12%', h: '10%' },
          { t: '40%', l: '20%', w: '10%', h: '6%' },
          { t: '40%', l: '55%', w: '10%', h: '6%' },
        ].map((b, i) => (
          <View key={i} style={[styles.block, { top: b.t as any, left: b.l as any, width: b.w as any, height: b.h as any }]} />
        ))}

        {/* My location pulse */}
        <View style={styles.myLocationOuter}>
          <View style={styles.myLocationPulse} />
          <View style={styles.myLocationDot} />
        </View>

        {/* Driver pins */}
        {drivers.map(driver => {
          const pos = PIN_POSITIONS.find(p => p.id === driver.id);
          if (!pos) return null;
          return (
            <TouchableOpacity
              key={driver.id}
              style={[styles.driverPin, {
                left: `${pos.x}%` as any,
                top: `${pos.y}%` as any,
                borderColor: vehicleColors[driver.vehicleType],
              }]}
              onPress={() => onDriverPress(driver)}
              activeOpacity={0.85}
            >
              <Text style={styles.driverPinIcon}>{VEHICLE_ICONS[driver.vehicleType]}</Text>
            </TouchableOpacity>
          );
        })}

        {/* Map label */}
        <View style={styles.mapLabel}>
          <MaterialIcons name="map" size={12} color={Colors.textTertiary} />
          <Text style={styles.mapLabelText}>خريطة المدينة</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  mapBg: {
    flex: 1,
    backgroundColor: Colors.mapBackground,
    position: 'relative',
    overflow: 'hidden',
  },
  roadH: {
    position: 'absolute',
    left: 0,
    right: 0,
    height: 1.5,
    backgroundColor: Colors.mapRoad,
  },
  roadV: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    width: 1.5,
    backgroundColor: Colors.mapRoad,
  },
  mainRoadH: {
    position: 'absolute',
    left: 0,
    right: 0,
    height: 4,
    backgroundColor: Colors.mapRoad + 'CC',
  },
  mainRoadV: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    width: 4,
    backgroundColor: Colors.mapRoad + 'CC',
  },
  block: {
    position: 'absolute',
    backgroundColor: '#0D1A2D',
    borderRadius: 2,
  },
  myLocationOuter: {
    position: 'absolute',
    left: '47%',
    top: '47%',
    width: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  myLocationPulse: {
    position: 'absolute',
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.accent + '25',
    borderWidth: 1,
    borderColor: Colors.accent + '50',
  },
  myLocationDot: {
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: Colors.accent,
    borderWidth: 2.5,
    borderColor: Colors.background,
  },
  driverPin: {
    position: 'absolute',
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: Colors.surface,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2.5,
    transform: [{ translateX: -19 }, { translateY: -19 }],
    ...Shadow.md,
  },
  driverPinIcon: { fontSize: 17 },
  mapLabel: {
    position: 'absolute',
    bottom: 10,
    right: 10,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(0,0,0,0.5)',
    borderRadius: Radius.sm,
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  mapLabelText: {
    fontSize: 11,
    color: Colors.textTertiary,
  },
});
