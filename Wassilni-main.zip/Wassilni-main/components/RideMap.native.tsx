// Powered by OnSpace.AI — Native Map (react-native-maps)
import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import MapView, { Marker, Circle, PROVIDER_DEFAULT } from 'react-native-maps';
import * as Location from 'expo-location';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Radius, Shadow } from '@/constants/theme';
import { Driver, VEHICLE_ICONS } from '@/constants/mockData';

interface RideMapProps {
  drivers: Driver[];
  userLocation: { latitude: number; longitude: number } | null;
  onUserLocation: (coords: { latitude: number; longitude: number }) => void;
  onLocationError: () => void;
  onDriverPress: (driver: Driver) => void;
  insetTop: number;
  vehicleColors: Record<string, string>;
}

const CAIRO_REGION = {
  latitude: 30.0626,
  longitude: 31.2497,
  latitudeDelta: 0.02,
  longitudeDelta: 0.02,
};

export default function RideMap({
  drivers,
  userLocation,
  onUserLocation,
  onLocationError,
  onDriverPress,
  insetTop,
  vehicleColors,
}: RideMapProps) {
  const mapRef = useRef<MapView>(null);

  useEffect(() => {
    (async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status !== 'granted') { onLocationError(); return; }
        const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
        const coords = { latitude: loc.coords.latitude, longitude: loc.coords.longitude };
        onUserLocation(coords);
        mapRef.current?.animateToRegion({ ...coords, latitudeDelta: 0.02, longitudeDelta: 0.02 }, 1000);
      } catch {
        onLocationError();
      }
    })();
  }, []);

  return (
    <View style={styles.container}>
      <MapView
        ref={mapRef}
        style={styles.map}
        provider={PROVIDER_DEFAULT}
        initialRegion={CAIRO_REGION}
        showsUserLocation={true}
        showsMyLocationButton={false}
        showsCompass={false}
        mapType="standard"
      >
        {userLocation ? (
          <Circle
            center={userLocation}
            radius={80}
            fillColor={Colors.accent + '20'}
            strokeColor={Colors.accent + '60'}
            strokeWidth={1}
          />
        ) : null}

        {drivers.map(driver => (
          <Marker
            key={driver.id}
            coordinate={{ latitude: driver.lat, longitude: driver.lng }}
            onPress={() => onDriverPress(driver)}
          >
            <View style={[styles.driverMarker, { borderColor: vehicleColors[driver.vehicleType] }]}>
              <Text style={styles.driverMarkerIcon}>{VEHICLE_ICONS[driver.vehicleType]}</Text>
            </View>
          </Marker>
        ))}
      </MapView>

      <TouchableOpacity
        style={[styles.gpsButton, { top: insetTop + 90 }]}
        onPress={() => {
          if (userLocation) {
            mapRef.current?.animateToRegion({ ...userLocation, latitudeDelta: 0.015, longitudeDelta: 0.015 }, 800);
          }
        }}
      >
        <MaterialIcons name="my-location" size={20} color={Colors.primary} />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  map: { flex: 1 },
  driverMarker: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.surface,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2.5,
    ...Shadow.md,
  },
  driverMarkerIcon: { fontSize: 18 },
  gpsButton: {
    position: 'absolute',
    right: 12,
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: Colors.surface,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.border,
    ...Shadow.md,
  },
});
