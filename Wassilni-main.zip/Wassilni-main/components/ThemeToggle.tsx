// Powered by OnSpace.AI
import React, { useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { useTheme } from '@/hooks/useTheme';
import { Spacing, Radius, Fonts } from '@/constants/theme';

interface ThemeToggleProps {
  compact?: boolean;
}

export function ThemeToggle({ compact = false }: ThemeToggleProps) {
  const { isDark, toggleTheme, colors } = useTheme();

  const slideAnim = useRef(new Animated.Value(isDark ? 1 : 0)).current;
  const rotateAnim = useRef(new Animated.Value(isDark ? 1 : 0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.spring(slideAnim, { toValue: isDark ? 1 : 0, useNativeDriver: true, tension: 80, friction: 9 }),
      Animated.timing(rotateAnim, { toValue: isDark ? 1 : 0, duration: 300, useNativeDriver: true }),
    ]).start();
  }, [isDark]);

  const translateX = slideAnim.interpolate({ inputRange: [0, 1], outputRange: [0, 30] });
  const rotate = rotateAnim.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });

  if (compact) {
    return (
      <TouchableOpacity onPress={toggleTheme} style={[compactStyles.btn, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <MaterialIcons
          name={isDark ? 'dark-mode' : 'light-mode'}
          size={20}
          color={isDark ? '#818CF8' : '#F59E0B'}
        />
      </TouchableOpacity>
    );
  }

  return (
    <TouchableOpacity
      onPress={toggleTheme}
      activeOpacity={0.85}
      style={[styles.toggleWrapper, {
        backgroundColor: isDark ? '#1A2035' : '#E8F4FD',
        borderColor: isDark ? '#2A3550' : '#D1E8FA',
      }]}
    >
      {/* Track icons */}
      <View style={styles.iconsRow}>
        <MaterialIcons name="light-mode" size={16} color={isDark ? '#3D4F6A' : '#F59E0B'} />
        <MaterialIcons name="dark-mode" size={16} color={isDark ? '#818CF8' : '#A0B0C8'} />
      </View>

      {/* Thumb */}
      <Animated.View style={[styles.thumb, { transform: [{ translateX }, { rotate }] }]}>
        <LinearGradient
          colors={isDark ? ['#6366F1', '#4F46E5'] : ['#F59E0B', '#D97706']}
          style={styles.thumbGradient}
        >
          <MaterialIcons
            name={isDark ? 'nights-stay' : 'wb-sunny'}
            size={14}
            color="#fff"
          />
        </LinearGradient>
      </Animated.View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  toggleWrapper: {
    width: 68,
    height: 34,
    borderRadius: 17,
    borderWidth: 1,
    justifyContent: 'center',
    paddingHorizontal: 4,
    position: 'relative',
  },
  iconsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 4,
    position: 'absolute',
    left: 0,
    right: 0,
  },
  thumb: {
    width: 28,
    height: 28,
    borderRadius: 14,
    overflow: 'hidden',
    shadowColor: '#6366F1',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 6,
    elevation: 4,
  },
  thumbGradient: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

const compactStyles = StyleSheet.create({
  btn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
  },
});
