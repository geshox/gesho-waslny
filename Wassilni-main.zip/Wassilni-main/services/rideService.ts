// Powered by OnSpace.AI
import { supabase } from '@/lib/supabase';
import { Database } from '@/lib/supabase';

type RideRow = Database['public']['Tables']['rides']['Row'];
type RideInsert = Database['public']['Tables']['rides']['Insert'];
type RideUpdate = Database['public']['Tables']['rides']['Update'];

export type { RideRow, RideInsert, RideUpdate };

export type RideStatus = RideRow['status'];

/**
 * Create a new ride request
 */
export async function createRide(
  data: RideInsert
): Promise<{ ride: RideRow | null; error: string | null }> {
  const { data: ride, error } = await supabase
    .from('rides')
    .insert(data)
    .select()
    .single();

  if (error) return { ride: null, error: error.message };
  return { ride: ride as RideRow, error: null };
}

/**
 * Update ride status and optional fields
 */
export async function updateRide(
  rideId: string,
  updates: RideUpdate
): Promise<{ error: string | null }> {
  const { error } = await supabase.from('rides').update(updates).eq('id', rideId);
  return { error: error?.message ?? null };
}

/**
 * Get ride by ID
 */
export async function getRide(rideId: string): Promise<RideRow | null> {
  const { data } = await supabase.from('rides').select('*').eq('id', rideId).single();
  return (data as RideRow) ?? null;
}

/**
 * Ride row with the accepting driver's profile embedded via FK joins
 */
export interface RideWithDriver extends RideRow {
  driver: {
    id: string;
    user: {
      full_name: string | null;
      avatar_url: string | null;
    } | null;
  } | null;
}

/**
 * Get passenger ride history (with driver name/avatar)
 */
export async function getPassengerRides(passengerId: string): Promise<RideWithDriver[]> {
  const { data } = await supabase
    .from('rides')
    .select(`
      *,
      driver:drivers(
        id,
        user:users(
          full_name,
          avatar_url
        )
      )
    `)
    .eq('passenger_id', passengerId)
    .order('created_at', { ascending: false });
  return (data as unknown as RideWithDriver[]) ?? [];
}

/**
 * Get driver ride history
 */
export async function getDriverRides(driverId: string): Promise<RideRow[]> {
  const { data } = await supabase
    .from('rides')
    .select('*')
    .eq('driver_id', driverId)
    .order('created_at', { ascending: false });
  return (data as RideRow[]) ?? [];
}

/**
 * Submit passenger rating
 */
export async function rateRide(
  rideId: string,
  rating: number,
  review: string,
  raterRole: 'passenger' | 'driver'
): Promise<{ error: string | null }> {
  const update =
    raterRole === 'passenger'
      ? { passenger_rating: rating, passenger_review: review }
      : { driver_rating: rating, driver_review: review };

  const { error } = await supabase.from('rides').update(update).eq('id', rideId);
  return { error: error?.message ?? null };
}

/**
 * Driver marks arrival at pickup point
 */
export async function driverArrived(rideId: string): Promise<{ error: string | null }> {
  const { error } = await supabase
    .from('rides')
    .update({ status: 'arriving' })
    .eq('id', rideId);
  return { error: error?.message ?? null };
}

/**
 * Driver starts the trip
 */
export async function startTrip(rideId: string): Promise<{ error: string | null }> {
  const { error } = await supabase
    .from('rides')
    .update({ status: 'in_progress', started_at: new Date().toISOString() })
    .eq('id', rideId);
  return { error: error?.message ?? null };
}

/**
 * Driver completes the trip
 */
export async function completeTrip(rideId: string): Promise<{ error: string | null }> {
  const { error } = await supabase
    .from('rides')
    .update({ status: 'completed', completed_at: new Date().toISOString() })
    .eq('id', rideId);
  return { error: error?.message ?? null };
}

/**
 * Get rides assigned to a driver with an active status
 */
export async function getDriverActiveRides(driverId: string): Promise<RideRow[]> {
  const { data } = await supabase
    .from('rides')
    .select('*')
    .eq('driver_id', driverId)
    .in('status', ['accepted', 'arriving', 'in_progress'])
    .order('created_at', { ascending: false });
  return (data as RideRow[]) ?? [];
}

/**
 * Subscribe to real-time ride updates
 */
export function subscribeToRide(
  rideId: string,
  callback: (ride: RideRow) => void
) {
  return supabase
    .channel(`ride:${rideId}`)
    .on(
      'postgres_changes',
      { event: 'UPDATE', schema: 'public', table: 'rides', filter: `id=eq.${rideId}` },
      (payload) => callback(payload.new as RideRow)
    )
    .subscribe();
}

/**
 * Subscribe to new ride requests (for drivers)
 */
export function subscribeToNewRides(
  vehicleType: string,
  callback: (ride: RideRow) => void
) {
  return supabase
    .channel('new_rides')
    .on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'rides',
        filter: `vehicle_type=eq.${vehicleType}`,
      },
      (payload) => callback(payload.new as RideRow)
    )
    .subscribe();
}
