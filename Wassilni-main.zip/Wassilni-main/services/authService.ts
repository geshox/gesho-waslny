// Powered by OnSpace.AI
import { supabase } from '@/lib/supabase';

export interface UserProfile {
  id: string;
  phone: string;
  full_name: string | null;
  avatar_url: string | null;
  rating: number;
  total_rides: number;
  wallet_balance: number;
  role: 'passenger' | 'driver' | 'admin';
  is_verified: boolean;
  is_active: boolean;
  created_at: string;
}

/**
 * Step 1 — send OTP to phone number via Supabase Auth
 */
export async function sendPhoneOTP(phone: string): Promise<{ error: string | null }> {
  const { error } = await supabase.auth.signInWithOtp({ phone });
  if (error) return { error: error.message };
  return { error: null };
}

/**
 * Step 2 — verify OTP token
 */
export async function verifyPhoneOTP(
  phone: string,
  token: string
): Promise<{ userId: string | null; error: string | null }> {
  const { data, error } = await supabase.auth.verifyOtp({
    phone,
    token,
    type: 'sms',
  });

  if (error || !data.user) return { userId: null, error: error?.message ?? 'فشل التحقق' };
  return { userId: data.user.id, error: null };
}

/**
 * Fetch or create user profile after successful OTP
 */
export async function getOrCreateProfile(
  userId: string,
  phone: string
): Promise<{ profile: UserProfile | null; error: string | null }> {
  // try fetch first
  const { data: existing, error: fetchErr } = await supabase
    .from('users')
    .select('*')
    .eq('id', userId)
    .single();

  if (existing) return { profile: existing as UserProfile, error: null };

  // create new profile
  const { data: created, error: createErr } = await supabase
    .from('users')
    .insert({
      id: userId,
      phone,
      role: 'passenger',
      wallet_balance: 0,
      rating: 5.0,
      total_rides: 0,
      is_verified: false,
      is_active: true,
    })
    .select()
    .single();

  if (createErr) return { profile: null, error: createErr.message };
  return { profile: created as UserProfile, error: null };
}

/**
 * Fetch the current session's user profile
 */
export async function fetchProfile(userId: string): Promise<UserProfile | null> {
  const { data } = await supabase.from('users').select('*').eq('id', userId).single();
  return (data as UserProfile) ?? null;
}

/**
 * Update user profile fields
 */
export async function updateProfile(
  userId: string,
  updates: { full_name?: string; avatar_url?: string }
): Promise<{ error: string | null }> {
  const { error } = await supabase.from('users').update(updates).eq('id', userId);
  return { error: error?.message ?? null };
}

/**
 * Update wallet balance
 */
export async function updateWalletBalance(
  userId: string,
  newBalance: number
): Promise<{ error: string | null }> {
  const { error } = await supabase
    .from('users')
    .update({ wallet_balance: newBalance })
    .eq('id', userId);
  return { error: error?.message ?? null };
}

/**
 * Sign out
 */
export async function signOut(): Promise<void> {
  await supabase.auth.signOut();
}
