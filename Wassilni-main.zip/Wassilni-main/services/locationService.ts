// Powered by OnSpace.AI
import * as Location from 'expo-location';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import { Platform } from 'react-native';

export interface DriverLocation {
  lat: number;
  lng: number;
  heading?: number;
  speed?: number;
  timestamp: number;
}

let locationSubscription: Location.LocationSubscription | null = null;
let broadcastInterval: ReturnType<typeof setInterval> | null = null;

/**
 * Request location permissions
 */
export async function requestLocationPermission(): Promise<boolean> {
  if (Platform.OS === 'web') return false;
  const { status } = await Location.requestForegroundPermissionsAsync();
  return status === 'granted';
}

/**
 * Get current location once
 */
export async function getCurrentLocation(): Promise<DriverLocation | null> {
  try {
    if (Platform.OS === 'web') {
      return { lat: 30.0444, lng: 31.2357, timestamp: Date.now() };
    }
    const location = await Location.getCurrentPositionAsync({
      accuracy: Location.Accuracy.High,
    });
    return {
      lat: location.coords.latitude,
      lng: location.coords.longitude,
      heading: location.coords.heading ?? undefined,
      speed: location.coords.speed ?? undefined,
      timestamp: location.timestamp,
    };
  } catch {
    return null;
  }
}

/**
 * Start watching driver location and broadcasting to Supabase Realtime
 * Updates every 5 seconds (or when position changes significantly)
 */
export async function startDriverLocationTracking(
  driverId: string,
  onLocationUpdate?: (loc: DriverLocation) => void
): Promise<void> {
  stopDriverLocationTracking(); // Clear any existing subscription

  if (Platform.OS === 'web') {
    // Web fallback: simulate location drift for demo
    broadcastInterval = setInterval(async () => {
      const mockLoc: DriverLocation = {
        lat: 30.0444 + (Math.random() - 0.5) * 0.002,
        lng: 31.2357 + (Math.random() - 0.5) * 0.002,
        timestamp: Date.now(),
      };
      onLocationUpdate?.(mockLoc);
      await broadcastLocation(driverId, mockLoc);
    }, 5000);
    return;
  }

  const hasPermission = await requestLocationPermission();
  if (!hasPermission) return;

  // Watch position with 5-second minimum interval
  locationSubscription = await Location.watchPositionAsync(
    {
      accuracy: Location.Accuracy.High,
      timeInterval: 5000,        // Update every 5 seconds
      distanceInterval: 10,      // Or every 10 meters
    },
    async (location) => {
      const loc: DriverLocation = {
        lat: location.coords.latitude,
        lng: location.coords.longitude,
        heading: location.coords.heading ?? undefined,
        speed: location.coords.speed ?? undefined,
        timestamp: location.timestamp,
      };
      onLocationUpdate?.(loc);
      await broadcastLocation(driverId, loc);
    }
  );
}

/**
 * Stop tracking driver location
 */
export function stopDriverLocationTracking(): void {
  if (locationSubscription) {
    locationSubscription.remove();
    locationSubscription = null;
  }
  if (broadcastInterval) {
    clearInterval(broadcastInterval);
    broadcastInterval = null;
  }
}

/**
 * Broadcast driver location to Supabase (DB + Realtime channel)
 */
async function broadcastLocation(
  driverId: string,
  loc: DriverLocation
): Promise<void> {
  if (!isSupabaseConfigured) return;

  // Update the drivers table (for persistence)
  await supabase
    .from('drivers')
    .update({
      current_lat: loc.lat,
      current_lng: loc.lng,
    })
    .eq('id', driverId);

  // Also broadcast via Realtime channel for instant passenger updates
  await supabase.channel(`driver_location:${driverId}`).send({
    type: 'broadcast',
    event: 'location_update',
    payload: {
      driver_id: driverId,
      lat: loc.lat,
      lng: loc.lng,
      heading: loc.heading,
      timestamp: loc.timestamp,
    },
  });
}

/**
 * Subscribe to driver location updates (for passenger's map screen)
 */
export function subscribeToDriverLocation(
  driverId: string,
  callback: (loc: DriverLocation) => void
) {
  return supabase
    .channel(`driver_location:${driverId}`)
    .on('broadcast', { event: 'location_update' }, (payload) => {
      callback({
        lat: payload.payload.lat,
        lng: payload.payload.lng,
        heading: payload.payload.heading,
        timestamp: payload.payload.timestamp,
      });
    })
    .subscribe();
}

/**
 * Also subscribe via postgres_changes as fallback
 */
export function subscribeToDriverLocationDB(
  driverId: string,
  callback: (lat: number, lng: number) => void
) {
  return supabase
    .channel(`driver_db_location:${driverId}`)
    .on(
      'postgres_changes',
      {
        event: 'UPDATE',
        schema: 'public',
        table: 'drivers',
        filter: `id=eq.${driverId}`,
      },
      (payload) => {
        const { current_lat, current_lng } = payload.new as any;
        if (current_lat && current_lng) callback(current_lat, current_lng);
      }
    )
    .subscribe();
}
