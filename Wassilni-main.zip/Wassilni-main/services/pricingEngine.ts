// Powered by OnSpace.AI
// Dynamic Pricing Engine — fully configurable without code changes

export type VehicleType = 'car' | 'tuk' | 'moto' | 'microbus';
export type ZoneType = 'city' | 'village' | 'intercity';
export type CurrencyCode = 'EGP' | 'SAR' | 'AED' | 'USD';

// ──────────────────────────────────────────────
// Currency Configuration
// ──────────────────────────────────────────────

export interface CurrencyConfig {
  code: CurrencyCode;
  symbol: string;
  name: string;
  roundingStep: number;   // e.g. 0.5 for 50 piasters
  fractionDigits: number;
}

export const CURRENCY_CONFIGS: Record<CurrencyCode, CurrencyConfig> = {
  EGP: {
    code: 'EGP',
    symbol: 'ج.م',
    name: 'الجنيه المصري',
    roundingStep: 0.5,      // rounds to nearest 50 piasters
    fractionDigits: 1,
  },
  SAR: {
    code: 'SAR',
    symbol: 'ر.س',
    name: 'الريال السعودي',
    roundingStep: 0.25,
    fractionDigits: 2,
  },
  AED: {
    code: 'AED',
    symbol: 'د.إ',
    name: 'الدرهم الإماراتي',
    roundingStep: 0.25,
    fractionDigits: 2,
  },
  USD: {
    code: 'USD',
    symbol: '$',
    name: 'الدولار الأمريكي',
    roundingStep: 0.01,
    fractionDigits: 2,
  },
};

// ──────────────────────────────────────────────
// Pricing Rules (replaces hardcoded values — load from DB in production)
// ──────────────────────────────────────────────

export interface VehiclePricingRule {
  vehicleType: VehicleType;
  baseFare: number;        // flat starting amount
  perKmRate: number;       // per kilometre
  perMinuteRate: number;   // per minute of travel
  minimumFare: number;     // floor price
  longDistanceThresholdKm: number;  // above this = long-distance rate
  longDistancePerKmRate: number;    // cheaper/different rate for long routes
}

export interface ZoneMultiplier {
  zone: ZoneType;
  label: string;
  multiplier: number;
}

export interface PeakHourRule {
  label: string;
  days: number[];           // 0=Sunday … 6=Saturday
  startHour: number;        // 0-23
  endHour: number;          // 0-23
  multiplier: number;
}

export interface PricingConfig {
  currency: CurrencyCode;
  vehicleRules: Record<VehicleType, VehiclePricingRule>;
  zoneMultipliers: ZoneMultiplier[];
  peakHours: PeakHourRule[];
  surgeActive: boolean;
  surgeMultiplier: number;
  nightSurchargeMultiplier: number;  // 22:00 – 06:00
}

// ─── Default config (mirrors what admin can edit in DB) ──────────────────────
export const DEFAULT_PRICING_CONFIG: PricingConfig = {
  currency: 'EGP',
  vehicleRules: {
    car: {
      vehicleType: 'car',
      baseFare: 8,
      perKmRate: 2.5,
      perMinuteRate: 0.5,
      minimumFare: 15,
      longDistanceThresholdKm: 30,
      longDistancePerKmRate: 2.0,
    },
    tuk: {
      vehicleType: 'tuk',
      baseFare: 4,
      perKmRate: 1.5,
      perMinuteRate: 0.3,
      minimumFare: 8,
      longDistanceThresholdKm: 10,
      longDistancePerKmRate: 1.2,
    },
    moto: {
      vehicleType: 'moto',
      baseFare: 3,
      perKmRate: 1.2,
      perMinuteRate: 0.25,
      minimumFare: 6,
      longDistanceThresholdKm: 15,
      longDistancePerKmRate: 1.0,
    },
    microbus: {
      vehicleType: 'microbus',
      baseFare: 5,
      perKmRate: 0.8,
      perMinuteRate: 0.2,
      minimumFare: 5,
      longDistanceThresholdKm: 50,
      longDistancePerKmRate: 0.6,
    },
  },
  zoneMultipliers: [
    { zone: 'city',      label: 'داخل المدينة',       multiplier: 1.0 },
    { zone: 'village',   label: 'القرى والريف',        multiplier: 0.8 },
    { zone: 'intercity', label: 'بين المدن',           multiplier: 1.3 },
  ],
  peakHours: [
    {
      label: 'ذروة الصباح',
      days: [0, 1, 2, 3, 4], // Sunday–Thursday
      startHour: 7,
      endHour: 9,
      multiplier: 1.3,
    },
    {
      label: 'ذروة المساء',
      days: [0, 1, 2, 3, 4],
      startHour: 17,
      endHour: 20,
      multiplier: 1.4,
    },
    {
      label: 'عطلة نهاية الأسبوع',
      days: [5, 6], // Friday–Saturday
      startHour: 14,
      endHour: 23,
      multiplier: 1.2,
    },
  ],
  surgeActive: false,
  surgeMultiplier: 1.5,
  nightSurchargeMultiplier: 1.2,
};

// ──────────────────────────────────────────────
// Core Calculation
// ──────────────────────────────────────────────

export interface PriceInput {
  vehicleType: VehicleType;
  distanceKm: number;
  durationMinutes: number;
  zone: ZoneType;
  departureTime?: Date;   // defaults to now
}

export interface PriceBreakdown {
  baseFare: number;
  distanceFare: number;
  timeFare: number;
  subtotal: number;
  zoneMultiplier: number;
  peakMultiplier: number;
  surgeMultiplier: number;
  nightMultiplier: number;
  totalMultiplier: number;
  rawTotal: number;
  roundedTotal: number;
  minimumApplied: boolean;
  currencySymbol: string;
  currencyCode: CurrencyCode;
  appliedPeakLabel: string | null;
  isLongDistance: boolean;
  formattedPrice: string;
}

/**
 * Rounds a number to the nearest `step`.
 * e.g. roundToStep(14.3, 0.5) → 14.5
 */
export function roundToStep(value: number, step: number): number {
  return Math.round(value / step) * step;
}

/**
 * Checks whether a given datetime falls within any peak-hour window.
 */
function getActivePeakRule(
  peakRules: PeakHourRule[],
  at: Date
): PeakHourRule | null {
  const day = at.getDay();
  const hour = at.getHours();

  for (const rule of peakRules) {
    if (rule.days.includes(day) && hour >= rule.startHour && hour < rule.endHour) {
      return rule;
    }
  }
  return null;
}

/**
 * Returns true if the departure time falls in the night-surcharge window
 * (22:00 – 05:59).
 */
function isNightTime(at: Date): boolean {
  const h = at.getHours();
  return h >= 22 || h < 6;
}

/**
 * Main pricing function.
 * Pass a custom `config` to override defaults (loaded from DB at runtime).
 */
export function calculateFare(
  input: PriceInput,
  config: PricingConfig = DEFAULT_PRICING_CONFIG
): PriceBreakdown {
  const { vehicleType, distanceKm, durationMinutes, zone, departureTime } = input;
  const at = departureTime ?? new Date();
  const currency = CURRENCY_CONFIGS[config.currency];
  const rule = config.vehicleRules[vehicleType];

  // ── Distance fare (with long-distance split) ──────────────────────
  const isLongDistance = distanceKm > rule.longDistanceThresholdKm;
  let distanceFare: number;

  if (isLongDistance) {
    const shortPortion = rule.longDistanceThresholdKm * rule.perKmRate;
    const longPortion = (distanceKm - rule.longDistanceThresholdKm) * rule.longDistancePerKmRate;
    distanceFare = shortPortion + longPortion;
  } else {
    distanceFare = distanceKm * rule.perKmRate;
  }

  // ── Time fare ─────────────────────────────────────────────────────
  const timeFare = durationMinutes * rule.perMinuteRate;

  // ── Subtotal ──────────────────────────────────────────────────────
  const subtotal = rule.baseFare + distanceFare + timeFare;

  // ── Zone multiplier ───────────────────────────────────────────────
  const zoneConfig = config.zoneMultipliers.find(z => z.zone === zone);
  const zoneMultiplier = zoneConfig?.multiplier ?? 1.0;

  // ── Peak-hour multiplier ──────────────────────────────────────────
  const activePeak = getActivePeakRule(config.peakHours, at);
  const peakMultiplier = activePeak?.multiplier ?? 1.0;

  // ── Night surcharge ───────────────────────────────────────────────
  const nightMultiplier = isNightTime(at) ? config.nightSurchargeMultiplier : 1.0;

  // ── Surge (admin-controlled) ──────────────────────────────────────
  const surgeMultiplier = config.surgeActive ? config.surgeMultiplier : 1.0;

  // ── Combined multiplier (peak and night don't stack — take max) ───
  const combinedDynamicMultiplier = Math.max(peakMultiplier, nightMultiplier);
  const totalMultiplier = zoneMultiplier * combinedDynamicMultiplier * surgeMultiplier;

  // ── Raw total ─────────────────────────────────────────────────────
  const rawTotal = subtotal * totalMultiplier;

  // ── Minimum fare ──────────────────────────────────────────────────
  const minimumApplied = rawTotal < rule.minimumFare;
  const preRoundTotal = minimumApplied ? rule.minimumFare : rawTotal;

  // ── Rounding to local denomination ───────────────────────────────
  const roundedTotal = roundToStep(preRoundTotal, currency.roundingStep);

  // ── Formatted string ──────────────────────────────────────────────
  const formattedPrice = `${roundedTotal.toFixed(currency.fractionDigits)} ${currency.symbol}`;

  return {
    baseFare: rule.baseFare,
    distanceFare: parseFloat(distanceFare.toFixed(2)),
    timeFare: parseFloat(timeFare.toFixed(2)),
    subtotal: parseFloat(subtotal.toFixed(2)),
    zoneMultiplier,
    peakMultiplier,
    surgeMultiplier,
    nightMultiplier,
    totalMultiplier: parseFloat(totalMultiplier.toFixed(4)),
    rawTotal: parseFloat(rawTotal.toFixed(2)),
    roundedTotal,
    minimumApplied,
    currencySymbol: currency.symbol,
    currencyCode: config.currency,
    appliedPeakLabel: activePeak?.label ?? null,
    isLongDistance,
    formattedPrice,
  };
}

/**
 * Quick helper — returns only the formatted price string.
 */
export function estimateFare(
  vehicleType: VehicleType,
  distanceKm: number,
  zone: ZoneType = 'city',
  durationMinutes?: number,
  config?: PricingConfig
): string {
  const avgSpeed = vehicleType === 'moto' ? 25 : vehicleType === 'microbus' ? 40 : 30; // km/h
  const estimatedMinutes = durationMinutes ?? (distanceKm / avgSpeed) * 60;

  const result = calculateFare(
    { vehicleType, distanceKm, durationMinutes: estimatedMinutes, zone },
    config
  );
  return result.formattedPrice;
}

/**
 * Returns a human-readable breakdown summary (Arabic).
 */
export function formatBreakdown(b: PriceBreakdown): string[] {
  const lines: string[] = [];
  const cs = b.currencySymbol;

  lines.push(`أجرة الأساس: ${b.baseFare.toFixed(1)} ${cs}`);
  lines.push(`المسافة: ${b.distanceFare.toFixed(1)} ${cs}`);
  lines.push(`الوقت: ${b.timeFare.toFixed(1)} ${cs}`);

  if (b.zoneMultiplier !== 1)
    lines.push(`معامل المنطقة: ×${b.zoneMultiplier}`);

  if (b.appliedPeakLabel)
    lines.push(`${b.appliedPeakLabel}: ×${b.peakMultiplier}`);

  if (b.nightMultiplier > 1 && !b.appliedPeakLabel)
    lines.push(`رسوم ليلية: ×${b.nightMultiplier}`);

  if (b.surgeMultiplier > 1)
    lines.push(`⚡ تسعير الذروة: ×${b.surgeMultiplier}`);

  if (b.minimumApplied)
    lines.push(`الحد الأدنى مُطبَّق`);

  if (b.isLongDistance)
    lines.push(`رحلة بعيدة المسافة`);

  return lines;
}
