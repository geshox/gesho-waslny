// Powered by OnSpace.AI
import { supabase, isSupabaseConfigured } from '@/lib/supabase';

export interface AdminUser {
  id: string;
  phone: string;
  full_name: string | null;
  avatar_url: string | null;
  role: 'passenger' | 'driver' | 'admin';
  is_active: boolean;
  is_verified: boolean;
  wallet_balance: number;
  total_rides: number;
  rating: number;
  created_at: string;
}

export interface AdminDriver extends AdminUser {
  driver_id: string;
  vehicle_type: string;
  vehicle_model: string;
  vehicle_plate: string;
  vehicle_color: string;
  approval_status: 'pending' | 'approved' | 'rejected';
  is_online: boolean;
  total_earnings: number;
  current_lat: number | null;
  current_lng: number | null;
  face_photo_url: string | null;
  national_id_url: string | null;
  license_url: string | null;
}

/**
 * Get all passengers
 */
export async function getAllPassengers(): Promise<AdminUser[]> {
  if (!isSupabaseConfigured) return getMockPassengers();

  const { data } = await supabase
    .from('users')
    .select('*')
    .eq('role', 'passenger')
    .order('created_at', { ascending: false });

  return (data as AdminUser[]) ?? getMockPassengers();
}

/**
 * Get all drivers (joined with drivers table)
 */
export async function getAllDrivers(): Promise<AdminDriver[]> {
  if (!isSupabaseConfigured) return getMockDrivers();

  const { data } = await supabase
    .from('drivers')
    .select(`
      id,
      vehicle_type,
      vehicle_model,
      vehicle_plate,
      vehicle_color,
      approval_status,
      is_online,
      total_earnings,
      current_lat,
      current_lng,
      face_photo_url,
      national_id_url,
      license_url,
      users (
        id, phone, full_name, avatar_url, role,
        is_active, is_verified, wallet_balance,
        total_rides, rating, created_at
      )
    `)
    .order('created_at', { ascending: false });

  if (!data) return getMockDrivers();

  return data.map((d: any) => ({
    ...d.users,
    driver_id: d.id,
    vehicle_type: d.vehicle_type,
    vehicle_model: d.vehicle_model,
    vehicle_plate: d.vehicle_plate,
    vehicle_color: d.vehicle_color,
    approval_status: d.approval_status,
    is_online: d.is_online,
    total_earnings: d.total_earnings,
    current_lat: d.current_lat,
    current_lng: d.current_lng,
    face_photo_url: d.face_photo_url,
    national_id_url: d.national_id_url,
    license_url: d.license_url,
  }));
}

/**
 * Toggle user active status
 */
export async function toggleUserStatus(
  userId: string,
  isActive: boolean
): Promise<{ error: string | null }> {
  if (!isSupabaseConfigured) return { error: null };
  const { error } = await supabase
    .from('users')
    .update({ is_active: isActive })
    .eq('id', userId);
  return { error: error?.message ?? null };
}

/**
 * Update driver approval status
 */
export async function updateDriverApproval(
  driverId: string,
  status: 'approved' | 'rejected',
  userId?: string
): Promise<{ error: string | null }> {
  if (!isSupabaseConfigured) return { error: null };

  const { error } = await supabase
    .from('drivers')
    .update({
      approval_status: status,
      is_approved: status === 'approved',
    })
    .eq('id', driverId);

  if (error) return { error: error.message };

  // If approving, also verify the user
  if (status === 'approved' && userId) {
    await supabase
      .from('users')
      .update({ is_verified: true, role: 'driver' })
      .eq('id', userId);
  }

  return { error: null };
}

/**
 * Get admin dashboard stats
 */
export async function getAdminStats(): Promise<{
  totalUsers: number;
  totalDrivers: number;
  pendingDrivers: number;
  totalRides: number;
  completedRides: number;
  totalRevenue: number;
  activeDrivers: number;
}> {
  if (!isSupabaseConfigured) {
    return {
      totalUsers: 1284,
      totalDrivers: 87,
      pendingDrivers: 12,
      totalRides: 5432,
      completedRides: 4980,
      totalRevenue: 148750,
      activeDrivers: 34,
    };
  }

  const [usersResult, driversResult, ridesResult] = await Promise.all([
    supabase.from('users').select('id, role', { count: 'exact' }),
    supabase.from('drivers').select('id, approval_status, is_online', { count: 'exact' }),
    supabase.from('rides').select('id, status, price', { count: 'exact' }),
  ]);

  const users = (usersResult.data as any[]) ?? [];
  const drivers = (driversResult.data as any[]) ?? [];
  const rides = (ridesResult.data as any[]) ?? [];

  return {
    totalUsers: users.filter(u => u.role === 'passenger').length,
    totalDrivers: drivers.length,
    pendingDrivers: drivers.filter(d => d.approval_status === 'pending').length,
    totalRides: rides.length,
    completedRides: rides.filter(r => r.status === 'completed').length,
    totalRevenue: rides
      .filter(r => r.status === 'completed')
      .reduce((sum: number, r: any) => sum + (r.price ?? 0), 0),
    activeDrivers: drivers.filter(d => d.is_online).length,
  };
}

// ── Mock data ─────────────────────────────────────────────────────────────────

function getMockPassengers(): AdminUser[] {
  return [
    {
      id: 'p1', phone: '+20 101 234 5678', full_name: 'فاطمة علي',
      avatar_url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop&crop=face',
      role: 'passenger', is_active: true, is_verified: true,
      wallet_balance: 350, total_rides: 23, rating: 4.8,
      created_at: '2024-03-15T00:00:00Z',
    },
    {
      id: 'p2', phone: '+20 102 345 6789', full_name: 'محمد حسن',
      avatar_url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
      role: 'passenger', is_active: true, is_verified: true,
      wallet_balance: 120, total_rides: 15, rating: 4.6,
      created_at: '2024-04-10T00:00:00Z',
    },
    {
      id: 'p3', phone: '+20 103 456 7890', full_name: 'نور السيد',
      avatar_url: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face',
      role: 'passenger', is_active: false, is_verified: true,
      wallet_balance: 0, total_rides: 8, rating: 3.9,
      created_at: '2024-05-01T00:00:00Z',
    },
    {
      id: 'p4', phone: '+20 104 567 8901', full_name: 'أميرة رضا',
      avatar_url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&h=150&fit=crop&crop=face',
      role: 'passenger', is_active: true, is_verified: true,
      wallet_balance: 780, total_rides: 41, rating: 4.9,
      created_at: '2024-01-20T00:00:00Z',
    },
    {
      id: 'p5', phone: '+20 105 678 9012', full_name: 'خالد إبراهيم',
      avatar_url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop&crop=face',
      role: 'passenger', is_active: true, is_verified: false,
      wallet_balance: 50, total_rides: 3, rating: 4.2,
      created_at: '2024-06-05T00:00:00Z',
    },
  ];
}

function getMockDrivers(): AdminDriver[] {
  return [
    {
      id: 'd1', driver_id: 'dr1', phone: '+20 111 222 3333', full_name: 'أحمد محمود',
      avatar_url: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&h=150&fit=crop&crop=face',
      role: 'driver', is_active: true, is_verified: true,
      wallet_balance: 0, total_rides: 156, rating: 4.9,
      vehicle_type: 'car', vehicle_model: 'تويوتا كورولا 2022',
      vehicle_plate: 'أ ب ج 1234', vehicle_color: 'أبيض',
      approval_status: 'approved', is_online: true,
      total_earnings: 15600, current_lat: 30.0444, current_lng: 31.2357,
      face_photo_url: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400',
      national_id_url: null, license_url: null,
      created_at: '2024-01-10T00:00:00Z',
    },
    {
      id: 'd2', driver_id: 'dr2', phone: '+20 122 333 4444', full_name: 'محمود عبدالله',
      avatar_url: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
      role: 'driver', is_active: true, is_verified: false,
      wallet_balance: 0, total_rides: 0, rating: 0,
      vehicle_type: 'tuk', vehicle_model: 'توكتوك كهربائي 2023',
      vehicle_plate: 'د هـ و 5678', vehicle_color: 'أصفر',
      approval_status: 'pending', is_online: false,
      total_earnings: 0, current_lat: null, current_lng: null,
      face_photo_url: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400',
      national_id_url: null, license_url: null,
      created_at: '2024-06-01T00:00:00Z',
    },
    {
      id: 'd3', driver_id: 'dr3', phone: '+20 133 444 5555', full_name: 'سامي حسين',
      avatar_url: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&h=150&fit=crop&crop=face',
      role: 'driver', is_active: false, is_verified: true,
      wallet_balance: 0, total_rides: 43, rating: 3.2,
      vehicle_type: 'moto', vehicle_model: 'هوندا موتوسيكل 2021',
      vehicle_plate: 'ز ح ط 9012', vehicle_color: 'أحمر',
      approval_status: 'rejected', is_online: false,
      total_earnings: 4300, current_lat: null, current_lng: null,
      face_photo_url: null, national_id_url: null, license_url: null,
      created_at: '2024-02-14T00:00:00Z',
    },
    {
      id: 'd4', driver_id: 'dr4', phone: '+20 144 555 6666', full_name: 'يوسف عمر',
      avatar_url: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop&crop=face',
      role: 'driver', is_active: true, is_verified: true,
      wallet_balance: 0, total_rides: 89, rating: 4.7,
      vehicle_type: 'car', vehicle_model: 'هيونداي إيلانترا 2021',
      vehicle_plate: 'ي ك ل 3456', vehicle_color: 'رمادي',
      approval_status: 'approved', is_online: false,
      total_earnings: 8900, current_lat: null, current_lng: null,
      face_photo_url: null, national_id_url: null, license_url: null,
      created_at: '2024-03-01T00:00:00Z',
    },
  ];
}
