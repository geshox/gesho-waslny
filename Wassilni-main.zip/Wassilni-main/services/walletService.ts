// Powered by OnSpace.AI
import { supabase, isSupabaseConfigured } from '@/lib/supabase';

export type TransactionType = 'recharge' | 'ride_payment' | 'refund' | 'transfer';
export type TransactionStatus = 'pending' | 'completed' | 'failed';

export interface WalletTransaction {
  id: string;
  user_id: string;
  ride_id?: string | null;
  type: TransactionType;
  amount: number;
  balance_after: number;
  description: string;
  payment_method?: string | null;
  status: TransactionStatus;
  created_at: string;
}

/**
 * Get wallet balance from Supabase
 */
export async function getWalletBalance(userId: string): Promise<number> {
  if (!isSupabaseConfigured) return 0;
  const { data } = await supabase
    .from('users')
    .select('wallet_balance')
    .eq('id', userId)
    .single();
  return (data as any)?.wallet_balance ?? 0;
}

/**
 * Get transaction history for a user
 */
export async function getTransactions(
  userId: string,
  limit = 50
): Promise<WalletTransaction[]> {
  if (!isSupabaseConfigured) return getMockTransactions();
  const { data } = await supabase
    .from('wallet_transactions')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(limit);
  return (data as WalletTransaction[]) ?? getMockTransactions();
}

/**
 * Add balance to wallet (recharge)
 * Uses the atomic recharge_wallet RPC when available; falls back to the
 * legacy client-side write if the DB function isn't installed yet.
 */
export async function rechargeWallet(
  userId: string,
  amount: number,
  paymentMethod: string
): Promise<{ newBalance: number; error: string | null }> {
  if (!isSupabaseConfigured) {
    return { newBalance: amount, error: null };
  }

  const { data: rpcBalance, error: rpcError } = await supabase.rpc('recharge_wallet', {
    p_user_id: userId,
    p_amount: amount,
    p_payment_method: paymentMethod,
  });

  if (!rpcError && typeof rpcBalance === 'number') {
    return { newBalance: rpcBalance, error: null };
  }

  // Fallback — read-then-write (legacy schema without the RPC)
  const current = await getWalletBalance(userId);
  const newBalance = current + amount;

  const { error: updateError } = await supabase
    .from('users')
    .update({ wallet_balance: newBalance })
    .eq('id', userId);

  if (updateError) return { newBalance: current, error: updateError.message };

  await supabase.from('wallet_transactions').insert({
    user_id: userId,
    type: 'recharge',
    amount: amount,
    balance_after: newBalance,
    description: `شحن رصيد عبر ${paymentMethod}`,
    payment_method: paymentMethod,
    status: 'completed',
  });

  return { newBalance, error: null };
}

/**
 * Deduct balance for ride payment (auto-called on ride completion)
 */
export async function deductRidePayment(
  userId: string,
  rideId: string,
  amount: number,
  destination: string
): Promise<{ newBalance: number; error: string | null }> {
  if (!isSupabaseConfigured) {
    return { newBalance: 0, error: null };
  }

  const { data: result, error: rpcError } = await supabase.rpc('pay_ride_from_wallet', {
    p_user_id: userId,
    p_ride_id: rideId,
    p_amount: amount,
    p_destination: destination,
  });

  if (!rpcError && typeof result === 'string') {
    if (result === 'OK') {
      const newBalance = await getWalletBalance(userId);
      return { newBalance, error: null };
    }
    const message =
      result === 'INSUFFICIENT_FUNDS' ? 'رصيد غير كافٍ في المحفظة' : 'تعذر العثور على الحساب';
    return { newBalance: 0, error: message };
  }

  // Fallback — read-then-write (legacy schema without the RPC)
  const current = await getWalletBalance(userId);
  if (current < amount) {
    return { newBalance: current, error: 'رصيد غير كافٍ في المحفظة' };
  }

  const newBalance = current - amount;

  const { error: updateError } = await supabase
    .from('users')
    .update({ wallet_balance: newBalance })
    .eq('id', userId);

  if (updateError) return { newBalance: current, error: updateError.message };

  await supabase.from('wallet_transactions').insert({
    user_id: userId,
    ride_id: rideId,
    type: 'ride_payment',
    amount: -amount,
    balance_after: newBalance,
    description: `دفع رحلة إلى ${destination}`,
    payment_method: 'wallet',
    status: 'completed',
  });

  return { newBalance, error: null };
}

/**
 * Refund to wallet (if ride is cancelled)
 */
export async function refundToWallet(
  userId: string,
  rideId: string,
  amount: number
): Promise<{ error: string | null }> {
  if (!isSupabaseConfigured) return { error: null };

  const current = await getWalletBalance(userId);
  const newBalance = current + amount;

  await supabase
    .from('users')
    .update({ wallet_balance: newBalance })
    .eq('id', userId);

  await supabase.from('wallet_transactions').insert({
    user_id: userId,
    ride_id: rideId,
    type: 'refund',
    amount: amount,
    balance_after: newBalance,
    description: 'استرداد رصيد - رحلة ملغاة',
    status: 'completed',
  });

  return { error: null };
}

/**
 * Subscribe to wallet balance changes in real-time
 */
export function subscribeToWallet(userId: string, callback: (balance: number) => void) {
  return supabase
    .channel(`wallet:${userId}`)
    .on(
      'postgres_changes',
      {
        event: 'UPDATE',
        schema: 'public',
        table: 'users',
        filter: `id=eq.${userId}`,
      },
      (payload) => {
        const newBalance = (payload.new as any).wallet_balance;
        if (typeof newBalance === 'number') callback(newBalance);
      }
    )
    .subscribe();
}

// ── Mock Data (used when Supabase not configured) ─────────────────────────────

function getMockTransactions(): WalletTransaction[] {
  return [
    {
      id: 'tx1', user_id: 'u1', type: 'recharge', amount: 200,
      balance_after: 350, description: 'شحن رصيد عبر InstaPay',
      payment_method: 'instapay', status: 'completed',
      created_at: new Date(Date.now() - 86400000).toISOString(),
    },
    {
      id: 'tx2', user_id: 'u1', ride_id: 'r1', type: 'ride_payment', amount: -45,
      balance_after: 305, description: 'دفع رحلة إلى مول العرب',
      payment_method: 'wallet', status: 'completed',
      created_at: new Date(Date.now() - 172800000).toISOString(),
    },
    {
      id: 'tx3', user_id: 'u1', type: 'recharge', amount: 100,
      balance_after: 150, description: 'شحن رصيد عبر Vodafone Cash',
      payment_method: 'vodafone', status: 'completed',
      created_at: new Date(Date.now() - 259200000).toISOString(),
    },
    {
      id: 'tx4', user_id: 'u1', ride_id: 'r2', type: 'ride_payment', amount: -30,
      balance_after: 120, description: 'دفع رحلة إلى المطار',
      payment_method: 'wallet', status: 'completed',
      created_at: new Date(Date.now() - 345600000).toISOString(),
    },
    {
      id: 'tx5', user_id: 'u1', ride_id: 'r3', type: 'refund', amount: 25,
      balance_after: 145, description: 'استرداد رصيد - رحلة ملغاة',
      status: 'completed',
      created_at: new Date(Date.now() - 432000000).toISOString(),
    },
  ];
}
