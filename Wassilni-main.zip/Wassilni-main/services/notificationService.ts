// Powered by OnSpace.AI
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';
import { supabase } from '@/lib/supabase';

// ── Configure notification behavior ──────────────────────────────────────────
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

// ── Push Token Registration ───────────────────────────────────────────────────
export async function registerForPushNotifications(): Promise<string | null> {
  if (!Device.isDevice) {
    console.log('Push notifications are only available on physical devices');
    return null;
  }

  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;

  if (existingStatus !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }

  if (finalStatus !== 'granted') return null;

  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('default', {
      name: 'وصّلني',
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: '#10D876',
    });
    await Notifications.setNotificationChannelAsync('rides', {
      name: 'الرحلات',
      importance: Notifications.AndroidImportance.HIGH,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: '#10D876',
    });
    await Notifications.setNotificationChannelAsync('payments', {
      name: 'المدفوعات',
      importance: Notifications.AndroidImportance.DEFAULT,
      lightColor: '#F59E0B',
    });
  }

  try {
    const tokenData = await Notifications.getExpoPushTokenAsync();
    return tokenData.data;
  } catch {
    return null;
  }
}

/**
 * Save push token to database for server-side notifications
 */
export async function savePushToken(userId: string, token: string): Promise<void> {
  await supabase
    .from('users')
    .update({ push_token: token } as any)
    .eq('id', userId);
}

// ── Local Notification Senders ────────────────────────────────────────────────

export async function notifyRideAccepted(driverName: string, eta: number): Promise<void> {
  await Notifications.scheduleNotificationAsync({
    content: {
      title: 'تم قبول رحلتك ✅',
      body: `السائق ${driverName} قبل طلبك، سيصل خلال ${eta} دقيقة`,
      data: { type: 'ride_accepted' },
      sound: true,
      categoryIdentifier: 'rides',
    },
    trigger: null,
  });
}

export async function notifyDriverArrived(driverName: string): Promise<void> {
  await Notifications.scheduleNotificationAsync({
    content: {
      title: 'السائق وصل 📍',
      body: `${driverName} ينتظرك الآن أمام الموقع المحدد`,
      data: { type: 'driver_arrived' },
      sound: true,
      categoryIdentifier: 'rides',
    },
    trigger: null,
  });
}

export async function notifyRideStarted(destination: string): Promise<void> {
  await Notifications.scheduleNotificationAsync({
    content: {
      title: 'بدأت رحلتك 🚗',
      body: `في طريقك إلى ${destination}. استمتع بالرحلة!`,
      data: { type: 'ride_started' },
      sound: false,
    },
    trigger: null,
  });
}

export async function notifyRideCompleted(price: number, currency = 'ج.م'): Promise<void> {
  await Notifications.scheduleNotificationAsync({
    content: {
      title: 'اكتملت رحلتك 🎉',
      body: `تكلفة الرحلة: ${price.toFixed(1)} ${currency}. شكراً لاستخدامك وصّلني!`,
      data: { type: 'ride_completed' },
      sound: true,
    },
    trigger: null,
  });
}

export async function notifyPaymentSuccess(amount: number, method: string): Promise<void> {
  await Notifications.scheduleNotificationAsync({
    content: {
      title: 'تم الدفع بنجاح 💳',
      body: `تم خصم ${amount.toFixed(1)} ج.م عبر ${method}`,
      data: { type: 'payment_success' },
      sound: true,
      categoryIdentifier: 'payments',
    },
    trigger: null,
  });
}

export async function notifyNewRideRequest(
  from: string,
  to: string,
  price: number
): Promise<void> {
  await Notifications.scheduleNotificationAsync({
    content: {
      title: 'طلب رحلة جديد 🛺',
      body: `من: ${from}\nإلى: ${to}\nالسعر: ${price} ج.م`,
      data: { type: 'new_ride_request' },
      sound: true,
      categoryIdentifier: 'rides',
    },
    trigger: null,
  });
}

export async function notifyComplaintUpdate(status: string): Promise<void> {
  await Notifications.scheduleNotificationAsync({
    content: {
      title: 'تحديث على شكواك',
      body: `تم تغيير حالة شكواك إلى: ${status}`,
      data: { type: 'complaint_update' },
      sound: false,
    },
    trigger: null,
  });
}

/**
 * Clear all delivered notifications from notification center
 */
export async function clearAllNotifications(): Promise<void> {
  await Notifications.dismissAllNotificationsAsync();
  await Notifications.setBadgeCountAsync(0);
}

/**
 * Get all delivered notifications
 */
export async function getDeliveredNotifications() {
  return Notifications.getPresentedNotificationsAsync();
}
