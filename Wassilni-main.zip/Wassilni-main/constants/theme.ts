// Powered by OnSpace.AI
// تك توكي — Brand: Amber/Gold Dark Theme

export const BrandColors = {
  amber:       '#F5A623',
  amberDark:   '#D4881A',
  amberLight:  '#FFCB6B',
  amberFaded:  'rgba(245, 166, 35, 0.12)',
  amberGlow:   'rgba(245, 166, 35, 0.25)',
  gold:        '#D4A017',
  goldLight:   '#FFD700',
};

export const Colors = {
  // ── Backgrounds ──────────────────────────────────────
  background:    '#0B0804',
  surface:       '#130E08',
  card:          '#1A1108',
  cardElevated:  '#22160A',
  overlay:       'rgba(11, 8, 4, 0.92)',

  // ── Brand (Amber/Gold — تك توكي) ─────────────────────
  primary:       '#F5A623',
  primaryDark:   '#D4881A',
  primaryLight:  '#FFCB6B',
  primaryFaded:  'rgba(245, 166, 35, 0.12)',

  // ── Accents ──────────────────────────────────────────
  accent:        '#3B82F6',
  accentFaded:   'rgba(59, 130, 246, 0.12)',
  gold:          '#FFD700',
  goldFaded:     'rgba(255, 215, 0, 0.12)',
  emerald:       '#10D876',
  emeraldFaded:  'rgba(16, 216, 118, 0.12)',

  // ── Text ─────────────────────────────────────────────
  text:          '#FDFAF5',
  textSecondary: '#C8B89A',
  textTertiary:  '#7A6A55',
  textInverse:   '#0B0804',

  // ── Borders ──────────────────────────────────────────
  border:        '#2E1F0F',
  borderLight:   '#3D2A15',

  // ── Status ───────────────────────────────────────────
  success:       '#22C55E',
  successFaded:  'rgba(34, 197, 94, 0.12)',
  warning:       '#F59E0B',
  warningFaded:  'rgba(245, 158, 11, 0.12)',
  error:         '#EF4444',
  errorFaded:    'rgba(239, 68, 68, 0.12)',
  info:          '#3B82F6',
  infoFaded:     'rgba(59, 130, 246, 0.12)',

  // ── Map ──────────────────────────────────────────────
  mapRoad:       '#1C1208',
  mapBackground: '#0E0A05',
  mapWater:      '#0A1220',

  // ── Vehicle types ────────────────────────────────────
  car:           '#F5A623',
  tuk:           '#10D876',
  moto:          '#3B82F6',
  microbus:      '#8B5CF6',
};

// Cairo — Primary font for all Arabic text
export const FontFamily = {
  cairo: 'Cairo',
};

export const Fonts = {
  thin:      '300',
  regular:   '400',
  medium:    '500',
  semibold:  '600',
  bold:      '700',
  extrabold: '800',
  black:     '900',
};

export const Spacing = {
  xs:   4,
  sm:   8,
  md:   12,
  base: 16,
  lg:   20,
  xl:   24,
  xxl:  32,
  xxxl: 48,
};

export const Radius = {
  sm:   8,
  md:   12,
  lg:   16,
  xl:   20,
  xxl:  28,
  full: 999,
};

export const Shadow = {
  sm: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 4,
    elevation: 3,
  },
  md: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.5,
    shadowRadius: 8,
    elevation: 6,
  },
  lg: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.6,
    shadowRadius: 16,
    elevation: 10,
  },
  glow: {
    shadowColor: '#F5A623',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 14,
    elevation: 8,
  },
  glowSoft: {
    shadowColor: '#F5A623',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 6,
  },
};
