// Powered by OnSpace.AI
export const MOCK_USER = {
  id: 'user_001',
  name: 'أحمد محمد السيد',
  phone: '+20 100 123 4567',
  avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
  rating: 4.8,
  totalRides: 47,
  walletBalance: 250.00,
  joinDate: 'يناير 2024',
  isVerified: true,
};

export type VehicleType = 'car' | 'tuk' | 'moto' | 'microbus';

export const VEHICLE_LABELS: Record<VehicleType, string> = {
  car: 'سيارة',
  tuk: 'توكتوك',
  moto: 'موتوسيكل',
  microbus: 'ميكروباص',
};

export const VEHICLE_ICONS: Record<VehicleType, string> = {
  car: '🚗',
  tuk: '🛺',
  moto: '🏍️',
  microbus: '🚐',
};

export interface Driver {
  id: string;
  name: string;
  avatar: string;
  rating: number;
  totalRides: number;
  vehicleType: VehicleType;
  vehicleModel: string;
  vehiclePlate: string;
  vehicleColor: string;
  distance: number; // km
  eta: number; // minutes
  price: number; // EGP
  isOnline: boolean;
  lat: number;
  lng: number;
}

export const MOCK_DRIVERS: Driver[] = [
  {
    id: 'd001',
    name: 'محمود حسن',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop&crop=face',
    rating: 4.9,
    totalRides: 1243,
    vehicleType: 'car',
    vehicleModel: 'تويوتا كورولا 2022',
    vehiclePlate: 'أ ب ج 1234',
    vehicleColor: 'أبيض',
    distance: 0.8,
    eta: 3,
    price: 25,
    isOnline: true,
    lat: 30.0626,
    lng: 31.2497,
  },
  {
    id: 'd002',
    name: 'كريم عبدالله',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
    rating: 4.7,
    totalRides: 876,
    vehicleType: 'car',
    vehicleModel: 'هيونداي إكسنت 2021',
    vehiclePlate: 'د ه و 5678',
    vehicleColor: 'رمادي',
    distance: 1.2,
    eta: 5,
    price: 30,
    isOnline: true,
    lat: 30.0601,
    lng: 31.2520,
  },
  {
    id: 'd003',
    name: 'سامي إبراهيم',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&h=150&fit=crop&crop=face',
    rating: 4.5,
    totalRides: 432,
    vehicleType: 'tuk',
    vehicleModel: 'توكتوك كهربائي',
    vehiclePlate: 'ز ح ط 9012',
    vehicleColor: 'أصفر',
    distance: 0.5,
    eta: 2,
    price: 15,
    isOnline: true,
    lat: 30.0650,
    lng: 31.2470,
  },
  {
    id: 'd004',
    name: 'عمر خالد',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&h=150&fit=crop&crop=face',
    rating: 4.6,
    totalRides: 654,
    vehicleType: 'moto',
    vehicleModel: 'هوندا 150cc',
    vehiclePlate: 'ي ك ل 3456',
    vehicleColor: 'أحمر',
    distance: 0.3,
    eta: 2,
    price: 12,
    isOnline: true,
    lat: 30.0615,
    lng: 31.2510,
  },
  {
    id: 'd005',
    name: 'طارق أحمد',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face',
    rating: 4.8,
    totalRides: 2100,
    vehicleType: 'microbus',
    vehicleModel: 'ميكروباص نيسان',
    vehiclePlate: 'م ن س 7890',
    vehicleColor: 'أبيض',
    distance: 1.8,
    eta: 7,
    price: 10,
    isOnline: true,
    lat: 30.0580,
    lng: 31.2540,
  },
];

export interface RideHistory {
  id: string;
  driverName: string;
  driverAvatar: string;
  vehicleType: VehicleType;
  fromLocation: string;
  toLocation: string;
  date: string;
  time: string;
  price: number;
  status: 'completed' | 'cancelled' | 'pending';
  rating?: number;
  distance: number;
  duration: number;
}

export const MOCK_RIDES: RideHistory[] = [
  {
    id: 'r001',
    driverName: 'محمود حسن',
    driverAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop&crop=face',
    vehicleType: 'car',
    fromLocation: 'ميدان التحرير، القاهرة',
    toLocation: 'مطار القاهرة الدولي',
    date: '2 يونيو 2025',
    time: '14:30',
    price: 85,
    status: 'completed',
    rating: 5,
    distance: 22.4,
    duration: 35,
  },
  {
    id: 'r002',
    driverName: 'كريم عبدالله',
    driverAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
    vehicleType: 'car',
    fromLocation: 'مول مصر، 6 أكتوبر',
    toLocation: 'شارع التحرير',
    date: '1 يونيو 2025',
    time: '19:15',
    price: 45,
    status: 'completed',
    rating: 4,
    distance: 14.2,
    duration: 28,
  },
  {
    id: 'r003',
    driverName: 'سامي إبراهيم',
    driverAvatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&h=150&fit=crop&crop=face',
    vehicleType: 'tuk',
    fromLocation: 'السوق المركزي',
    toLocation: 'الحي الثالث',
    date: '30 مايو 2025',
    time: '10:00',
    price: 15,
    status: 'completed',
    rating: 5,
    distance: 3.1,
    duration: 12,
  },
  {
    id: 'r004',
    driverName: 'عمر خالد',
    driverAvatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&h=150&fit=crop&crop=face',
    vehicleType: 'moto',
    fromLocation: 'محطة المترو',
    toLocation: 'مكتب العمل',
    date: '28 مايو 2025',
    time: '08:45',
    price: 12,
    status: 'cancelled',
    distance: 2.8,
    duration: 0,
  },
  {
    id: 'r005',
    driverName: 'طارق أحمد',
    driverAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face',
    vehicleType: 'microbus',
    fromLocation: 'المنصورة',
    toLocation: 'القاهرة الجديدة',
    date: '25 مايو 2025',
    time: '07:00',
    price: 35,
    status: 'completed',
    rating: 4,
    distance: 85.0,
    duration: 90,
  },
];

export const PAYMENT_METHODS = [
  { id: 'p001', type: 'wallet', label: 'المحفظة الإلكترونية', icon: '💳', balance: 250.00, isDefault: true },
  { id: 'p002', type: 'instapay', label: 'إنستا باي', icon: '📱', balance: null, isDefault: false },
  { id: 'p003', type: 'vodafone', label: 'فودافون كاش', icon: '📲', balance: null, isDefault: false },
  { id: 'p004', type: 'card', label: 'بطاقة بنكية', icon: '💰', balance: null, isDefault: false },
  { id: 'p005', type: 'cash', label: 'الدفع النقدي', icon: '💵', balance: null, isDefault: false },
];

export const NOTIFICATION_MOCK = [
  { id: 'n001', title: 'تم قبول رحلتك', body: 'السائق محمود حسن في طريقه إليك', time: 'منذ 5 دقائق', icon: '🚗', isRead: false },
  { id: 'n002', title: 'السائق وصل', body: 'السائق ينتظرك أمام المبنى', time: 'منذ 12 دقيقة', icon: '📍', isRead: false },
  { id: 'n003', title: 'تم الدفع بنجاح', body: 'تم خصم 45 جنيه من محفظتك', time: 'أمس', icon: '💸', isRead: true },
  { id: 'n004', title: 'شكرًا على تقييمك', body: 'ساعدت تقييماتك في تحسين الخدمة', time: 'أمس', icon: '⭐', isRead: true },
];
